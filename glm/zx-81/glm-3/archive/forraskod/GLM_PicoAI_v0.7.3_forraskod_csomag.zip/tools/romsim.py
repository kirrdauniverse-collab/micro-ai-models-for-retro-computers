#!/usr/bin/env python3
"""ROM-szintű ZX81 szimulátor: a VALÓDI 8K ROM futtatásával teszteli a
teljes láncot (friss gép → RUN → boot-ML → láncolt LOAD → motor → chat
→ /save). A kazettát az IN-BYTE (0x034C) címén injektáljuk (a valódi
jelek helyett bájtokat adunk), a név-illesztést és a betöltés
befejezését viszont a ROM SAJÁT kódja végzi. A SAVE-ről a 0x0316-os
(OUT-PROG) és a 030B (OUT-NAME) címeken fogjuk fel a kimenő bájtokat.
"""
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__))))
from zx81sim import (ZX81Sim, load_blocks, KEY_POS, ZX2ASC,
                     F_C, F_Z, F_N, F_S, F_H)

ROM_PATH = os.environ.get("ZX81ROM",
                          "/home/z/my-project/GLM/refs/zx81.rom")
IN_BYTE = 0x034C       # a ROM szalag-bájt-olvasó rutin belépési pontja
OUT_NAME = 0x030B      # SAVE: a név kiírása (a bájt (HL)-ben)
OUT_PROG = 0x0316      # SAVE: a programbájt kiírása (a bájt (HL)-ben)
POST_TIMEOUT = 0x0364  # a csend-út folytatása: LD H,D / LD L,E / IN-NAME
INITIAL = 0x03E5       # a ROM inicializálása (= reset-jelenség)

# ASCII -> ZX81 belső karakterkód (a kazettanevekhez)
ASC2ZX = {}
for _i in range(26):
    ASC2ZX[chr(65 + _i)] = 0x26 + _i
for _i in range(10):
    ASC2ZX[str(_i)] = 0x1C + _i
ASC2ZX.update({'-': 0x1B, '.': 0x0B, '?': 0x0F, '"': 0x0B})


class Tape:
    """A T81-blokkokból álló kazetta-jelfolyam:
    [csend][név+adat][csend][név+adat]... — a csend az IN-BYTE
    időtúllépését váltja ki (a valódi gépen a blokkok közti szünet)."""

    def __init__(self, blocks, start_at=0):
        self.segs = [("gap", b"")]
        for name, data in blocks:
            zxname = bytes(ASC2ZX.get(ch, 0x00) for ch in name)
            zxname = zxname[:-1] + bytes([zxname[-1] | 0x80])
            self.segs.append(("data", zxname + data))
            self.segs.append(("gap", b""))
        # start_at: hányadik blokk TÖLÉSE után áll a szalag (a teszt
# elején a PICOBOOT már "betöltött", ezért 1-től megyünk)
        self.seg = 1 + 2 * start_at
        self.off = 0

    def read(self):
        """Egy bájt, vagy None ha a jelenlegi szegmens csendes."""
        while self.seg < len(self.segs):
            kind, data = self.segs[self.seg]
            if kind == "data" and self.off < len(data):
                b = data[self.off]
                self.off += 1
                return b
            return None
        return None

    def advance(self):
        """A csend után a következő szegmensre lép."""
        self.seg += 1
        self.off = 0


class RomSim(ZX81Sim):
    """Valódi ROM-módú szimulátor."""

    def __init__(self, container, trace=False):
        super().__init__(container, trace=trace)
        with open(ROM_PATH, "rb") as f:
            rom = f.read()
        assert len(rom) == 8192, "hibás ROM-méret"
        # 64K RAM: a 0x8000 felettit sosem olvassa értelmesen semmi,
        # de a SP=0-s induló verem 0xFFFE-re csúszik (mint a valóságban)
        self.ram = bytearray(0x10000)
        self.ram[0x0000:0x2000] = rom
        self.rom_exec = True
        self.tape = None
        self.save_log = []         # (forrás, bájt) a SAVE-ből
        self.saving = False
        self.stop_reason = None
        self.key_script = []       # (lépés, 'press'/'release', (sor,oszlop))
        self.total = 0
        self.watch = {}            # cím -> hányszor (megfigyelések)
        self.pc = 0x0000           # hideg indítás
        self.running = True

    # --- kazetta-injektálás az IN-BYTE-nál
    def _tape_inbyte(self):
        b = self.tape.read() if self.tape else None
        if b is not None:
            self.c = b
            self.a = b
            self.pc = self.pop()
            return
        # csend: a ROM időtúllépési útja: POP AF; CP D; JP NC,INITIAL
        self.tape.advance()
        self.sp = (self.sp + 2) & 0xFFFF
        self.a = 0x03              # a visszatérési cím magas bájtja
        r = (0x03 - self.d) & 0xFF
        carry = 1 if 0x03 < self.d else 0
        self.f = ((self.f & ~(F_C | F_Z | F_N | F_S | F_H))
                  | (F_C if carry else 0) | F_N
                  | (F_Z if r == 0 else 0)
                  | (F_S if r & 0x80 else 0))
        self.pc = POST_TIMEOUT if carry else INITIAL

    # --- SAVE-rögzítés (a 030B / 0316 címeken)
    def _save_capture(self, which):
        hl = self._hl()
        self.save_log.append((which, self.ram[hl]))

    # --- billentyű-vezérlés
    def key(self, ch, press=True):
        if ch in KEY_POS:
            if press:
                self.held.add(KEY_POS[ch])
            else:
                self.held.discard(KEY_POS[ch])

    def type_text(self, text, at, hold=400, gap=400):
        """Szöveg begépelése: minden billentyű hold lépésig lenyomva,
        majd elengedve, gap lépés különbséggel."""
        t = at
        for ch in text:
            self.key_script.append((t, "press", ch))
            self.key_script.append((t + hold, "release", ch))
            t += hold + gap
        return t

    def _apply_key_script(self):
        while self.key_script and self.key_script[0][0] <= self.total:
            _, act, ch = self.key_script.pop(0)
            self.key(ch, act == "press")

    # --- a KEYBOARD (02BB) szken funkcionális megfelelője:
    # a lenyomott billentyűk bitmapja H-be/L-be épül (mint a ROM-nál),
    # LAST-K (4025) frissül, és a CDFLAG (403B) 0. bitje jelzi, ha van
    # lenyomott billentyű — erre vár a szerkesztő SLOW-DISP (04CF) hurok.
    def _keyboard_effect(self):
        h, l = 0xFF, 0xFF
        for row, col in self.held:
            l &= row
            h &= (0xE0 | (0xFF ^ (1 << col))) & 0xFF
        self.h, self.l = h, l
        # A ROM-konvenció (JAVÍTVA 2026-11-23): a NMI-szkenn a KEYBOARD
        # (0x02BB) H/L eredményét `LD (LAST-K),HL`-lal tárolja — vagyis
        # mem[0x4025] = L = SORMASZK, mem[0x4026] = H = KULCSBITEK.
        # (Korábban fordítva írtuk — a DECODE ezért transzponálva
        # dekódolta a billentyűket: az 'R'-ből '1' lett!)
        self.w(0x4025, l)            # LAST-K alsó bájtja: L = sorok
        self.w(0x4026, h)            # LAST-K felső bájtja: H = kulcsbitek
        cd = self.ram[0x403B]
        if h != 0xFF:
            self.w(0x403B, cd | 0x01)   # van lenyomott billentyű
        else:
            self.w(0x403B, cd & 0xFE)

    # --- gyors-NMI: a valódi kezelő funkcionális hatása: az A'-számláló
    # eggyel nő (a PAUSE és a HALT-szinkron erre épül), a HALT feloldódik,
    # és lefut egy "képkockányi" billentyű-szkennelés (a valódi gépen ezt
    # az NMI-vezérelt képkocka-generálás végzi). A videójel-előállítást
    # (0x0281/0x028F, JP (IX), MARGIN-tánc) nem emuláljuk: a képernyőt a
    # D_FILE-ból olvassuk, állapota nem változik.
    def _quick_nmi(self):
        self.a2 = (self.a2 + 1) & 0xFF
        if self.halted:
            self.halted = False
        # A VALÓDI NMI minden regisztert megőriz (PUSH/POP, EX AF) — a
        # gyorsmodellünk is ezt teszi: a _keyboard_effect a H/L-be
        # építené a szkenn-bitmapot, de azt itt meg kell őrizni! (Enélkül
        # minden 26. lépésben 0xFFFF-re csonkult a HL, és a ROM rutinok
        # — pl. a LOC-ADDR 0x76-keresése — örök hurokba estek.)
        h, l = self.h, self.l
        self._keyboard_effect()
        self.h, self.l = h, l

    # --- futtatás
    def rom_run(self, max_steps=20_000_000, checkpoints=None):
        # A hideg start után MODE=1 (K-mód) — a valóság-konform állapot
        # (a ROM RAM-CHECK-je a MODE-t 0x02-vel roncsolja, de az első
        # gombnyomás MODE-SORT-útvonala 1-re viszi; a szim 0x00-s RAM-ja
        # miatt ez nálunk kihagyódna és minden gomb L-módú betű lenne).
        if self.ram[0x4027] == 0:
            self.w(0x4027, 1)
        checkpoints = checkpoints or []
        n = 0
        while n < max_steps and self.running:
            if self.halted:
                # HALT: várakozás a következő NMI-re (~soronként)
                self.nmi_countdown -= 1
                if self.nmi_countdown <= 0:
                    self.nmi_countdown = 26
                    self._quick_nmi()
                self.total += 1
                n += 1
                self._apply_key_script()
                continue
            if n % 26 == 0 and (self.ram[0x403B] & 0x80):
                self._quick_nmi()
            pc = self.pc
            if pc in checkpoints:
                self.watch[pc] = self.watch.get(pc, 0) + 1
                if self.watch[pc] >= checkpoints[pc]:
                    self.stop_reason = "ellenőrzőpont 0x%04X" % pc
                    self.running = False
                    break
            if pc == IN_BYTE:
                self._tape_inbyte()
            elif pc == 0x0207:       # SLOW/FAST ("mezőkészítés")
                # A valódi teszt: RET NC, ha CDFLAG bit6 == bit7 (nincs
                # teendő); ha KÜLÖNBÖZNEK (SLOW mód + videó ki — pl. a
                # LOAD-befejezés beleesése!), a videó visszakapcsol és
                # egy "mezőnyi" szken történik. Mindkét belépés (CALL és
                # a 01FC utáni beleesés) ugyanígy tér vissza: pop.
                cd = self.ram[0x403B]
                if ((cd >> 6) ^ (cd >> 7)) & 1:   # mezőt kell készíteni
                    self.w(0x403B, cd | 0xC0)     # videó + SLOW vissza
                    self._keyboard_effect()
                    self.f |= F_C
                else:
                    self.f &= ~F_C & 0xFF
                self.pc = self.pop()
            elif pc == 0x0229:       # DISPLAY-1 (csak a CALL Z útvonal!)
                self._keyboard_effect()
                self.pc = self.pop()
            elif pc == 0x0292:       # DISPLAY-3 (video-sor generátor)
                # A valódi rutin POP IX-szel veszi el a visszatérési címet,
                # egy video-sort generál (a D_FILE tükrözött bájtjait
                # utasításként futtatja a 0xC000-as RAM-tükörben) és
                # JP (IX)-szal tér vissza. A szimulátorban a sort
                # funkcionalizáljuk: egy NMI-nyi billentyű-szken + ugrás
                # a visszatérési címre — RAM-tükrözés nélkül is lefut az
                # egész betöltés→RUN út a valódi ROM-mal.
                self.ix = self.pop()
                self._keyboard_effect()
                self.pc = self.ix
            elif pc == 0x02B5:       # WAIT-INT (időzítő várakozás)
                self.pc = self.pop()
            elif pc == OUT_NAME:
                self._save_capture("name")
                self.step()
            elif pc == OUT_PROG:
                self._save_capture("data")
                self.step()
            else:
                self.step()
            if self.rom_exec and self.pc == 0x0000 and self.total > 100:
                self.stop_reason = "RESET! (PC=0x0000)"
                self.running = False
                break
            self.total += 1
            n += 1
            self._apply_key_script()
        if n >= max_steps:
            self.stop_reason = self.stop_reason or "lépéskorlát"
        return n

    # --- képernyő (D_FILE alapján)
    def screen(self):
        # A ZX81 D_FILE-formátum: [vezető 0x76] + 24 × [32 karakter +
        # záró 0x76] — az r. sor cellái: DFILE+1+33*r (a config.z80-val
        # azonos konvenció; a záró 0x76 a sorok VÉGÉN áll!)
        df = self.peek16(0x400C)
        out = []
        for r in range(24):
            base = df + 1 + 33 * r
            if base + 31 >= len(self.ram):
                break
            row = []
            for i in range(32):
                c = self.ram[base + i]
                row.append(ZX2ASC.get(c, '?'))
            out.append("".join(row))
        return "\n".join(out)


def main():
    import argparse
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("tape", help="a .T81 kazetta útvonala")
    ap.add_argument("--boot", default="PICOBOOT",
                    help="a már betöltött boot-blokk neve")
    ap.add_argument("--steps", type=int, default=20_000_000)
    ap.add_argument("--trace", action="store_true")
    args = ap.parse_args()

    sim = RomSim(args.tape, trace=args.trace)
    blocks = dict(sim.blocks)
    names = [n for n, _ in sim.blocks]
    print("blokkok:", names)
    # 1) a gép felépíti magát (ROM: 0x0000-tól)
    n = sim.rom_run(max_steps=3_000_000)
    print("[1] hideg indulás: %d lépés, ok: %s" % (n, sim.stop_reason))
    sim.stop_reason = None
    sim.running = True
    print("    RAMTOP=0x%04X  E_LINE=0x%04X  D_FILE=0x%04X"
          % (sim.peek16(0x4004), sim.peek16(0x4014), sim.peek16(0x400C)))
    # 2) a boot-blokk "betöltése": a kép alkalmazása + a szalag a
    #    következő blokkra áll (a valóságban LOAD "PICOBOOT" történt)
    img = blocks[args.boot]
    sim.ram[0x4009:0x4009 + len(img)] = img
    # a LOAD-befejezés (01FC utáni beleesés a 0x0207-be) emulálása:
    # a videó visszakapcsol SLOW-ban — a ROM-terhelő kikapcsolta
    sim.w(0x403B, sim.ram[0x403B] | 0xC0)
    sim.tape = Tape(sim.blocks, start_at=1 + names.index(args.boot)
                    if args.boot in names[:1] else names.index(args.boot))
    # 3) RUN begépelése
    t = sim.type_text("RUN\n", at=sim.total + 200)
    print("[2] RUN begépelése indul, szalag a(z) %d. blokknál"
          % sim.tape.seg)
    n = sim.rom_run(max_steps=args.steps)
    print("[3] futás: %d lépés, ok: %s" % (n, sim.stop_reason))
    print("    PC=0x%04X  BC=0x%04X  RAMTOP=0x%04X"
          % (sim.pc, sim._bc(), sim.peek16(0x4004)))
    print("--- képernyő ---")
    print(sim.screen())
    if sim.save_log:
        names_ = [b for w, b in sim.save_log if w == "name"]
        data_ = [b for w, b in sim.save_log if w == "data"]
        print("SAVE %d név-bájt + %d adat-bájt" % (len(names_), len(data_)))


if __name__ == "__main__":
    main()
