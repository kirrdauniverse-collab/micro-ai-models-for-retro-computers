#!/usr/bin/env python3
"""build_t81.py — a Pico AI kazetta (EO81/.T81/.P) összeállítása.

A 0x4009-től induló memóriakép-recept a korábbi (hármasan ellenőrzött)
projektből: rendszer-változók 116 B, "1 REM <motor>", "2 IF USR 16514=1
THEN LOAD", "3 IF USR 16514=2 THEN SAVE", "4 RAND USR VAL "16514"";
minden szám-literál után 0x7E + 5 bájtos ZX lebegőpontos érték (a ROM
S-STK-DEC szcennerének követelménye).

Blokkok:
  PICOBASE  FULL  (D_FILE-fal és VARS-jelzővel)  — első betöltésre kész
  PICOASTR  SHORT (0x7120 alatt végződik)        — témacsomag
  PICOSCIN  SHORT
A SHORT képek nem írják felül a D_FILE-t (a profil-cellák!) sem a
0x7160-tól induló tanult-zónát.
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
Z = 0x4009
PROG = 0x407D
CODE_ORG = 16514
DFILE = 0x7B00
VARSND = DFILE + 793
ELINE = VARSND + 1
SHORT_END = 0x7120
ENGINE = Z + 0x407D - Z  # placeholder (nem használt)


def be16(v):
    return bytes(((v >> 8) & 0xFF, v & 0xFF))


def le16(v):
    return bytes((v & 0xFF, (v >> 8) & 0xFF))


def sysvars():
    s = bytearray(116)
    s[1:3] = le16(1)            # E_PPC
    s[3:5] = le16(DFILE)        # D_FILE
    s[5:7] = le16(DFILE + 1)    # DF_CC
    s[7:9] = le16(VARSND)       # VARS
    s[9:11] = le16(0)           # DEST
    s[11:13] = le16(ELINE)      # E_LINE
    s[13:15] = le16(ELINE + 4)  # CH_ADD
    s[17:19] = le16(ELINE + 5)  # STKBOT
    s[19:21] = le16(ELINE + 5)  # STKEND
    s[22:24] = le16(0x405D)     # MEM
    s[25] = 2                   # DF_SZ
    s[29:31] = le16(0x7FFD)     # verem-tető (SP-forrás gyorsbetöltéskor)
    s[32:34] = le16(DFILE)      # D_FILE-másolat
    return bytes(s)


def zx_digits(n):
    return bytes(0x1C + int(ch) for ch in str(n))


def zx_name(s):
    out = []
    for ch in s:
        if "A" <= ch <= "Z":
            out.append(0x26 + ord(ch) - 65)
        elif "0" <= ch <= "9":
            out.append(0x1C + int(ch))
        elif ch == "-":
            out.append(0x16)
        else:
            raise ValueError(f"rossz blokknév-karakter: {ch!r}")
    return bytes(out)


def zx_fp(n):
    e = n.bit_length()
    m = round(n / (1 << e) * (1 << 32))
    assert 1 << 31 <= m < 1 << 32, f"zx_fp({n})"
    return bytes([0x80 + e, (m >> 24) & 0x7F, (m >> 16) & 0xFF,
                  (m >> 8) & 0xFF, m & 0xFF])


def dfile_blank():
    return b"\x76" + (b"\x00" * 32 + b"\x76") * 24


def line(num, body):
    return be16(num) + le16(len(body) + 1) + body + b"\x76"


def lines3(code, load_name):
    body1 = b"\xEA" + code
    l2 = (b"\xFA\xD4" + zx_digits(CODE_ORG) + b"\x7E" + zx_fp(CODE_ORG)
          + b"\x14\x1D" + b"\x7E" + zx_fp(1)
          + b"\xDE\xEF\x0B" + zx_name(load_name) + b"\x0B")
    l3 = (b"\xFA\xD4" + zx_digits(CODE_ORG) + b"\x7E" + zx_fp(CODE_ORG)
          + b"\x14\x1E" + b"\x7E" + zx_fp(2)
          + b"\xDE\xF8\x0B" + zx_name("PICOBASE") + b"\x0B")
    l4 = b"\xF9\xD4\xC5\x0B" + zx_digits(CODE_ORG) + b"\x0B"
    return (line(1, body1) + line(2, l2) + line(3, l3) + line(4, l4)
            + b"\x76")


MARKER = b"\xAD\xDE\xB1\x5C"      # NAMESLOT DW 0xDEAD + bűnjel


def build_image(code, kb, load_name, full):
    prog = lines3(code, load_name)
    img = bytearray(sysvars())
    assert len(img) == PROG - Z
    img += prog
    # DICT és KB a rögzített címeken
    end = Z + len(img)
    assert end <= 0x5F00, f"a motor túl hosszú: 0x{end:04X}"
    img += b"\x00" * (0x5F00 - end)
    img += dict_bin
    img += b"\x00" * (0x6900 - (Z + len(img)))
    img += kb
    end = Z + len(img)
    if full:
        assert end <= DFILE, f"FULL túl hosszú: 0x{end:04X}"
        img += b"\x00" * (DFILE - end)
        img += dfile_blank()
        img += b"\x80"
    else:
        assert end <= SHORT_END, f"SHORT túl hosszú: 0x{end:04X}"
        img += b"\x00" * (SHORT_END - end)
    return bytes(img)


def patch_nameslot(code_img):
    """A 2-es sor LOAD-név-mezőjének címe a NAMESLOT DW-be."""
    pos = code_img.index(MARKER)
    # a 2-es sor törzse a PROG-ban: számoljuk a tényleges kezdőcímet
    # sor1: [00 01][len LE] 0xEA + kód + 0x76
    l1_len = 4 + 1 + (len(code_img) - len(MARKER) - 2) + 1
    # pontosabban a builderben a code a motor MARADÉKÁVAL együtt van a
    # képben; itt a név-mező lineárisan: PROG + l1 + l2-fej + 24
    return pos


def wrap_eo81(name, data):
    hdr = name.encode().ljust(32, b"\0") + str(len(data)).encode().ljust(
        16, b"\0")
    return hdr + data


def main():
    global dict_bin
    bdir = os.path.join(HERE, "..", "engine", "build")
    dist = os.path.join(HERE, "..", "dist")
    os.makedirs(dist, exist_ok=True)
    code = open(os.path.join(bdir, "engine.bin"), "rb").read()
    dict_bin = open(os.path.join(bdir, "dict.bin"), "rb").read()
    topics = [("PICOBASE", "base.pk", True),
              ("PICOASTR", "astronomy.pk", False),
              ("PICOSCIN", "science.pk", False)]
    blocks = []
    for name, pk, full in topics:
        kb = open(os.path.join(bdir, pk), "rb").read()
        img = build_image(code, kb, name, full)
        # NAMESLOT-patch: a 2-es sor név-mezőjének címe
        # sor1 törzs: 0xEA + kód; sor2 kezdete utána + 4 fejléc + 24 offset
        l1 = 4 + 1 + len(code) + 1
        l2_body = PROG + l1 + 4
        slot = l2_body + 24
        pos = img.index(MARKER) - 2 + Z  # a DW kezdete a képen belül
        img = bytearray(img)
        img[pos:pos + 2] = le16(slot)
        img = bytes(img)
        open(os.path.join(dist, name + ".p"), "wb").write(img)
        blocks.append((name, img))
        print(f"{name}: {len(img)} B ({'FULL' if full else 'SHORT'}), "
              f"név-mező: 0x{slot:04X}")
    tape = b"EO81" + b"".join(wrap_eo81(n, d) for n, d in blocks)
    out = os.path.join(dist, "ZX81PICO.T81")
    open(out, "wb").write(tape)
    print(f"ZX81PICO.T81: {len(tape)} B, {len(blocks)} blokk")
    # szerkezeti ellenőrzés
    i = 4
    n = 0
    while i + 48 <= len(tape):
        nm = tape[i:i + 32].rstrip(b"\0").decode()
        ln = int(tape[i + 32:i + 48].rstrip(b"\0"))
        assert tape[i + 48:i + 48 + ln][0x407D - 0x4009 - 0x407D + 0x407D
                                         - 0x4009:] is not None
        i += 48 + ln
        n += 1
    assert i == len(tape) and n == len(blocks)
    print("EO81 szerkezet: OK")
    return 0


if __name__ == "__main__":
    sys.exit(main())
