/* hal_tvc.c - Videoton TV Computer HAL skeleton (z88dk z80).
 *
 * Status: SKELETON (see docs/STATUS.md). The TVC is Z80-based with 64 KB
 * RAM; tape is built in, the disk (TDC/EXDOS-style controller) is rare.
 * Class C fits in 64 KB.
 *
 * The TVC BASIC ROM exposes cassette routines at fixed addresses; the
 * exact vectors (CASREAD-family) need verification against the TVC
 * service manual before use - the placeholders below document the plan.
 */
#include <string.h>
#include "rt_hal.h"

long hal_load_file(const char *name, rt_u8 *buf, long maxlen)
{
    /* TDC disk controller if present (rare); verify ROM entry points. */
    (void)name; (void)buf; (void)maxlen;
    return -1;
}

int hal_save_file(const char *name, const rt_u8 *buf, long len)
{
    (void)name; (void)buf; (void)len;
    return -1;
}

long hal_tape_load(int index, rt_u8 *buf, long maxlen)
{
    /* Plan: call the TVC ROM cassette read vector for each block in
     * sequence (blocks: 0 = base model, 1..n = topic packs). */
    (void)index; (void)buf; (void)maxlen;
    return -1; /* TODO: verify ROM cassette vectors */
}

int hal_tape_save(int index, const rt_u8 *buf, long len)
{
    (void)index; (void)buf; (void)len;
    return -1;
}

int hal_getchar(void)   { return -1; } /* TODO: keyboard scan via ROM */
int hal_kbhit(void)     { return 0; }
void hal_putchar(int c) { (void)c; }   /* TODO: screen print via ROM */
void hal_flush(void)    { }
void hal_msleep(long ms){ (void)ms; }
rt_u32 hal_entropy(void){ return 0x54564321UL; }

int hal_list_topics(char *names, int max)
{
    (void)names; (void)max;
    return -1; /* tape topics load by index */
}

/* Screen-RAM scratch: not supported yet. The TVC video RAM is selected
 * through video-segment registers; borrowing cells safely needs that
 * addressed first (future work). */
long hal_scratch_cells(void)          { return -1; }
int  hal_scratch_bits(void)           { return 8; }
rt_u8 hal_scratch_get(long i)         { (void)i; return 0; }
void hal_scratch_put(long i, rt_u8 v) { (void)i; (void)v; }

void hal_panic(const char *msg)
{
    (void)msg;
    for (;;)
        ;
}
