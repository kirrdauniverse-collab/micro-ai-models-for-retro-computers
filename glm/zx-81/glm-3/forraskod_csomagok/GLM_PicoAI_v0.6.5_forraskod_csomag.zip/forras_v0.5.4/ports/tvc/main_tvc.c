/* main_tvc.c - Videoton TV Computer entry point. */
#include "rt_app.h"

int main(void)
{
    if (rt_app_boot_tape(0) != 0)
        return 1;
    rt_app_run();
    return 0;
}
