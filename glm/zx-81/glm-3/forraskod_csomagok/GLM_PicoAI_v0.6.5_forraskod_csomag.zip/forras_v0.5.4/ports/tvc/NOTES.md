# Videoton TV Computer notes

- Z80 target, 64 KB RAM: Class C (28 KB blob) + engine (~12 KB) fits.
- Tape is the realistic source; the disk controller is rare (still the
  primary source per project policy WHERE it exists).
- hal_tvc.c is a SKELETON: verify the TVC ROM cassette and keyboard
  vectors from the service manual, then wire hal_tape_load/hal_getchar.
- The RT-turbo pulse decoder (engine/rt_tape.c) runs on any Z80 that can
  count loop iterations between cassette port edges - same approach as
  ports/zxspectrum/turbo_zx.s.
