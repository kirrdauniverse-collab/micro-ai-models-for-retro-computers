/* main_c64.c - C64 entry point: load the base model from disk, chat. */
#include "rt_app.h"

int main(void)
{
    if (rt_app_boot("base_c") != 0) {
        /* fall back to the first tape block if the disk is absent */
        if (rt_app_boot_tape(0) != 0) {
            return 1;
        }
    }
    rt_app_run();
    return 0;
}
