/* hal_c64.c - Commodore 64 HAL (cc65).
 *
 * Status: source complete, NOT yet compiled in CI (no cc65 in the sandbox
 * that produced v0.1). Build with ports/c64/Makefile (needs cc65).
 *
 * Memory plan (64 KB):
 *   engine + app code   ~10-14 KB (cc65 small model)
 *   scratch tier       200 B in screen rows 0-4 (docs/SCRATCH.md)
 *   model buffer        32 KB  (Class C, ctx10/emb24/h96)
 *   tape/model reload   the same buffer
 * Disk is the PRIMARY model source (kernal LOAD, device 8); tape is the
 * fallback (device 1). Both go through the same LOAD call, so this HAL
 * implements them together.
 */
#include <stddef.h>
#include <string.h>
#include <cc65.h>
#include <cbm.h>
#include "rt_hal.h"
#include "rt_tape.h"

#define MODEL_BUF_LEN 40960

static rt_u8 c64_model[MODEL_BUF_LEN]; /* exposed via hal hooks below */

/* --- file/tape loading via kernal --- */

static long load_from_device(const char *name, rt_u8 *buf, long maxlen,
                             int device)
{
    /* kernal LOAD("name", device, 0) reads a PRG into RAM at its load
     * address. To land it in OUR buffer we use the "secondary address 0
     * means load address from file" trick inverted: we pass the buffer
     * through cbm_load(), which returns the number of bytes loaded. */
    unsigned len = (unsigned)(maxlen > 60000U ? 60000U : maxlen);
    int res = cbm_load(name, device, (void *)buf);
    if (res < 0)
        return -1;
    len = (unsigned)res;
    return (long)len;
}

long hal_load_file(const char *name, rt_u8 *buf, long maxlen)
{
    long n = load_from_device(name, buf, maxlen, 8); /* disk first */
    if (n >= 0)
        return n;
    return load_from_device(name, buf, maxlen, 1); /* tape fallback */
}

long hal_tape_load(int index, rt_u8 *buf, long maxlen)
{
    char name[4] = "0";
    /* sequential tape blocks: block 0 = "0", 1 = "1", ... The build tape
     * (tools/build_tape.sh) names them accordingly; the kernal scans the
     * tape for the requested header. */
    name[0] = (char)('0' + index);
    return load_from_device(name, buf, maxlen, 1);
}

int hal_tape_save(int index, const rt_u8 *buf, long len)
{
    char name[4] = "0";
    name[0] = (char)('0' + index);
    return cbm_save(name, 1, buf, (unsigned)len) < 0 ? -1 : 0;
}

int hal_save_file(const char *name, const rt_u8 *buf, long len)
{
    return cbm_save(name, 8, (void *)buf, (unsigned)len) < 0 ? -1 : 0;
}

/* --- console --- */

int hal_getchar(void)
{
    return cbm_k_chrin();
}

int hal_kbhit(void)
{
    return cbm_k_readst() & 0x40 ? 0 : 1;
}

/* --- text area rows 5-24; rows 0-4 belong to the scratch tier ---
 * Direct screen-RAM output (PETSCII screen codes, own cursor, own
 * scroll): the kernal editor would scroll all 25 lines and scramble the
 * stored bytes, so normal output bypasses CHROUT (panic() keeps using
 * it: fatal path only). A VIC matrix move could free ~1 KB more but
 * needs bank/font handling - future work, see docs/SCRATCH.md. */
#define C64_TEXT_TOP 5
#define C64_COLS 40

static int c64_row = C64_TEXT_TOP;
static int c64_col = 0;

static rt_u8 *c64_scr_addr(int row, int col)
{
    return (rt_u8 *)(0x0400u + row * C64_COLS + col);
}

static rt_u8 *c64_col_addr(int row, int col)
{
    return (rt_u8 *)(0xD800u + row * C64_COLS + col);
}

static rt_u8 c64_screencode(int c)
{
    c &= 0x7F;
    if (c >= 'a' && c <= 'z')
        c -= 32; /* the font is upper case */
    if (c >= 32 && c < 64)
        return (rt_u8)c; /* punctuation + digits: same code */
    if (c >= 64 && c < 96)
        return (rt_u8)(c - 64); /* letters: screen code 1-26 */
    return 32; /* space */
}

static void c64_scr_scroll(void)
{
    int row, col;
    for (row = C64_TEXT_TOP; row < 24; row++) {
        for (col = 0; col < C64_COLS; col++) {
            *c64_scr_addr(row, col) = *c64_scr_addr(row + 1, col);
            *c64_col_addr(row, col) = *c64_col_addr(row + 1, col);
        }
    }
    for (col = 0; col < C64_COLS; col++) {
        *c64_scr_addr(24, col) = 32;
        *c64_col_addr(24, col) = 1; /* light blue text */
    }
}

static void c64_advance(void)
{
    c64_col = 0;
    if (++c64_row > 24) {
        c64_scr_scroll();
        c64_row = 24;
    }
}

void hal_putchar(int c)
{
    if (c == '\n') {
        c64_advance();
        return;
    }
    if (c64_col > C64_COLS - 1)
        c64_advance();
    *c64_scr_addr(c64_row, c64_col) = c64_screencode(c);
    c64_col++;
}

long hal_scratch_cells(void)
{
    return 200; /* screen rows 0-4: $0400-$04C7 */
}

int hal_scratch_bits(void)
{
    return 8;
}

rt_u8 hal_scratch_get(long i)
{
    return *c64_scr_addr((int)(i / C64_COLS), (int)(i % C64_COLS));
}

void hal_scratch_put(long i, rt_u8 v)
{
    *c64_scr_addr((int)(i / C64_COLS), (int)(i % C64_COLS)) = v;
}

void hal_flush(void)
{
}

void hal_msleep(long ms)
{
    /* ~1 ms per jiffy (60 Hz PAL: 16.67 ms granularity is fine here) */
    long jiffies = ms * 60 / 1000;
    while (jiffies-- > 0) {
        unsigned char last = *(unsigned char *)0xA2;
        while (*(unsigned char *)0xA2 == last)
            ;
    }
}

rt_u32 hal_entropy(void)
{
    return (rt_u32)*(unsigned char *)0xA2 * 65536UL +
           (rt_u32)*(unsigned char *)0xA1 * 256UL + 0x1234UL;
}

int hal_list_topics(char *names, int max)
{
    /* reading the disk directory needs cbm_opendir; topic packs are named
     * topic_*.bin - v0.1 keeps the fixed list to save RAM */
    static const char *fixed[] = { "topic_retro", "topic_weather",
                                   "topic_animals", "topic_greetings",
                                   "topic_numbers", "topic_jokes" };
    int i, n = sizeof fixed / sizeof fixed[0];
    if (n > max)
        n = max;
    for (i = 0; i < n; i++) {
        strncpy(names + i * 16, fixed[i], 15);
        names[i * 16 + 15] = 0;
    }
    return n;
}

void hal_panic(const char *msg)
{
    while (*msg)
        cbm_k_bsout((unsigned char)*msg++);
    for (;;)
        ;
}
