# ZX Spectrum notes

- Tape is the default on a bare 48K: `tools/tapewriter.py --tzx tape.tzx
  models/topic_retro.bin ...` produces a turbo tape; `/load N` picks the
  N-th block. `--zx out.tap` gives plain ROM-loadable blocks as a
  compatibility fallback (LOAD ""CODE).
- Disk where the interface exists (+3, TR-DOS, +D, MB-02): wire
  `hal_load_file` to the DOS read call - the engine does not care where
  the bytes come from. Disk stays the primary source per project policy.
- Class C model (28 KB) fits in 48K with the engine (~12 KB).
- `turbo_zx.s` is the timing-critical edge counter; it must be validated
  on real hardware (or a cycle-exact emulator) before relying on it.
