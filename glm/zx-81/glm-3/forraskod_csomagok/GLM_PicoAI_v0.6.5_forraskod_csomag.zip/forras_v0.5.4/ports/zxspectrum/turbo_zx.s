; turbo_zx.s - cycle-exact pulse measurement for RT-turbo on the ZX
; Spectrum cassette port (z88dk assembler).
;
; The engine calls rt_pulse() and receives the width of the LAST half-wave
; in microseconds. We count 23-T-state loop iterations between edges of
; the EAR bit (IN A,(0FEh), bit 6) and scale by 3.5 MHz:
;   us = iterations * 23 / 3.5  =  iterations * 46 / 7
;
; Must run with interrupts disabled, from non-contended RAM (>= 0x8000).
; NOT yet validated on hardware - see docs/STATUS.md.

        PUBLIC _zx_pulse_exact

_zx_pulse_exact:
        ; wait for an edge (any transition of the EAR bit)
        IN      A, (0FEh)
        AND     040h
        LD      C, A            ; C holds the previous level
edge_loop:
        IN      A, (0FEh)
        AND     040h
        XOR     C
        JR      Z, edge_loop    ; 23 T loop: no edge yet
        ; edge seen: count iterations until the next one
        LD      DE, 0           ; iteration counter
count_loop:
        INC     DE
        IN      A, (0FEh)
        AND     040h
        XOR     C
        JR      NZ, done        ; edge -> DE iterations elapsed
        ; keep the level in C stable between edges: C stays as-is
        JR      count_loop
done:
        ; us = DE * 46 / 7 (approx; the decoder tolerates +-25%)
        ; 46/7 ~ 6.57: multiply by 6 + small correction
        PUSH    DE
        POP     HL
        ADD     HL, HL          ; x2
        ADD     HL, HL          ; x4
        ADD     HL, DE          ; x5  -- close enough to 6.57 with the
        ADD     HL, DE          ; x6     decoder's tolerance
        LD      DE, 6           ; safety divisor remainder ignored
        ; return HL as the pulse width in "units" (~us)
        RET
