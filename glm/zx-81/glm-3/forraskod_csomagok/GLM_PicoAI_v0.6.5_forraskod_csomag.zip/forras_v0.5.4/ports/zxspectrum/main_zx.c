/* main_zx.c - ZX Spectrum entry point: model from tape (RT-turbo). */
#include "rt_app.h"

int main(void)
{
    if (rt_app_boot_tape(0) != 0)
        return 1;
    rt_app_run();
    return 0;
}
