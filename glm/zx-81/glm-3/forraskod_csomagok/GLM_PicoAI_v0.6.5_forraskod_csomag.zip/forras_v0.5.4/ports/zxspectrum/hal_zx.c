/* hal_zx.c - ZX Spectrum 48K HAL (z88dk).
 *
 * Status: skeleton - the kernal-free z80 code paths (edge counting for
 * RT-turbo, disk via +3 DOS / TR-DOS / +D) are documented in NOTES.md and
 * need z88dk + on-hardware validation. The ENGINE itself is proven on the
 * host (see docs/STATUS.md); only this HAL is pending.
 *
 * Memory plan (48 KB):
 *   engine + app   ~12 KB
 *   model buffer   28 KB (Class C)
 */
#include <string.h>
#include <stdlib.h>
#include <spectrum.h>
#include "rt_hal.h"
#include "rt_tape.h"

long hal_load_file(const char *name, rt_u8 *buf, long maxlen)
{
    /* Disk interface (+3 DOS / TR-DOS / +D) - the primary source where
     * the interface exists. TODO: call the DOS through its entry point
     * (TR-DOS 0x3D13 or +3 DOS) once validated on hardware. */
    (void)name; (void)buf; (void)maxlen;
    return -1;
}

int hal_save_file(const char *name, const rt_u8 *buf, long len)
{
    (void)name; (void)buf; (void)len;
    return -1;
}

/* RT-turbo over the cassette port: measure the pulse width between two
 * flux edges. The z80 loop below counts iterations between IN 0xFE bit 6
 * transitions; the count is converted to microseconds with a calibration
 * constant (3.5 MHz CPU, loop = 23 T-states).
 * NOTE: cycle-exact timing needs the interrupts disabled and the loader
 * placed in contended-free RAM - see NOTES.md before first hardware use.
 */
static rt_u16 zx_edge_pulse(void);

long hal_tape_load(int index, rt_u8 *buf, long maxlen)
{
    long want = -1;
    while (index >= 0) {
        want = rt_tape_read_block(buf, maxlen, zx_edge_pulse);
        if (want < 0)
            return want;
        index--;
    }
    return want;
}

int hal_tape_save(int index, const rt_u8 *buf, long len)
{
    (void)index;
    /* writing needs the MIC port bit-banged with the same calibration;
     * v0.1 keeps saves on disk-capable machines only */
    (void)buf; (void)len;
    return -1;
}

#pragma disable-warning 59  /* pointer sign */

int hal_getchar(void)
{
    return getk() ? getk() : -1; /* z88dk keyboard scan */
}

int hal_kbhit(void)
{
    return getk() != 0;
}

/* --- text area rows 8-23; rows 0-7 belong to the scratch tier ---
 * Direct D-file output (ROM font, own cursor, own scroll): the ROM print
 * routines would scroll all 24 lines and scramble the stored bytes, so
 * normal output never goes through them (panic() still does: fatal path
 * only). Capacities in docs/SCRATCH.md; hardware validation pending. */
#define ZX_TEXT_TOP 8

static int zx_row = ZX_TEXT_TOP;
static int zx_col = 0;

static rt_u8 *zx_scr_addr(int row, int scan, int col)
{
    unsigned a = 0x4000u
        + ((unsigned)(row >> 3) << 11)  /* third * 2048 */
        + ((unsigned)(row & 7) << 8)    /* char line * 256 */
        + ((unsigned)scan << 5)         /* scanline * 32 */
        + (unsigned)col;
    return (rt_u8 *)a;
}

static void zx_write_char(int c)
{
    int scan, col;
    unsigned code = (c < 32 || c > 127) ? 32u : (unsigned)c;
    for (scan = 0; scan < 8; scan++)
        *zx_scr_addr(zx_row, scan, zx_col) =
            *(rt_u8 *)(15616u + (code - 32) * 8 + scan); /* ROM font 0x3D00 */
    *(rt_u8 *)(0x5800u + zx_row * 32 + zx_col) = 0x38; /* black on white */
}

static void zx_scr_scroll(void)
{
    int row, scan, col;
    for (row = ZX_TEXT_TOP; row < 23; row++) {
        for (scan = 0; scan < 8; scan++)
            for (col = 0; col < 32; col++)
                *zx_scr_addr(row, scan, col) = *zx_scr_addr(row + 1, scan, col);
        *(rt_u8 *)(0x5800u + row * 32) = *(rt_u8 *)(0x5800u + (row + 1) * 32);
        for (col = 1; col < 32; col++)
            *(rt_u8 *)(0x5800u + row * 32 + col)
                = *(rt_u8 *)(0x5800u + (row + 1) * 32 + col);
    }
    for (scan = 0; scan < 8; scan++)
        for (col = 0; col < 32; col++)
            *zx_scr_addr(23, scan, col) = 0;
    for (col = 0; col < 32; col++)
        *(rt_u8 *)(0x5800u + 23 * 32 + col) = 0x38;
}

static void zx_advance(void)
{
    zx_col = 0;
    if (++zx_row > 23) {
        zx_scr_scroll();
        zx_row = 23;
    }
}

void hal_putchar(int c)
{
    if (c == '\n') {
        zx_advance();
        return;
    }
    if (zx_col > 31)
        zx_advance();
    zx_write_char(c);
    zx_col++;
}

long hal_scratch_cells(void)
{
    return 2048; /* top third of pixel RAM: 0x4000-0x47FF */
}

int hal_scratch_bits(void)
{
    return 8;
}

static rt_u8 *zx_cell(long i)
{
    return (rt_u8 *)(0x4000u + (unsigned)i);
}

rt_u8 hal_scratch_get(long i)
{
    return *zx_cell(i);
}

void hal_scratch_put(long i, rt_u8 v)
{
    *zx_cell(i) = v; /* shows as garbage in the top 8 rows - the trade */
}

void hal_flush(void)
{
}

void hal_msleep(long ms)
{
    msleep(ms);
}

rt_u32 hal_entropy(void)
{
    /* frame counter at 0x5C78 (23672), increments every 20 ms */
    unsigned char *f = (unsigned char *)0x5C78;
    return (rt_u32)f[0] | ((rt_u32)f[1] << 8) | 0xBEEF0000UL;
}

int hal_list_topics(char *names, int max)
{
    /* no disk listing on a bare 48K; tape topics load by index */
    (void)names; (void)max;
    return -1;
}

void hal_panic(const char *msg)
{
    while (*msg)
        putc(*msg++);
    for (;;)
        ;
}

/* --- pulse measurement stub (assembly hand-off point) ---
 * The reference C version below is functionally right but NOT cycle
 * exact; ports/zxspectrum/turbo_zx.s holds the timing-correct routine
 * (IN A,(0FEh) / edge detect / 23-T loop). The HAL uses it via this
 * extern when built with z88dk. */
__asm
_PULSE_CALIB = 23            ; T-states per loop iteration
__endasm

static rt_u16 zx_edge_pulse(void)
{
    /* placeholder that returns silence; replaced by turbo_zx.s */
    return 0;
}
