# Amiga 500 notes

- Primary source: AmigaDOS disk. Put `chat_amiga`, `model.bin` and the
  `topic_*.bin` packs in one drawer.
- Model classes: A (about 348 KB) and B fit in 512 KB chip RAM. With a RAM
  expansion the SAME engine loads bigger files (header-driven, no recompile).
- "Tape variant": the Amiga has no tape standard; the documented fallback
  is streaming model blocks over the serial port from a PC
  (`tools/tapewriter.py --out tape.rtp` then any raw sender at 19200 baud,
  8N1; the HAL hook is `hal_tape_load`, to be wired to `serial.device`).
- Fine-tuning (`/finetune`) is enabled on this port: int32 gradient
  buffers need ~35 KB extra RAM (Class A).
