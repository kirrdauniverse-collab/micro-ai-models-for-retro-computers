/* main_amiga.c - Amiga entry point: model from disk (AmigaDOS), chat. */
#include <proto/dos.h>
#include "rt_app.h"

int main(void)
{
    if (rt_app_boot("model.bin") != 0)
        return 20;
    rt_app_run();
    return 0;
}
