/* hal_amiga.c - Amiga 500 HAL (vbcc m68k-amiga, Kickstart 1.3+).
 *
 * Status: source complete, NOT yet compiled here (no vbcc in the v0.1
 * sandbox). Build with ports/amiga/Makefile (needs vbcc + amiga headers).
 *
 * Memory plan (512 KB chip RAM, Class A/B models):
 *   engine + app + finetune buffers  ~50 KB code + data
 *   model buffer                     up to 360 KB (Class A ~348 KB)
 * Disk (AmigaDOS) is the PRIMARY model source. The "tape variant" on an
 * Amiga is the serial port: a PC can stream model blocks over a null-modem
 * cable with tools/tapewriter.py output - see NOTES.md.
 */
#include <exec/types.h>
#include <exec/io.h>
#include <dos/dos.h>
#include <dos/dosextens.h>
#include <proto/exec.h>
#include <proto/dos.h>
#include <time.h>
#include <string.h>
#include "rt_hal.h"

long hal_load_file(const char *name, rt_u8 *buf, long maxlen)
{
    BPTR fh = Open((CONST_STRPTR)name, MODE_OLDFILE);
    long n = -1;
    if (fh) {
        n = (long)Read(fh, buf, (long)maxlen);
        Close(fh);
    }
    return n;
}

int hal_save_file(const char *name, const rt_u8 *buf, long len)
{
    BPTR fh = Open((CONST_STRPTR)name, MODE_NEWFILE);
    if (!fh)
        return -1;
    Write(fh, (APTR)buf, (long)len);
    Close(fh);
    return 0;
}

long hal_tape_load(int index, rt_u8 *buf, long maxlen)
{
    /* v0.1: the serial-stream loader is documented in NOTES.md; the
     * default Amiga setup keeps every model on disk. */
    (void)index;
    (void)buf;
    (void)maxlen;
    return -1;
}

int hal_tape_save(int index, const rt_u8 *buf, long len)
{
    (void)index;
    (void)buf;
    (void)len;
    return -1;
}

/* console via DOS stdio (Output()) */
int hal_getchar(void)
{
    char c;
    long n = Read(Input(), &c, 1);
    return n == 1 ? (int)(unsigned char)c : -1;
}

int hal_kbhit(void)
{
    return WaitForChar(Input(), 0) ? 1 : 0;
}

void hal_putchar(int c)
{
    char b = (char)c;
    Write(Output(), &b, 1);
}

void hal_flush(void)
{
}

void hal_msleep(long ms)
{
    Delay(ms / 20 + 1); /* 20 ms ticks */
}

rt_u32 hal_entropy(void)
{
    return (rt_u32)DateStamp(NULL) ? 0x5A5A1234UL : 0x1234ABCDUL;
}

int hal_list_topics(char *names, int max)
{
    /* AmigaDOS pattern scan for topic_#?.bin - v0.1 fixed list */
    static const char *fixed[] = { "topic_retro", "topic_weather",
                                   "topic_animals", "topic_greetings",
                                   "topic_numbers", "topic_jokes" };
    int i, n = sizeof fixed / sizeof fixed[0];
    if (n > max)
        n = max;
    for (i = 0; i < n; i++) {
        strncpy(names + i * 16, fixed[i], 15);
        names[i * 16 + 15] = 0;
    }
    return n;
}

/* Screen-RAM scratch: not supported here. AmigaOS owns the display via
 * Intuition/graphics.library - screen memory is not ours to borrow, and
 * with hundreds of KB free there is nothing to gain. */
long hal_scratch_cells(void)          { return -1; }
int  hal_scratch_bits(void)           { return 8; }
rt_u8 hal_scratch_get(long i)         { (void)i; return 0; }
void hal_scratch_put(long i, rt_u8 v) { (void)i; (void)v; }

void hal_panic(const char *msg)
{
    Write(Output(), (APTR)msg, (long)strlen(msg));
    Delay(100);
    exit(20);
}
