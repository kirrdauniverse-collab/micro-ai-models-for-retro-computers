/* hal_c16.c - Commodore 16 / Plus4 HAL (cc65).
 *
 * Status: skeleton, needs cc65 + hardware validation (see docs/STATUS.md).
 * The C16 (16 KB RAM) fits Class D; the Plus4 (64 KB) fits Class C.
 * Tape via the C16 kernal (same LOAD/SAVE calls as the C64, device 1);
 * the 1551 disk drive is rare - tape is the realistic source here.
 */
#include <string.h>
#include <cc65.h>
#include <cbm.h>
#include "rt_hal.h"

long hal_load_file(const char *name, rt_u8 *buf, long maxlen)
{
    int res = cbm_load(name, 8, (void *)buf); /* 1551 if present */
    if (res < 0)
        res = cbm_load(name, 1, (void *)buf); /* tape fallback */
    return res < 0 ? -1 : (long)res;
}

int hal_save_file(const char *name, const rt_u8 *buf, long len)
{
    return cbm_save(name, 1, (void *)buf, (unsigned)len) < 0 ? -1 : 0;
}

long hal_tape_load(int index, rt_u8 *buf, long maxlen)
{
    char name[2] = "0";
    name[0] = (char)('0' + index);
    {
        int res = cbm_load(name, 1, (void *)buf);
        return res < 0 ? -1 : (long)res;
    }
}

int hal_tape_save(int index, const rt_u8 *buf, long len)
{
    char name[2] = "0";
    name[0] = (char)('0' + index);
    return cbm_save(name, 1, (void *)buf, (unsigned)len) < 0 ? -1 : 0;
}

int hal_getchar(void)             { return cbm_k_chrin(); }
int hal_kbhit(void)               { return cbm_k_readst() & 0x40 ? 0 : 1; }
/* --- text area rows 5-24; rows 0-4 belong to the scratch tier ---
 * Direct TED screen output (screen codes, own cursor, own scroll); the
 * kernal would scroll all 25 lines over the data. Cell colors are left
 * as the kernal cleared them (touching TED color RAM is deferred until
 * hardware validation). Screen $0800, 40 columns. */
#define C16_TEXT_TOP 5
#define C16_COLS 40

static int c16_row = C16_TEXT_TOP;
static int c16_col = 0;

static rt_u8 *c16_scr_addr(int row, int col)
{
    return (rt_u8 *)(0x0800u + row * C16_COLS + col);
}

static rt_u8 c16_screencode(int c)
{
    c &= 0x7F;
    if (c >= 'a' && c <= 'z')
        c -= 32;
    if (c >= 32 && c < 64)
        return (rt_u8)c;
    if (c >= 64 && c < 96)
        return (rt_u8)(c - 64);
    return 32;
}

static void c16_scr_scroll(void)
{
    int row, col;
    for (row = C16_TEXT_TOP; row < 24; row++)
        for (col = 0; col < C16_COLS; col++)
            *c16_scr_addr(row, col) = *c16_scr_addr(row + 1, col);
    for (col = 0; col < C16_COLS; col++)
        *c16_scr_addr(24, col) = 32;
}

static void c16_advance(void)
{
    c16_col = 0;
    if (++c16_row > 24) {
        c16_scr_scroll();
        c16_row = 24;
    }
}

void hal_putchar(int c)
{
    if (c == '\n') {
        c16_advance();
        return;
    }
    if (c16_col > C16_COLS - 1)
        c16_advance();
    *c16_scr_addr(c16_row, c16_col) = c16_screencode(c);
    c16_col++;
}

long hal_scratch_cells(void)
{
    return 200; /* TED screen rows 0-4: $0800-$08C7 */
}

int hal_scratch_bits(void)
{
    return 8;
}

rt_u8 hal_scratch_get(long i)
{
    return *c16_scr_addr((int)(i / C16_COLS), (int)(i % C16_COLS));
}

void hal_scratch_put(long i, rt_u8 v)
{
    *c16_scr_addr((int)(i / C16_COLS), (int)(i % C16_COLS)) = v;
}
void hal_flush(void)              { }
void hal_msleep(long ms)          { msleep(ms); }
rt_u32 hal_entropy(void)          { return (rt_u32)clock() ^ 0x5A5AUL; }

int hal_list_topics(char *names, int max)
{
    (void)names; (void)max;
    return -1; /* tape topics load by index */
}

void hal_panic(const char *msg)
{
    while (*msg)
        cbm_k_bsout((unsigned char)*msg++);
    for (;;)
        ;
}
