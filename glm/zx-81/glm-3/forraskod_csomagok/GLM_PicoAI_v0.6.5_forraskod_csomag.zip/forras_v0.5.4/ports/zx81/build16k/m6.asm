;* * * * *  Small-C/Plus z88dk * * * * *
;  Version: 20070909.1
;
;	Reconstructed for the z80 Module Assembler
;
;	Module compile time: Fri Nov 20 17:01:17 2026



	MODULE	rt_chat.c

	INCLUDE "z80_crt0.hdr"



._rt_chat_init
	ld	hl,0	;const
	push	hl
	jp	i_5
.i_3
	pop	hl
	inc	hl
	push	hl
	dec	hl
.i_5
	pop	hl
	push	hl
	ld	de,8	;const
	ex	de,hl
	call	l_lt
	jp	nc,i_4
	ld	hl,8	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	pop	hl
	push	hl
	push	de
	pop	de
	add	hl,de
	ld	(hl),#(1 % 256 % 256)
	ld	l,(hl)
	ld	h,0
	jp	i_3
.i_4
	ld	hl,8	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,8
	add	hl,bc
	ld	(hl),#(0 % 256)
	inc	hl
	ld	(hl),#(0 / 256)
	ld	hl,8	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,10
	add	hl,bc
	push	hl
	ld	hl,6	;const
	add	hl,sp
	call	l_glong
	pop	bc
	call	l_plong
	ld	hl,8	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,14
	add	hl,bc
	ld	(hl),#(0 % 256)
	inc	hl
	ld	(hl),#(0 / 256)
	ld	hl,8	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,16
	add	hl,bc
	ld	(hl),#(2 % 256)
	inc	hl
	ld	(hl),#(2 / 256)
	ld	hl,8	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,18
	add	hl,bc
	ld	de,72	;const
	ex	de,hl
	call	l_pint
	pop	bc
	ret



._rt_chat_push_idx
	push	bc
	ld	hl,6	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,8
	add	hl,bc
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,8	;const
	call	l_lt
	jp	nc,i_6
	ld	hl,6	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,8	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,8
	add	hl,bc
	push	hl
	call	l_gint	;
	inc	hl
	pop	de
	call	l_pint
	dec	hl
	pop	de
	add	hl,de
	push	hl
	ld	hl,6	;const
	add	hl,sp
	ld	a,(hl)
	pop	de
	ld	(de),a
	ld	l,a
	ld	h,0
	pop	bc
	ret


.i_6
	ld	hl,1	;const
	pop	bc
	push	hl
	jp	i_9
.i_7
	pop	hl
	inc	hl
	push	hl
	dec	hl
.i_9
	pop	hl
	push	hl
	ld	de,8	;const
	ex	de,hl
	call	l_lt
	jp	nc,i_8
	ld	hl,6	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	pop	hl
	push	hl
	push	de
	dec	hl
	pop	de
	add	hl,de
	push	hl
	ld	hl,8	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,4	;const
	add	hl,sp
	call	l_gint	;
	pop	de
	add	hl,de
	ld	a,(hl)
	pop	de
	ld	(de),a
	ld	l,a
	ld	h,0
	jp	i_7
.i_8
	ld	hl,6	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,7
	add	hl,bc
	push	hl
	ld	hl,6	;const
	add	hl,sp
	ld	a,(hl)
	pop	de
	ld	(de),a
	ld	l,a
	ld	h,0
	pop	bc
	ret



._rt_chat_push
.i_10
	pop	bc
	pop	hl
	push	hl
	push	bc
	call	l_gchar
	ld	a,h
	or	l
	jp	z,i_11
	ld	hl,4	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,4	;const
	add	hl,sp
	push	hl
	call	l_gint	;
	inc	hl
	pop	de
	call	l_pint
	dec	hl
	call	l_gchar
	push	hl
	call	_rt_map_char
	pop	bc
	ld	h,0
	push	hl
	call	_rt_chat_push_idx
	pop	bc
	pop	bc
	jp	i_10
.i_11
	ret



._rt_chat_gen
	push	bc
	push	bc
	push	bc
	push	bc
	push	bc
	ld	hl,0	;const
	push	hl
	ld	hl,20	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,18
	add	hl,bc
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,3	;const
	push	hl
.i_12
	ld	hl,4	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,4	;const
	add	hl,sp
	call	l_gint	;
	pop	de
	call	l_lt
	jp	nc,i_13
	push	bc
	ld	hl,24	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,6
	add	hl,bc
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,10	;const
	add	hl,sp
	ld	de,0	;const
	ex	de,hl
	call	l_pint
	jp	i_16
.i_14
	ld	hl,10	;const
	add	hl,sp
	push	hl
	call	l_gint	;
	inc	hl
	pop	de
	call	l_pint
	dec	hl
.i_16
	ld	hl,10	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	pop	hl
	push	hl
	push	de
	pop	de
	call	l_lt
	jp	nc,i_15
	ld	hl,28	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,8
	add	hl,bc
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	pop	hl
	push	hl
	push	de
	pop	de
	ex	de,hl
	and	a
	sbc	hl,de
	ex	de,hl
	ld	hl,12-2	;const
	add	hl,sp
	call	l_gint	;
	add	hl,de
	push	hl
	ld	hl,14	;const
	add	hl,sp
	push	hl
	dec	hl
	dec	hl
	call	l_gint	;
	pop	de
	add	hl,de
	push	hl
	pop	bc
	pop	de
	push	de
	push	bc
	bit	7,d
	jp	z,i_17
	ld	hl,1	;const
	jp	i_18
.i_17
	ld	hl,32	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,4	;const
	add	hl,sp
	call	l_gint	;
	pop	de
	add	hl,de
	ld	l,(hl)
	ld	h,0
.i_18
	pop	de
	ld	a,l
	ld	(de),a
	pop	bc
	jp	i_14
.i_15
	ld	hl,26	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,14	;const
	add	hl,sp
	push	hl
	ld	hl,_rt_logits
	push	hl
	call	_rt_forward
	pop	bc
	pop	bc
	pop	bc
	ld	hl,26	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,_rt_logits
	push	hl
	ld	hl,32	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,16
	add	hl,bc
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,34	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,14
	add	hl,bc
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,36	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,10
	add	hl,bc
	push	hl
	call	_rt_sample
	pop	bc
	pop	bc
	pop	bc
	pop	bc
	pop	bc
	pop	de
	pop	bc
	push	hl
	push	de
	ld	a,h
	or	l
	jp	nz,i_19
	ld	hl,8	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,0	;const
	call	l_eq
	jp	nc,i_21
	ld	hl,4	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,0	;const
	call	l_gt
	jr	c,i_22_i_21
.i_21
	jp	i_20
.i_22_i_21
	ld	hl,4	;const
	add	hl,sp
	push	hl
	call	l_gint	;
	dec	hl
	pop	de
	call	l_pint
	inc	hl
	pop	bc
	pop	bc
	jp	i_12
.i_20
	pop	bc
	pop	bc
	jp	i_13
.i_19
	ld	hl,24	;const
	add	hl,sp
	call	l_gint	;
	ld	a,h
	or	l
	jp	z,i_23
	ld	hl,24	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	de,_RT_CHARSET
	ld	hl,6-2	;const
	add	hl,sp
	call	l_gint	;
	add	hl,de
	call	l_gchar
	ex	(sp),hl
	push	hl
	ld	hl,26	;const
	add	hl,sp
	call	l_gint	;
	ex	(sp),hl
	ld	a,2
	call	l_dcal
	pop	bc
	pop	bc
.i_23
	ld	hl,28	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,4	;const
	add	hl,sp
	call	l_gint	;
	ld	h,0
	push	hl
	call	_rt_chat_push_idx
	pop	bc
	pop	bc
	ld	hl,8	;const
	add	hl,sp
	push	hl
	call	l_gint	;
	inc	hl
	pop	de
	call	l_pint
	dec	hl
	pop	bc
	pop	bc
	jp	i_12
.i_13
	ld	hl,4	;const
	add	hl,sp
	call	l_gint	;
	exx
	ld	hl,16	;const
	add	hl,sp
	ld	sp,hl
	exx
	ret



._rt_chat_context
	push	bc
	ld	hl,8	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,8
	add	hl,bc
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	l,e
	ld	h,d
	push	hl
	ld	hl,8	;const
	add	hl,sp
	call	l_gint	;
	dec	hl
	pop	de
	call	l_gt
	jp	nc,i_24
	ld	hl,6	;const
	add	hl,sp
	call	l_gint	;
	dec	hl
	pop	bc
	push	hl
.i_24
	ld	hl,0	;const
	pop	de
	pop	bc
	push	hl
	push	de
	jp	i_27
.i_25
	pop	de
	pop	hl
	inc	hl
	push	hl
	push	de
	dec	hl
.i_27
	pop	bc
	pop	hl
	push	hl
	push	bc
	ex	de,hl
	pop	hl
	push	hl
	call	l_lt
	jp	nc,i_26
	ld	hl,8	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,4	;const
	add	hl,sp
	call	l_gint	;
	pop	de
	add	hl,de
	push	hl
	ld	hl,_RT_CHARSET
	push	hl
	ld	hl,14	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,8	;const
	add	hl,sp
	call	l_gint	;
	pop	de
	add	hl,de
	ld	l,(hl)
	ld	h,0
	pop	de
	add	hl,de
	call	l_gchar
	ld	a,l
	call	l_sxt
	pop	de
	ld	a,l
	ld	(de),a
	jp	i_25
.i_26
	ld	hl,8	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,4	;const
	add	hl,sp
	call	l_gint	;
	pop	de
	add	hl,de
	push	hl
	ld	hl,0	;const
	ld	a,l
	call	l_sxt
	pop	de
	ld	a,l
	ld	(de),a
	pop	bc
	pop	bc
	ret




; --- Start of Static Variables ---

._rt_logits	defs	192


; --- Start of Scope Defns ---

	XREF	_rt_last_hidden
	XDEF	_rt_chat_push
	XREF	_rt_forward
	XREF	_rt_charset_init
	XDEF	_rt_chat_context
	XREF	_rt_model_load
	XREF	_RT_CHARSET
	XREF	_RT_CHAR_TO_IDX
	XREF	_rt_model_size
	XREF	_rt_sample
	XDEF	_rt_chat_push_idx
	XREF	_rt_rand
	XREF	_rt_map_char
	XDEF	_rt_chat_gen
	XDEF	_rt_chat_init


; --- End of Scope Defns ---


; --- End of Compilation ---
