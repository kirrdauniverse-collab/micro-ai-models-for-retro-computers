;* * * * *  Small-C/Plus z88dk * * * * *
;  Version: 20070909.1
;
;	Reconstructed for the z80 Module Assembler
;
;	Module compile time: Fri Nov 20 17:01:17 2026



	MODULE	boot16.c

	INCLUDE "z80_crt0.hdr"



._say
.i_3
	pop	bc
	pop	hl
	push	hl
	push	bc
	call	l_gchar
	ld	a,h
	or	l
	jp	z,i_4
	pop	de
	pop	hl
	inc	hl
	push	hl
	push	de
	dec	hl
	call	l_gchar
	push	hl
	call	_hal_putchar
	pop	bc
	jp	i_3
.i_4
	ret



._say_int
	push	bc
	push	bc
	push	bc
	ld	hl,0	;const
	push	hl
	ld	hl,10	;const
	add	hl,sp
	call	l_gint	;
	xor	a
	or	h
	jp	p,i_5
	ld	hl,45	;const
	push	hl
	call	_hal_putchar
	pop	bc
	ld	hl,10	;const
	add	hl,sp
	push	hl
	ld	hl,12	;const
	add	hl,sp
	call	l_gint	;
	call	l_neg
	pop	de
	call	l_pint
.i_5
.i_8
	ld	hl,2	;const
	add	hl,sp
	push	hl
	dec	hl
	dec	hl
	push	hl
	call	l_gint	;
	inc	hl
	pop	de
	call	l_pint
	dec	hl
	pop	de
	add	hl,de
	push	hl
	ld	hl,12	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,10	;const
	call	l_div
	ex	de,hl
	ld	de,48
	add	hl,de
	ld	a,l
	call	l_sxt
	ld	a,l
	call	l_sxt
	pop	de
	ld	a,l
	ld	(de),a
	ld	hl,10	;const
	add	hl,sp
	push	hl
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,10	;const
	call	l_div
	pop	de
	call	l_pint
.i_6
	ld	hl,10	;const
	add	hl,sp
	call	l_gint	;
	ld	a,h
	or	l
	jp	nz,i_8
.i_7
.i_9
	pop	hl
	push	hl
	ld	a,h
	or	l
	jp	z,i_10
	ld	hl,2	;const
	add	hl,sp
	push	hl
	dec	hl
	dec	hl
	push	hl
	call	l_gint	;
	dec	hl
	pop	de
	call	l_pint
	pop	de
	add	hl,de
	call	l_gchar
	push	hl
	call	_hal_putchar
	pop	bc
	jp	i_9
.i_10
	pop	bc
	pop	bc
	pop	bc
	pop	bc
	ret



._getline
	ld	hl,0	;const
	push	hl
	jp	i_13
.i_11
.i_13
	call	_hal_getchar
	push	hl
	inc	hl
	ld	a,h
	or	l
	jp	nz,i_14
	pop	bc
	jp	i_11
.i_14
	pop	hl
	push	hl
	ld	de,13	;const
	ex	de,hl
	call	l_eq
	jp	nc,i_15
	ld	hl,8	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,4	;const
	add	hl,sp
	call	l_gint	;
	pop	de
	add	hl,de
	push	hl
	ld	hl,0	;const
	ld	a,l
	call	l_sxt
	pop	de
	ld	a,l
	ld	(de),a
	pop	bc
	pop	bc
	ret


.i_15
	pop	hl
	push	hl
	ld	de,32	;const
	ex	de,hl
	call	l_lt
	jp	c,i_17
	pop	hl
	push	hl
	ld	de,127	;const
	ex	de,hl
	call	l_gt
	jp	nc,i_16
.i_17
	pop	bc
	jp	i_11
.i_16
	pop	hl
	push	hl
	ld	de,65	;const
	ex	de,hl
	call	l_ge
	jp	nc,i_20
	pop	hl
	push	hl
	ld	de,90	;const
	ex	de,hl
	call	l_le
	jr	c,i_21_i_20
.i_20
	jp	i_19
.i_21_i_20
	pop	hl
	ld	bc,32
	add	hl,bc
	push	hl
.i_19
	pop	bc
	pop	hl
	push	hl
	push	bc
	push	hl
	ld	hl,8	;const
	add	hl,sp
	call	l_gint	;
	dec	hl
	pop	de
	call	l_lt
	jp	nc,i_22
	ld	hl,8	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,4	;const
	add	hl,sp
	push	hl
	call	l_gint	;
	inc	hl
	pop	de
	call	l_pint
	dec	hl
	pop	de
	add	hl,de
	push	hl
	pop	bc
	pop	hl
	push	hl
	push	bc
	ld	a,l
	call	l_sxt
	ld	a,l
	call	l_sxt
	pop	de
	ld	a,l
	ld	(de),a
.i_22
	pop	hl
	push	hl
	push	hl
	call	_hal_putchar
	pop	bc
	pop	bc
	jp	i_11
.i_12
	pop	bc
	ret



._getnum
	push	bc
	push	bc
	push	bc
	push	bc
	jp	i_25
.i_23
.i_25
	ld	hl,0	;const
	push	hl
	push	bc
	ld	hl,4	;const
	add	hl,sp
	push	hl
	ld	hl,6	;const
	push	hl
	call	_getline
	pop	bc
	pop	bc
	ld	hl,0	;const
	pop	bc
	push	hl
	jp	i_28
.i_26
	pop	hl
	inc	hl
	push	hl
	dec	hl
.i_28
	ld	hl,4	;const
	add	hl,sp
	ex	de,hl
	pop	hl
	push	hl
	add	hl,de
	call	l_gchar
	ld	a,h
	or	l
	jp	z,i_27
	ld	hl,4	;const
	add	hl,sp
	ex	de,hl
	pop	hl
	push	hl
	add	hl,de
	call	l_gchar
	ld	de,48	;const
	ex	de,hl
	call	l_lt
	jp	c,i_30
	ld	hl,4	;const
	add	hl,sp
	ex	de,hl
	pop	hl
	push	hl
	add	hl,de
	call	l_gchar
	ld	de,57	;const
	ex	de,hl
	call	l_gt
	jp	nc,i_29
.i_30
	ld	hl,16	;const
	add	hl,sp
	call	l_gint	;
	dec	hl
	pop	de
	pop	bc
	push	hl
	push	de
	jp	i_27
.i_29
	pop	bc
	pop	hl
	push	hl
	push	bc
	ld	b,h
	ld	c,l
	add	hl,hl
	add	hl,hl
	add	hl,bc
	add	hl,hl
	push	hl
	ld	hl,6	;const
	add	hl,sp
	ex	de,hl
	ld	hl,4-2	;const
	add	hl,sp
	call	l_gint	;
	add	hl,de
	call	l_gchar
	pop	de
	add	hl,de
	ld	bc,-48
	add	hl,bc
	pop	de
	pop	bc
	push	hl
	push	de
	jp	i_26
.i_27
	pop	bc
	pop	hl
	push	hl
	push	bc
	ex	de,hl
	ld	hl,18-2	;const
	add	hl,sp
	call	l_gint	;
	call	l_ge
	jp	nc,i_33
	pop	bc
	pop	hl
	push	hl
	push	bc
	ex	de,hl
	ld	hl,16-2	;const
	add	hl,sp
	call	l_gint	;
	call	l_le
	jr	c,i_34_i_33
.i_33
	jp	i_32
.i_34_i_33
	pop	bc
	pop	hl
	push	hl
	push	bc
	exx
	ld	hl,12	;const
	add	hl,sp
	ld	sp,hl
	exx
	ret


.i_32
	ld	hl,i_1+0
	push	hl
	call	_say
	pop	bc
	ld	hl,16	;const
	add	hl,sp
	call	l_gint	;
	push	hl
	call	_say_int
	pop	bc
	ld	hl,i_1+6
	push	hl
	call	_say
	pop	bc
	ld	hl,14	;const
	add	hl,sp
	call	l_gint	;
	push	hl
	call	_say_int
	pop	bc
	ld	hl,i_1+8
	push	hl
	call	_say
	pop	bc
	pop	bc
	pop	bc
	jp	i_23
.i_24
	pop	bc
	pop	bc
	pop	bc
	pop	bc
	ret


._logo
	defw	i_1+11
	defw	i_1+42
	defw	i_1+73
	defw	i_1+104
	defw	i_1+135


._logo_draw
	ld	hl,0	;const
	push	hl
	jp	i_38
.i_36
	pop	hl
	inc	hl
	push	hl
	dec	hl
.i_38
	pop	hl
	push	hl
	ld	de,3	;const
	ex	de,hl
	call	l_lt
	jp	nc,i_37
	ld	hl,i_1+9
	push	hl
	call	_say
	pop	bc
	jp	i_36
.i_37
	ld	hl,0	;const
	pop	bc
	push	hl
	jp	i_41
.i_39
	pop	hl
	inc	hl
	push	hl
	dec	hl
.i_41
	pop	hl
	push	hl
	ld	de,5	;const
	ex	de,hl
	call	l_lt
	jp	nc,i_40
	pop	hl
	push	hl
	add	hl,hl
	ld	de,_logo
	add	hl,de
	call	l_gint	;
	push	hl
	call	_say
	pop	bc
	ld	hl,i_1+9
	push	hl
	call	_say
	pop	bc
	jp	i_39
.i_40
	ld	hl,i_1+166
	push	hl
	call	_say
	pop	bc
	ld	hl,i_1+196
	push	hl
	call	_say
	pop	bc
	pop	bc
	ret


._mdays
	defm	""&31&""&28&""&31&""&30&""&31&""&30&""&31&""&31&""&30&""&31&""&30&""&31&""


._doy_calc
	push	bc
	ld	hl,4	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,0	;const
	pop	bc
	push	hl
	push	de
	jp	i_45
.i_43
	pop	de
	pop	hl
	inc	hl
	push	hl
	push	de
	dec	hl
.i_45
	pop	bc
	pop	hl
	push	hl
	push	bc
	push	hl
	ld	hl,10	;const
	add	hl,sp
	call	l_gint	;
	dec	hl
	pop	de
	call	l_lt
	jp	nc,i_44
	pop	hl
	push	hl
	push	hl
	ld	de,_mdays
	ld	hl,6-2	;const
	add	hl,sp
	call	l_gint	;
	add	hl,de
	call	l_gchar
	pop	de
	add	hl,de
	pop	bc
	push	hl
	jp	i_43
.i_44
	ld	hl,8	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,2	;const
	call	l_gt
	jp	nc,i_47
	ld	hl,10	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,4	;const
	call	l_div
	ld	hl,0	;const
	call	l_eq
	jp	nc,i_48
	ld	hl,10	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,100	;const
	call	l_div
	ld	hl,0	;const
	call	l_ne
	jp	c,i_50
.i_48
	jr	i_48_i_49
.i_49
	ld	a,h
	or	l
	jp	nz,i_50
.i_48_i_49
	ld	hl,10	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,400	;const
	call	l_div
	ld	hl,0	;const
	call	l_eq
	jp	nc,i_47
.i_50
	jr	i_52_i_47
.i_47
	jp	i_46
.i_52_i_47
	pop	hl
	inc	hl
	push	hl
	dec	hl
.i_46
	pop	hl
	pop	bc
	ret



._pack_profile
	push	bc
	push	bc
	ld	hl,0	;const
	ld	a,l
	call	l_sxt
	dec	sp
	ld	a,l
	pop	hl
	ld	l,a
	push	hl
	ld	hl,1	;const
	add	hl,sp
	ld	de,0	;const
	ex	de,hl
	call	l_pint
	jp	i_55
.i_53
	ld	hl,1	;const
	add	hl,sp
	push	hl
	call	l_gint	;
	inc	hl
	pop	de
	call	l_pint
	dec	hl
.i_55
	ld	hl,1	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,72	;const
	call	l_lt
	jp	nc,i_54
	ld	de,_buf
	ld	hl,3-2	;const
	add	hl,sp
	call	l_gint	;
	add	hl,de
	ld	(hl),#(0 % 256 % 256)
	ld	l,(hl)
	ld	h,0
	jp	i_53
.i_54
	ld	hl,_buf
	ld	(hl),#(82 % 256 % 256)
	ld	hl,_buf+1
	ld	(hl),#(84 % 256 % 256)
	ld	hl,_buf+1+1
	ld	(hl),#(50 % 256 % 256)
	ld	hl,_buf+1+1+1
	ld	(hl),#(1 % 256 % 256)
	ld	hl,1	;const
	add	hl,sp
	ld	de,0	;const
	ex	de,hl
	call	l_pint
	jp	i_58
.i_56
	ld	hl,1	;const
	add	hl,sp
	push	hl
	call	l_gint	;
	inc	hl
	pop	de
	call	l_pint
	dec	hl
.i_58
	ld	hl,1	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,8	;const
	call	l_lt
	jp	nc,i_59
	ld	de,_bname
	ld	hl,3-2	;const
	add	hl,sp
	call	l_gint	;
	add	hl,de
	call	l_gchar
	ld	a,h
	or	l
	jr	nz,i_60_i_59
.i_59
	jp	i_57
.i_60_i_59
	ld	hl,_buf
	push	hl
	ld	hl,3	;const
	add	hl,sp
	call	l_gint	;
	ld	de,4
	add	hl,de
	pop	de
	add	hl,de
	push	hl
	ld	de,_bname
	ld	hl,5-2	;const
	add	hl,sp
	call	l_gint	;
	add	hl,de
	call	l_gchar
	pop	de
	ld	a,l
	ld	(de),a
	jp	i_56
.i_57
	ld	hl,_buf+12
	push	hl
	ld	hl,_bgen
	call	l_gchar
	pop	de
	ld	a,l
	ld	(de),a
	ld	hl,_buf+13
	push	hl
	ld	hl,(_byear)
	ld	bc,-2000
	add	hl,bc
	pop	de
	ld	a,l
	ld	(de),a
	ld	hl,_buf+14
	push	hl
	ld	hl,(_bstamp)
	ld	l,h
	ld	h,0
	pop	de
	ld	a,l
	ld	(de),a
	ld	de,_buf+15
	ld	hl,(_bstamp)
	ld	a,l
	ld	(de),a
	ld	de,_buf+16
	ld	hl,(_bhour)
	ld	a,l
	ld	(de),a
	ld	de,_buf+17
	ld	hl,(_bmin)
	ld	a,l
	ld	(de),a
	ld	hl,_buf+55
	ld	(hl),#(0 % 256 % 256)
	ld	hl,_buf+56
	ld	(hl),#(0 % 256 % 256)
	ld	hl,1	;const
	add	hl,sp
	ld	de,0	;const
	ex	de,hl
	call	l_pint
	jp	i_63
.i_61
	ld	hl,1	;const
	add	hl,sp
	push	hl
	call	l_gint	;
	inc	hl
	pop	de
	call	l_pint
	dec	hl
.i_63
	ld	hl,1	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,71	;const
	call	l_lt
	jp	nc,i_62
	ld	hl,0	;const
	add	hl,sp
	push	hl
	ld	hl,2	;const
	add	hl,sp
	ld	l,(hl)
	ld	h,0
	push	hl
	ld	de,_buf
	ld	hl,7-2	;const
	add	hl,sp
	call	l_gint	;
	add	hl,de
	ld	l,(hl)
	ld	h,0
	pop	de
	call	l_xor
	pop	de
	ld	a,l
	ld	(de),a
	jp	i_61
.i_62
	ld	hl,_buf+71
	push	hl
	ld	hl,2	;const
	add	hl,sp
	ld	a,(hl)
	pop	de
	ld	(de),a
	ld	hl,3	;const
	add	hl,sp
	ld	de,0	;const
	ex	de,hl
	call	l_pint
	jp	i_66
.i_64
	ld	hl,3	;const
	add	hl,sp
	push	hl
	call	l_gint	;
	inc	hl
	pop	de
	call	l_pint
	dec	hl
.i_66
	ld	hl,3	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,24	;const
	call	l_lt
	jp	nc,i_65
	ld	hl,_buf
	push	hl
	ld	hl,5	;const
	add	hl,sp
	call	l_gint	;
	ld	b,h
	ld	c,l
	add	hl,bc
	add	hl,bc
	pop	de
	add	hl,de
	ld	l,(hl)
	ld	h,0
	ld	a,l
	call	l_sxt
	dec	sp
	ld	a,l
	pop	hl
	ld	l,a
	push	hl
	ld	hl,_buf
	push	hl
	ld	hl,6	;const
	add	hl,sp
	call	l_gint	;
	ld	b,h
	ld	c,l
	add	hl,bc
	add	hl,bc
	inc	hl
	pop	de
	add	hl,de
	ld	l,(hl)
	ld	h,0
	ld	a,l
	call	l_sxt
	dec	sp
	ld	a,l
	pop	hl
	ld	l,a
	push	hl
	ld	hl,_buf
	push	hl
	ld	hl,7	;const
	add	hl,sp
	call	l_gint	;
	ld	b,h
	ld	c,l
	add	hl,bc
	add	hl,bc
	inc	hl
	inc	hl
	pop	de
	add	hl,de
	ld	l,(hl)
	ld	h,0
	ld	a,l
	call	l_sxt
	dec	sp
	ld	a,l
	pop	hl
	ld	l,a
	push	hl
	ld	hl,6	;const
	add	hl,sp
	call	l_gint	;
	add	hl,hl
	add	hl,hl
	call	l_int2long_s
	push	de
	push	hl
	ld	hl,6	;const
	add	hl,sp
	ld	a,(hl)
	and	#(63 % 256)
	ld	l,a
	ld	h,0
	push	hl
	call	_hal_scratch_put
	pop	bc
	pop	bc
	pop	bc
	ld	hl,6	;const
	add	hl,sp
	call	l_gint	;
	add	hl,hl
	add	hl,hl
	inc	hl
	call	l_int2long_s
	push	de
	push	hl
	ld	hl,6	;const
	add	hl,sp
	ld	e,(hl)
	ld	d,0
	ld	l,#(6 % 256)
	call	l_asr_u
	push	hl
	ld	hl,7	;const
	add	hl,sp
	ld	a,(hl)
	and	#(15 % 256)
	ld	e,a
	ld	d,0
	ld	l,#(2 % 256)
	call	l_asl
	pop	de
	call	l_or
	ld	h,0
	push	hl
	call	_hal_scratch_put
	pop	bc
	pop	bc
	pop	bc
	ld	hl,6	;const
	add	hl,sp
	call	l_gint	;
	add	hl,hl
	add	hl,hl
	inc	hl
	inc	hl
	call	l_int2long_s
	push	de
	push	hl
	ld	hl,5	;const
	add	hl,sp
	ld	e,(hl)
	ld	d,0
	ld	l,#(4 % 256)
	call	l_asr_u
	ld	de,15	;const
	ex	de,hl
	call	l_and
	push	hl
	ld	hl,6	;const
	add	hl,sp
	ld	a,(hl)
	and	#(3 % 256)
	ld	e,a
	ld	d,0
	ld	l,#(4 % 256)
	call	l_asl
	pop	de
	call	l_or
	ld	h,0
	push	hl
	call	_hal_scratch_put
	pop	bc
	pop	bc
	pop	bc
	ld	hl,6	;const
	add	hl,sp
	call	l_gint	;
	add	hl,hl
	add	hl,hl
	inc	hl
	inc	hl
	inc	hl
	call	l_int2long_s
	push	de
	push	hl
	ld	hl,4	;const
	add	hl,sp
	ld	e,(hl)
	ld	d,0
	ld	l,#(2 % 256)
	call	l_asr_u
	push	hl
	call	_hal_scratch_put
	pop	bc
	pop	bc
	pop	bc
	inc	sp
	pop	bc
	jp	i_64
.i_65
	inc	sp
	pop	bc
	pop	bc
	ret



._manual
	ld	hl,i_1+228
	push	hl
	call	_say
	pop	bc
	ld	hl,i_1+246
	push	hl
	call	_say
	pop	bc
	ld	hl,i_1+279
	push	hl
	call	_say
	pop	bc
	ld	hl,i_1+321
	push	hl
	call	_say
	pop	bc
	ld	hl,i_1+365
	push	hl
	call	_say
	pop	bc
	ld	hl,i_1+408
	push	hl
	call	_say
	pop	bc
	ld	hl,i_1+455
	push	hl
	call	_say
	pop	bc
	ld	hl,i_1+492
	push	hl
	call	_say
	pop	bc
	ld	hl,i_1+532
	push	hl
	call	_say
	pop	bc
	ret



._main
	push	bc
	push	bc
	; -IXIY swap: assembles as LD IY,4000h = the ROM sysvar base
	ld ix, $4000
	call $0F2B ; SLOW: enable the continuous NMI display
	call	_logo_draw
	ld	hl,i_1+570
	push	hl
	call	_say
	pop	bc
	jp	i_69
.i_67
.i_69
	call	_hal_getchar
	push	hl
	inc	hl
	ld	a,h
	or	l
	jp	nz,i_70
	pop	bc
	jp	i_67
.i_70
	pop	hl
	push	hl
	ld	de,65	;const
	ex	de,hl
	call	l_ge
	jp	nc,i_72
	pop	hl
	push	hl
	ld	de,90	;const
	ex	de,hl
	call	l_le
	jr	c,i_73_i_72
.i_72
	jp	i_71
.i_73_i_72
	pop	hl
	ld	bc,32
	add	hl,bc
	push	hl
.i_71
	pop	hl
	push	hl
	ld	de,105	;const
	ex	de,hl
	call	l_eq
	jp	nc,i_74
	call	_manual
	pop	bc
	jp	i_68
.i_74
	pop	hl
	push	hl
	ld	de,110	;const
	ex	de,hl
	call	l_eq
	jp	nc,i_75
	pop	bc
	jp	i_68
.i_75
	pop	bc
	jp	i_67
.i_68
	ld	hl,i_1+609
	push	hl
	call	_say
	pop	bc
	ld	hl,2000	;const
	push	hl
	ld	hl,2099	;const
	push	hl
	call	_getnum
	pop	bc
	pop	bc
	ld	(_byear),hl
	ld	hl,i_1+621
	push	hl
	call	_say
	pop	bc
	ld	hl,1	;const
	push	hl
	ld	hl,12	;const
	push	hl
	call	_getnum
	pop	bc
	pop	bc
	pop	bc
	push	hl
	ld	hl,i_1+636
	push	hl
	call	_say
	pop	bc
	pop	hl
	push	hl
	ld	de,(_byear)
	push	de
	push	hl
	ld	hl,1	;const
	push	hl
	ld	hl,31	;const
	push	hl
	call	_getnum
	pop	bc
	pop	bc
	push	hl
	call	_doy_calc
	pop	bc
	pop	bc
	pop	bc
	ld	(_bdoy),hl
	ld	hl,i_1+649
	push	hl
	call	_say
	pop	bc
	ld	hl,0	;const
	push	hl
	ld	hl,23	;const
	push	hl
	call	_getnum
	pop	bc
	pop	bc
	ld	(_bhour),hl
	ld	hl,i_1+667
	push	hl
	call	_say
	pop	bc
	ld	hl,0	;const
	push	hl
	ld	hl,59	;const
	push	hl
	call	_getnum
	pop	bc
	pop	bc
	ld	(_bmin),hl
	ld	hl,i_1+681
	push	hl
	call	_say
	pop	bc
	ld	hl,_bname
	push	hl
	ld	hl,9	;const
	push	hl
	call	_getline
	pop	bc
	pop	bc
	ld	hl,i_1+689
	push	hl
	call	_say
	pop	bc
	jp	i_78
.i_76
.i_78
	call	_hal_getchar
	push	hl
	inc	hl
	ld	a,h
	or	l
	jp	nz,i_79
	pop	bc
	jp	i_76
.i_79
	pop	hl
	push	hl
	ld	de,65	;const
	ex	de,hl
	call	l_ge
	jp	nc,i_81
	pop	hl
	push	hl
	ld	de,90	;const
	ex	de,hl
	call	l_le
	jr	c,i_82_i_81
.i_81
	jp	i_80
.i_82_i_81
	pop	hl
	ld	bc,32
	add	hl,bc
	push	hl
.i_80
	pop	hl
	push	hl
	ld	de,102	;const
	ex	de,hl
	call	l_eq
	jp	c,i_84
	pop	hl
	push	hl
	ld	de,110	;const
	ex	de,hl
	call	l_eq
	jp	nc,i_83
.i_84
	pop	hl
	push	hl
	ld	a,l
	call	l_sxt
	ld	a,l
	call	l_sxt
	ld	a,l
	ld	(_bgen),a
	pop	hl
	push	hl
	push	hl
	call	_hal_putchar
	pop	bc
	pop	bc
	jp	i_77
.i_83
	pop	bc
	jp	i_76
.i_77
	ld	hl,i_1+9
	push	hl
	call	_say
	pop	bc
	ld	hl,(_byear)
	ld	bc,-2000
	add	hl,bc
	ld	de,365
	call	l_mult
	ex	de,hl
	ld	hl,(_bdoy)
	add	hl,de
	ld	(_bstamp),hl
	call	_pack_profile
	ld	hl,i_1+703
	push	hl
	call	_say
	pop	bc
	ld	hl,0	;const
	pop	de
	pop	bc
	push	hl
	push	de
	jp	i_88
.i_86
	pop	de
	pop	hl
	inc	hl
	push	hl
	push	de
	dec	hl
.i_88
	ld	de,_bname
	ld	hl,4-2	;const
	add	hl,sp
	call	l_gint	;
	add	hl,de
	call	l_gchar
	ld	a,h
	or	l
	jp	z,i_87
	ld	de,_bname
	ld	hl,4-2	;const
	add	hl,sp
	call	l_gint	;
	add	hl,de
	call	l_gchar
	push	hl
	call	_hal_putchar
	pop	bc
	jp	i_86
.i_87
	ld	hl,i_1+713
	push	hl
	call	_say
	pop	bc
	ld	hl,i_1+760
	push	hl
	call	_say
	pop	bc
	ld	hl,1	;const
	pop	bc
	pop	bc
	ret


.i_1
	defm	"??? ("&0
	defm	"-"&0
	defm	")"&13&""&0
	defm	"=...= =...= .====. =...= =...="
	defm	""&0
	defm	"=.==. =...=    =   =...= =...="
	defm	""&0
	defm	"=.==. =...=   =    =...= =...="
	defm	""&0
	defm	"=..=. =...=  =     =...= =...="
	defm	""&0
	defm	"=.==.  ===  .====.  ===.  ===."
	defm	""&0
	defm	"   retro-tinyllm 16k  v0.5.4"&13&""&0
	defm	"=============================="
	defm	""&13&""&0
	defm	""&13&"HOGYAN MUKODIK:"&13&""&0
	defm	"- irj kisbetukkel, entert nyom"
	defm	"j"&13&""&0
	defm	"- /topic: temalist es valtas ("
	defm	"szalagrol)"&13&""&0
	defm	"- SHIFT+1..4: hofok 1-4 (ulere"
	defm	"se/keverese)"&13&""&0
	defm	"- SHIFT+2 ures soron: gondolko"
	defm	"do kapcsolo"&13&""&0
	defm	"- SHIFT+5/SHIFT+0: regen elore"
	defm	"/vissza tekercs"&13&""&0
	defm	"- /save: emlekek mentese a sza"
	defm	"lagra"&13&""&0
	defm	"- /new: uj beszelgetes, /quit:"
	defm	" kilepes"&13&""&0
	defm	"- a felso sorok: a modell kont"
	defm	"exusa"&13&""&13&""&0
	defm	"Ujra itt vagyok! Utmutato kell"
	defm	"? (i/n)"&13&""&0
	defm	"Datum: ev? "&0
	defm	"honap (1-12)? "&0
	defm	"nap (1-31)? "&0
	defm	"Ido: ora (0-23)? "&0
	defm	"perc (0-59)? "&0
	defm	"Neved? "&0
	defm	"Nemed (f/n)? "&0
	defm	"Rendben, "&0
	defm	"!"&13&"Mentem a beallitasokat es to"
	defm	"ltom az alapot."&13&""&0
	defm	"Tekerj fel a szalagot a RT-BAS"
	defm	"E16 blokkra!"&13&""&0


; --- Start of Static Variables ---

._bname	defs	9
._bhour	defs	2
._byear	defs	2
._bstamp	defs	2
._bgen	defs	1
._bdoy	defs	2
._bmin	defs	2
._buf	defs	72


; --- Start of Scope Defns ---

	LIB	strcmp
	XREF	_hal_kbhit
	LIB	strcpy
	LIB	strlen
	LIB	strdup
	LIB	strrev
	LIB	strpos
	LIB	strlwr
	XREF	_hal_flush
	LIB	strtok
	LIB	strspn
	LIB	bcopy
	XREF	_hal_panic
	LIB	strstr
	LIB	strupr
	LIB	memopd_callee
	LIB	stricmp
	LIB	strncat
	LIB	strcspn
	LIB	strncmp
	LIB	strncpy
	LIB	strpbrk
	LIB	strrchr
	XREF	_hal_scratch_bits
	LIB	index
	LIB	bzero
	XDEF	_mdays
	LIB	strtok_callee
	LIB	strpos_callee
	XREF	_hal_getchar
	LIB	strcasecmp
	LIB	strrstr
	LIB	memmove
	XREF	_hal_putchar
	LIB	memswap
	LIB	strcat_callee
	LIB	strncat_callee
	LIB	strrstrip_callee
	LIB	strstrip_callee
	LIB	strcspn_callee
	LIB	strspn_callee
	LIB	memset_callee
	LIB	strrstrip
	XREF	_hal_scratch_cells
	LIB	strnicmp
	XREF	_hal_msleep
	LIB	bcmp
	LIB	memchr
	XDEF	_main
	LIB	memcmp
	XREF	_hal_scratch_get
	LIB	memcpy
	XREF	_hal_load_file
	LIB	memopd
	XDEF	_logo
	LIB	memopi
	LIB	memset
	XREF	_hal_entropy
	XREF	_hal_scratch_put
	XREF	_hal_list_topics
	LIB	strstrip
	LIB	strcpy_callee
	LIB	strncpy_callee
	LIB	memcpy_callee
	LIB	memmove_callee
	LIB	memopi_callee
	LIB	strncasecmp
	LIB	rindex
	XREF	_hal_tape_load
	LIB	strcmp_callee
	LIB	strncmp_callee
	LIB	strchr_callee
	LIB	strrchr_callee
	LIB	strstr_callee
	LIB	strrstr_callee
	LIB	stricmp_callee
	LIB	strnicmp_callee
	LIB	memchr_callee
	LIB	memcmp_callee
	LIB	memswap_callee
	XREF	_hal_tape_save
	XREF	_hal_save_file
	LIB	strpbrk_callee
	LIB	strcat
	LIB	strchr


; --- End of Scope Defns ---


; --- End of Compilation ---
