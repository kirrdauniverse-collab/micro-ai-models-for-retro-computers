# 1 "../app16.c"

# 15 "/home/z/my-project/tools/z88dk-deb/root/usr/share/z88dk/include/sys/types.h"
typedef unsigned int size_t;




typedef signed int ssize_t;




typedef unsigned long clock_t;




typedef signed int pid_t;




typedef unsigned char bool_t;




typedef long time_t;




typedef short wild_t;




typedef unsigned long fpos_t;



typedef unsigned char u8_t;
typedef unsigned short u16_t;
typedef unsigned long u32_t;

typedef char i8_t;
typedef short i16_t;
typedef long i32_t;
# 66
typedef unsigned char uchar;




typedef unsigned int uint;
# 20 "/home/z/my-project/tools/z88dk-deb/root/usr/share/z88dk/include/string.h"
extern int __LIB__ __FASTCALL__ strlen(char *);
extern char __LIB__ *strcat(char *, char *);
extern int __LIB__ strcmp(char *, char *);
extern char __LIB__ *strcpy(char *, char *);
extern char __LIB__ *strncat(char *, char *, uint);
extern int __LIB__ strncmp(char *, char *, uint);
extern char __LIB__ *strncpy(char *, char *, uint);
extern char __LIB__ __FASTCALL__ *strrev(char *);
extern char __LIB__ *strchr(unsigned char *, unsigned char);
extern char __LIB__ *strrchr(unsigned char *, unsigned char);
extern char __LIB__ *strrstrip(char *, char);
extern char __LIB__ *strstrip(char *, uint);
extern char __LIB__ *strstr(char *, char *);
extern char __LIB__ *strrstr(char *, char *);
extern char __LIB__ *strtok(char *, char *);
extern char __LIB__ *strpbrk(char *, char *);
extern int __LIB__ strpos(char *, uint);
extern int __LIB__ strcspn(char *, char *);
extern int __LIB__ strspn(char *, char *);
extern int __LIB__ stricmp(char *, char *);
extern int __LIB__ strcasecmp(char *, char *);
extern int __LIB__ strnicmp(char *, char *, uint);
extern int __LIB__ strncasecmp(char *, char *, uint);
extern char __LIB__ __FASTCALL__ *strlwr(char *);
extern char __LIB__ __FASTCALL__ *strupr(char *);

extern void __LIB__ *memset(void *, unsigned char, uint);
extern void __LIB__ *memcpy(void *, void *,uint);
extern void __LIB__ *memmove(void *, void *, uint);
extern void __LIB__ *memchr(void *, unsigned char, uint);
extern int __LIB__ memcmp(void *, void *, uint);
extern void __LIB__ *memswap(void *, void *, uint);
extern void __LIB__ *memopi(void *, void *, uint, uint);
extern void __LIB__ *memopd(void *, void *, uint, uint);

extern char __LIB__ __FASTCALL__ *strdup(char *);



extern char __LIB__ __CALLEE__ *strcat_callee(char *, char *);
extern int __LIB__ __CALLEE__ strcmp_callee(char *, char *);
extern char __LIB__ __CALLEE__ *strcpy_callee(char *, char *);
extern char __LIB__ __CALLEE__ *strncat_callee(char *, char *, uint);
extern int __LIB__ __CALLEE__ strncmp_callee(char *, char *, uint);
extern char __LIB__ __CALLEE__ *strncpy_callee(char *, char *, uint);
extern char __LIB__ __CALLEE__ *strchr_callee(unsigned char *, unsigned char);
extern char __LIB__ __CALLEE__ *strrchr_callee(unsigned char *, unsigned char);
extern char __LIB__ __CALLEE__ *strrstrip_callee(char *, char);
extern char __LIB__ __CALLEE__ *strstrip_callee(char *, uint);
extern char __LIB__ __CALLEE__ *strstr_callee(char *, char *);
extern char __LIB__ __CALLEE__ *strrstr_callee(char *, char *);
extern char __LIB__ __CALLEE__ *strtok_callee(char *, char *);
extern char __LIB__ __CALLEE__ *strpbrk_callee(char *, char *);
extern int __LIB__ __CALLEE__ strpos_callee(char *, uint);
extern int __LIB__ __CALLEE__ strcspn_callee(char *, char *);
extern int __LIB__ __CALLEE__ strspn_callee(char *, char *);
extern int __LIB__ __CALLEE__ stricmp_callee(char *, char *);
extern int __LIB__ __CALLEE__ strnicmp_callee(char *, char *, uint);

extern void __LIB__ __CALLEE__ *memset_callee(void *, unsigned char, uint);
extern void __LIB__ __CALLEE__ *memcpy_callee(void *, void *,uint);
extern void __LIB__ __CALLEE__ *memmove_callee(void *, void *, uint);
extern void __LIB__ __CALLEE__ *memchr_callee(void *, unsigned char, uint);
extern int __LIB__ __CALLEE__ memcmp_callee(void *, void *, uint);
extern void __LIB__ __CALLEE__ *memswap_callee(void *, void *, uint);
extern void __LIB__ __CALLEE__ *memopi_callee(void *, void *, uint, uint);
extern void __LIB__ __CALLEE__ *memopd_callee(void *, void *, uint, uint);
# 171
extern void __LIB__ *bzero(void *, uint);
extern int __LIB__ bcmp(void *, void *, uint);
extern void __LIB__ *bcopy(void *, void *,uint);
extern char __LIB__ *index(unsigned char *, unsigned char);
extern char __LIB__ *rindex(unsigned char *, unsigned char);
# 16 "../../../engine/rt_types.h"
typedef signed char rt_i8;
typedef unsigned char rt_u8;
typedef short rt_i16;
typedef unsigned short rt_u16;
typedef long rt_i32;
typedef unsigned long rt_u32;
# 15 "../../../engine/rt_hal.h"
long hal_load_file(const char *name, rt_u8 *buf, long maxlen);


int hal_save_file(const char *name, const rt_u8 *buf, long len);
# 23
long hal_tape_load(int index, rt_u8 *buf, long maxlen);


int hal_tape_save(int index, const rt_u8 *buf, long len);
# 31
int hal_getchar(void);
int hal_kbhit(void);
void hal_putchar(int c);
void hal_flush(void);
void hal_msleep(long ms);


rt_u32 hal_entropy(void);
# 44
int hal_list_topics(char *names, int max);
# 53
long hal_scratch_cells(void);
int hal_scratch_bits(void);
rt_u8 hal_scratch_get(long i);
void hal_scratch_put(long i, rt_u8 v);


void hal_panic(const char *msg);
# 15 "../../../engine/rt_charset.h"
extern const char RT_CHARSET[48 + 1];
extern rt_u8 RT_CHAR_TO_IDX[128];

void rt_charset_init(void);
rt_u8 rt_map_char(char c);
# 55 "../../../engine/rt_model.h"
typedef struct {
rt_u16 version, flags;
rt_u16 vocab, ctx, emb, h1, h2;
rt_u16 sh_e, sh1, sh2, sh_o, temp_sh;
} rt_hdr;

typedef struct {
rt_hdr hdr;
rt_i8 *emb;
rt_u8 *sh1;
rt_i8 *w1;
rt_u8 *sh2;
rt_i8 *w2;
rt_u8 *sho;
rt_i8 *wo;
const rt_u8 *raw;
} rt_model;
# 79
int rt_model_load(rt_model *m, const rt_u8 *buf, long len);


long rt_model_size(const rt_hdr *h);
# 7 "../../../engine/rt_chat.h"
typedef struct {
rt_u8 hist[8];
int hist_n;
rt_u32 seed;
int greedy;
int temp_sh;
int max_new;
} rt_chat;
# 19
typedef void (*rt_emit_fn)();

void rt_chat_init(rt_chat *c, rt_u32 seed);
void rt_chat_push_idx(rt_chat *c, rt_u8 idx);
void rt_chat_push(rt_chat *c, const char *s);
int rt_chat_gen(rt_chat *c, const rt_model *m, rt_emit_fn fn, void *user);
void rt_chat_context(const rt_chat *c, char *out, int maxlen);
# 12 "../../../engine/rt_engine.h"
void rt_forward(const rt_model *m, const rt_u8 *ctx, rt_i32 *logits);


void rt_last_hidden(const rt_i8 **h, int *n);


rt_u32 rt_rand(rt_u32 *seed);
# 23
int rt_sample(const rt_model *m, const rt_i32 *logits, int temp_sh,
int greedy, rt_u32 *seed);
# 92 "../app16.c"
static rt_model model;
static rt_chat chat;
static rt_u16 model_addr;


static rt_u16 namtab;
static int ring_col;
static int ring_pos;
static rt_u8 b[72];
static char uname[9];
static unsigned int now;
# 111
static rt_u8 topic_idx;
static rt_u8 pending;



static void say(const char *s)
{
while (*s)
hal_putchar(*s++);
}

static void say_int(int v)
{
char t[6];
int n = 0;

if (v < 0) {
hal_putchar('-');
v = -v;
}
do {
t[n++] = (char)('0' + v % 10);
v /= 10;
} while (v);
while (n)
hal_putchar(t[--n]);
}
# 148
static void pack_state(void)
{
#asm

ld hl,($400C)
inc hl ; HL = the first cell of row 0
ld de,_b ; DE = the source b[0..71]
ld a,3 ; 3 work rows
ps_row:
ld b,8 ; 8 groups of 3 -> 4 per row
push af
ps_grp:
push bc ; the group counter
ld a,(de)
ld c,a ; C = b0
inc de
ld a,(de)
ld b,a ; B = b1
inc de
ld a,(de)
inc de
push af ; b2 for cell2
push af ; b2 for cell3
ld a,c ; cell0 = b0 & $3F
and $3F
ld (hl),a
inc hl
ld a,c ; cell1 = (b0>>6) | ((b1&0F)<<2)
and $C0
rlca ; bits 6-7 -> bits 0-1
rlca
ld c,a
ld a,b
and $0F
add a,a
add a,a
or c
ld (hl),a
inc hl
ld a,b ; cell2 = ((b1>>4)&$0F) | ((b2&3)<<4)
and $F0
rrca
rrca
rrca
rrca
ld c,a
pop af ; b2
and $03
add a,a
add a,a
add a,a
add a,a
or c
ld (hl),a
inc hl
pop af ; b2
srl a ; cell3 = b2 >> 2
srl a
ld (hl),a
inc hl
pop bc
djnz ps_grp
inc hl ; skip the row terminator ($76)
pop af
dec a
jr nz,ps_row
ret
#endasm

}

static void unpack_state(void)
{
#asm

ld hl,($400C)
inc hl ; HL = the first cell of row 0 (the source)
ld de,_b ; DE = the target b[0..71] - NEVER clobbered
ld a,3 ; 3 work rows
pu_row:
ld b,8 ; 8 groups per row
push af
pu_grp:
push bc ; the group counter waits on the stack, so
; B and C are free as cell temporaries
ld a,(hl) ; cell0
inc hl
and $3F
ld c,a ; C = cell0
ld a,(hl) ; cell1
inc hl
and $3F
ld b,a ; B = cell1
ld a,(hl) ; cell2
inc hl
and $3F
push af ; cell2 on the stack
ld a,(hl) ; cell3
inc hl
and $3F
push af ; cell3 on the stack
; b0 = cell0 | (cell1&3)<<6
ld a,b
and $03
rrca
rrca
or c
ld (de),a
inc de
; b1 = (cell1>>2)&0F | (cell2&0F)<<4
ld a,b
and $3C
rrca
rrca
ld c,a
pop af ; cell2
and $0F
add a,a
add a,a
add a,a
add a,a
or c
ld (de),a
inc de
; b2 = (cell2>>4)&3 | cell3<<2
pop af ; cell2 again
and $30
rrca
rrca
rrca
rrca
ld c,a
pop af ; cell3
add a,a
add a,a
or c
ld (de),a
inc de
pop bc
djnz pu_grp
inc hl ; skip the row terminator ($76)
pop af
dec a
jr nz,pu_row
ret
#endasm

}

static int state_valid(void)
{
rt_u8 x = 0;
int i;

if (b[0] != 'R' || b[1] != 'T' || b[2] != '2')
return 0;
for (i = 0; i < 72 - 1; i++)
x = (rt_u8)(x ^ b[i]);
return x == b[72 - 1];
}

static void state_apply(void)
{
int i;

for (i = 0; i < 8; i++)
chat.hist[i] = b[18 + i] < 48 ? b[18 + i] : 1;
chat.hist_n = b[26] > 8 ? 8 : b[26];
chat.seed = (rt_u32)b[27] | ((rt_u32)b[28] << 8);
chat.temp_sh = b[33] < 1 ? 1 : b[33] > 4 ? 3 : b[33] - 1;
topic_idx = b[31] > 13 ? 0 : b[31];
pending = b[32] > 13 ? 0 : b[32];
}



static int model_find(void)
{
rt_u16 a, lo = 0x4090, hi = 0x7AFF;

for (a = hi; a >= lo; a--) {
if (*(rt_u8 *)a == 'R' && *(rt_u8 *)(a + 1) == 'T' &&
*(rt_u8 *)(a + 2) == 'L' && *(rt_u8 *)(a + 3) == 'M') {
if (rt_model_load(&model, (const rt_u8 *)a,
2816) == 0) {
model_addr = a;
namtab = a + 1030 + 12;
return 1;
}
}
}
return 0;
}



static void event_add(rt_u8 type)
{
int slot = b[55] % 10;

b[35 + slot * 2] = type;
b[35 + slot * 2 + 1] = (rt_u8)(now & 255);
b[55]++;
}

static int match(const char *s, const char *w)
{
int n = 0, i;

while (w[n])
n++;
for (;;) {
for (i = 0; i < n; i++)
if (s[i] != w[i])
goto next;
if (!s[n] || s[n] == ' ' || s[n] == ',' || s[n] == '.' ||
s[n] == '?' || s[n] == '!')
return 1;
next:
while (*s && *s != ' ')
s++;
if (!*s)
return 0;
s++;
}
}

static void memory_scan(const char *s)
{
if (match(s, "faj") || match(s, "fajdalom"))
event_add(1);
else if (match(s, "boldog") || match(s, "szerelmes"))
event_add(2);
else if (match(s, "szomoru") || match(s, "faradt"))
event_add(3);
}

static void recall_print(void)
{
static const char *ew[6] = {0, "faj a fejem", "orom",
"szomorusag", "faradsag", "szerelem"};
int i, newest = -1;
rt_u8 age;

for (i = 0; i < 10; i++)
if (b[35 + i * 2] &&
(newest < 0 ||
(rt_u8)(b[35 + i * 2 + 1] -
b[35 + newest * 2 + 1]) < 128))
newest = i;
if (newest < 0)
return;
age = (rt_u8)((now & 255) - b[35 + newest * 2 + 1]);
if (age > 14)
say("emlek: mar elmult\n");
else {
say("emlek: ");
say(ew[b[35 + newest * 2]]);
say(" (");
say_int(age);
say(" napja)\n");
}
}



static void poke_load_name(rt_u8 topic)
{
#asm

ld hl,2
add hl,sp
ld a,(hl) ; topic number
ld hl,(_namtab) ; the name table (the C computed it)
ld c,a
ld a,(hl) ; magic
cp $A1
ret nz
inc hl
ld a,(hl) ; count
cp c
ret c ; topic > count: leave line 2 untouched
dec c
ld b,$00
ld a,c
add a,a
add a,a
add a,a ; (topic-1)*8
ld c,a
inc hl ; first name byte
add hl,bc ; hl = names + (topic-1)*8
ex de,hl ; de = the source
ld hl,($407F) ; line-1 body length
ld bc,$4085
add hl,bc ; hl = the first body byte of line 2
ld b,$20
pkn2:
ld a,(hl)
cp $EF ; the LOAD token
jr z,pkn3
inc hl
djnz pkn2
ret ; no LOAD in line 2: leave it untouched
pkn3:
inc hl ; skip the quote: hl = the 8-char slot
ld b,$08
pkn1:
ld a,(de)
ld (hl),a
inc hl
inc de
djnz pkn1
ret
#endasm

}



static void page_show(void)
{
int i, c;
char row[33];

row[32] = 0;
for (i = 0; i < 5; i++) {
int base = (ring_pos / 32) * 32;
int src = (base + i * 32) % 160;

for (c = 0; c < 32; c++) {
rt_u8 v = hal_scratch_get(96 +
((src + c) % 160));
row[c] = RT_CHARSET[v < 48 ? v : 0];
}
for (c = 0; c < 32; c++)
hal_scratch_char((8 + i) * 32 + c, row[c]);
}
}

static void emit(char c, void *user)
{
(void)user;
hal_putchar(c);
if (ring_col >= 0) {
if (c == '\n') {
while (ring_col < 32) {
hal_scratch_put(96 + ring_pos, ' ');
ring_pos++;
ring_col++;
}
ring_col = 0;
} else if (ring_col < 32) {
hal_scratch_put(96 + ring_pos, (rt_u8)c);
ring_pos = (ring_pos + 1) % 160;
ring_col++;
}
}
hal_flush();
}
# 504
static int eq_cmd(const char *line, const char *cmd)
{
int i = 1;

while (*cmd) {
if (line[i] != *cmd)
return 0;
i++;
cmd++;
}
return line[i] == 0 || line[i] == ' ';
}
# 519
static void silent_emit(char c, void *user)
{
(void)user;
(void)c;
}



static char line[40];

static int getline(void)
{
int n = 0, c;

for (;;) {
c = hal_getchar();
if (c < 0)
continue;
if (c == '\n' || c == '\r') {
line[n] = 0;
return n;
}
if (c == 0x1E || c == 0x1F) {
page_show();
continue;
}
if (n == 0) {
if (c >= 0x11 && c <= 0x14) {
b[33] = (rt_u8)(c - 0x11 + 1);
if (b[33] > 4)
b[33] = 4;
chat.temp_sh = b[33] - 1;
say("hofok: ");
say_int(b[33]);
say("\n");
continue;
}
if (c == '"') {
b[34] = b[34] ? 0 : 1;
say(b[34] ? "gondolkodom\n" : "gyors valasz\n");
continue;
}
}
if (c == 0x12) {
if (n) {
n--;
hal_putchar(8);
}
continue;
}
if (c < ' ' || c > 0x7F)
continue;
if (c >= 'A' && c <= 'Z')
c += 32;
if (n < 38)
line[n++] = (char)c;
hal_putchar(c);
}
}



static void gen_reply(void)
{
if (b[34]) {
chat.greedy = 1;
rt_chat_gen(&chat, &model, silent_emit, 0);
chat.greedy = 0;
}
rt_chat_gen(&chat, &model, emit, 0);
if (ring_col) {
while (ring_col < 32) {
hal_scratch_put(96 + ring_pos, ' ');
ring_pos = (ring_pos + 1) % 160;
ring_col++;
}
ring_col = 0;
}
}



static void state_default(void)
{
int i;

for (i = 0; i < 72; i++)
b[i] = 0;
b[0] = 'R';
b[1] = 'T';
b[2] = '2';
b[3] = 2;
b[33] = 2;
}

int main(void)
{
int restored, i;
char cmd;
#asm
# 624
; -IXIY swap: assembles as LD IY,4000h = the ROM sysvar base
ld ix, $4000
call $0F2B ; SLOW: enable the continuous NMI display
#endasm


rt_charset_init();
# 636
unpack_state();
restored = 0;
if (state_valid()) {
restored = 1;
if (b[56] == 2) {
b[56] = 0;
pack_state();
return 2;
}
state_apply();
} else {
state_default();
}

if (model_find() == 0) {
say("no model! dfile=");
say_int((int)(*(rt_u16 *)0x400C));
say("\nbad cassette\n");
return 0;
}
{
rt_u8 tag = *(rt_u8 *)(model_addr + 1030);

if (tag > 13)
tag = 0;
topic_idx = tag;
b[31] = tag;
}

for (i = 0; i < 8; i++)
uname[i] = (b[4 + i] == 0) ? ' ' : b[4 + i];
uname[8] = 0;
now = ((unsigned int)b[14] << 8) | b[15];

ring_col = 0;
ring_pos = 0;

say("tinyllm v0.5.4\n");
if (uname[0] != ' ')
recall_print();
else
say("udv! /help\n");

for (;;) {
int n;

say("you> ");
hal_flush();
n = getline();
say("\n");
if (n == 0)
continue;
memory_scan(line);
if (line[0] == '/') {
cmd = line[1];
if (line[1] == 'h' && line[2] == 'e') {
say("/topic /save /new /quit\n");
say("SHIFT 1-4 hofok, 9 gondolkodo, 5/0 regen\n");
} else if (cmd == 't' && line[2] == 'o' &&
line[6] == ' ' && line[7] == 0) {
for (i = 1; i <= 13; i++) {
say_int(i);
say(" ");
}
say("\n1 tud 2 elet 3 hobbi 4 egesz 5 munka\n");
say("6 muvesz 7 tanul 8 irod 9 film 10 prog\n");
say("11 csill 12 rajz 13 vers\n");
} else if (cmd == 't' && line[7] >= '1' &&
line[7] <= '9') {
rt_u8 t = (rt_u8)(line[7] - '0');

if (t > 13)
t = 13;
pending = t;
poke_load_name(t);
pack_state();
say("toltom a temat...\n");
return 1;
} else if (cmd == 's') {
pack_state();
# 718
b[56] = 2;
pack_state();
say("tekerj a RTBASE16-ra es mentsd!\n");
return 2;
} else if (cmd == 'n') {
chat.hist_n = 0;
b[26] = 0;
pack_state();
say("uj beszelgetes.\n");
} else if (cmd == 'q') {
pack_state();
return 0;
} else {
say("???\n");
}
continue;
}
rt_chat_push(&chat, line);
gen_reply();
hal_putchar('\n');
# 740
pack_state();
}
}
