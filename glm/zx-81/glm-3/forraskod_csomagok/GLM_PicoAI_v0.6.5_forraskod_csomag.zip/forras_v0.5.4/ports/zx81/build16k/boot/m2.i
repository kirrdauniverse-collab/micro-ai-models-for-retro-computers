# 1 "../../boot16.c"

# 15 "/home/z/my-project/tools/z88dk-deb/root/usr/share/z88dk/include/sys/types.h"
typedef unsigned int size_t;




typedef signed int ssize_t;




typedef unsigned long clock_t;




typedef signed int pid_t;




typedef unsigned char bool_t;




typedef long time_t;




typedef short wild_t;




typedef unsigned long fpos_t;



typedef unsigned char u8_t;
typedef unsigned short u16_t;
typedef unsigned long u32_t;

typedef char i8_t;
typedef short i16_t;
typedef long i32_t;
# 66
typedef unsigned char uchar;




typedef unsigned int uint;
# 20 "/home/z/my-project/tools/z88dk-deb/root/usr/share/z88dk/include/string.h"
extern int __LIB__ __FASTCALL__ strlen(char *);
extern char __LIB__ *strcat(char *, char *);
extern int __LIB__ strcmp(char *, char *);
extern char __LIB__ *strcpy(char *, char *);
extern char __LIB__ *strncat(char *, char *, uint);
extern int __LIB__ strncmp(char *, char *, uint);
extern char __LIB__ *strncpy(char *, char *, uint);
extern char __LIB__ __FASTCALL__ *strrev(char *);
extern char __LIB__ *strchr(unsigned char *, unsigned char);
extern char __LIB__ *strrchr(unsigned char *, unsigned char);
extern char __LIB__ *strrstrip(char *, char);
extern char __LIB__ *strstrip(char *, uint);
extern char __LIB__ *strstr(char *, char *);
extern char __LIB__ *strrstr(char *, char *);
extern char __LIB__ *strtok(char *, char *);
extern char __LIB__ *strpbrk(char *, char *);
extern int __LIB__ strpos(char *, uint);
extern int __LIB__ strcspn(char *, char *);
extern int __LIB__ strspn(char *, char *);
extern int __LIB__ stricmp(char *, char *);
extern int __LIB__ strcasecmp(char *, char *);
extern int __LIB__ strnicmp(char *, char *, uint);
extern int __LIB__ strncasecmp(char *, char *, uint);
extern char __LIB__ __FASTCALL__ *strlwr(char *);
extern char __LIB__ __FASTCALL__ *strupr(char *);

extern void __LIB__ *memset(void *, unsigned char, uint);
extern void __LIB__ *memcpy(void *, void *,uint);
extern void __LIB__ *memmove(void *, void *, uint);
extern void __LIB__ *memchr(void *, unsigned char, uint);
extern int __LIB__ memcmp(void *, void *, uint);
extern void __LIB__ *memswap(void *, void *, uint);
extern void __LIB__ *memopi(void *, void *, uint, uint);
extern void __LIB__ *memopd(void *, void *, uint, uint);

extern char __LIB__ __FASTCALL__ *strdup(char *);



extern char __LIB__ __CALLEE__ *strcat_callee(char *, char *);
extern int __LIB__ __CALLEE__ strcmp_callee(char *, char *);
extern char __LIB__ __CALLEE__ *strcpy_callee(char *, char *);
extern char __LIB__ __CALLEE__ *strncat_callee(char *, char *, uint);
extern int __LIB__ __CALLEE__ strncmp_callee(char *, char *, uint);
extern char __LIB__ __CALLEE__ *strncpy_callee(char *, char *, uint);
extern char __LIB__ __CALLEE__ *strchr_callee(unsigned char *, unsigned char);
extern char __LIB__ __CALLEE__ *strrchr_callee(unsigned char *, unsigned char);
extern char __LIB__ __CALLEE__ *strrstrip_callee(char *, char);
extern char __LIB__ __CALLEE__ *strstrip_callee(char *, uint);
extern char __LIB__ __CALLEE__ *strstr_callee(char *, char *);
extern char __LIB__ __CALLEE__ *strrstr_callee(char *, char *);
extern char __LIB__ __CALLEE__ *strtok_callee(char *, char *);
extern char __LIB__ __CALLEE__ *strpbrk_callee(char *, char *);
extern int __LIB__ __CALLEE__ strpos_callee(char *, uint);
extern int __LIB__ __CALLEE__ strcspn_callee(char *, char *);
extern int __LIB__ __CALLEE__ strspn_callee(char *, char *);
extern int __LIB__ __CALLEE__ stricmp_callee(char *, char *);
extern int __LIB__ __CALLEE__ strnicmp_callee(char *, char *, uint);

extern void __LIB__ __CALLEE__ *memset_callee(void *, unsigned char, uint);
extern void __LIB__ __CALLEE__ *memcpy_callee(void *, void *,uint);
extern void __LIB__ __CALLEE__ *memmove_callee(void *, void *, uint);
extern void __LIB__ __CALLEE__ *memchr_callee(void *, unsigned char, uint);
extern int __LIB__ __CALLEE__ memcmp_callee(void *, void *, uint);
extern void __LIB__ __CALLEE__ *memswap_callee(void *, void *, uint);
extern void __LIB__ __CALLEE__ *memopi_callee(void *, void *, uint, uint);
extern void __LIB__ __CALLEE__ *memopd_callee(void *, void *, uint, uint);
# 171
extern void __LIB__ *bzero(void *, uint);
extern int __LIB__ bcmp(void *, void *, uint);
extern void __LIB__ *bcopy(void *, void *,uint);
extern char __LIB__ *index(unsigned char *, unsigned char);
extern char __LIB__ *rindex(unsigned char *, unsigned char);
# 16 "../../../../engine/rt_types.h"
typedef signed char rt_i8;
typedef unsigned char rt_u8;
typedef short rt_i16;
typedef unsigned short rt_u16;
typedef long rt_i32;
typedef unsigned long rt_u32;
# 15 "../../../../engine/rt_hal.h"
long hal_load_file(const char *name, rt_u8 *buf, long maxlen);


int hal_save_file(const char *name, const rt_u8 *buf, long len);
# 23
long hal_tape_load(int index, rt_u8 *buf, long maxlen);


int hal_tape_save(int index, const rt_u8 *buf, long len);
# 31
int hal_getchar(void);
int hal_kbhit(void);
void hal_putchar(int c);
void hal_flush(void);
void hal_msleep(long ms);


rt_u32 hal_entropy(void);
# 44
int hal_list_topics(char *names, int max);
# 53
long hal_scratch_cells(void);
int hal_scratch_bits(void);
rt_u8 hal_scratch_get(long i);
void hal_scratch_put(long i, rt_u8 v);


void hal_panic(const char *msg);
# 38 "../../boot16.c"
static char bname[9];
static char bgen;
static int byear, bdoy, bhour, bmin;
static unsigned int bstamp;



static void say(const char *s)
{
while (*s)
hal_putchar(*s++);
}

static void say_int(int v)
{
char b[6];
int n = 0;

if (v < 0) {
hal_putchar('-');
v = -v;
}
do {
b[n++] = (char)('0' + v % 10);
v /= 10;
} while (v);
while (n)
hal_putchar(b[--n]);
}



static void getline(char *buf, int max)
{
int n = 0;

for (;;) {
int c = hal_getchar();
if (c == -1)
continue;
if (c == '\n') {
buf[n] = 0;
return;
}
if (c < ' ' || c > 0x7F)
continue;
if (c >= 'A' && c <= 'Z')
c += 32;
if (n < max - 1)
buf[n++] = (char)c;
hal_putchar(c);
}
}


static int getnum(int lo, int hi)
{
char buf[8];

for (;;) {
int v = 0, i;

getline(buf, 6);
for (i = 0; buf[i]; i++) {
if (buf[i] < '0' || buf[i] > '9') {
v = lo - 1;
break;
}
v = v * 10 + buf[i] - '0';
}
if (v >= lo && v <= hi)
return v;
say("??? (");
say_int(lo);
say("-");
say_int(hi);
say(")\n");
}
}



static const char *logo[5] = {
"=...= =...= .====. =...= =...=",
"=.==. =...=    =   =...= =...=",
"=.==. =...=   =    =...= =...=",
"=..=. =...=  =     =...= =...=",
"=.==.  ===  .====.  ===.  ===.",
};

static void logo_draw(void)
{
int i;

for (i = 0; i < 3; i++)
say("\n");
for (i = 0; i < 5; i++) {
say(logo[i]);
say("\n");
}
say("   retro-tinyllm 16k  v0.5.4\n");
say("==============================\n");
}



static const char mdays[12] = {31, 28, 31, 30, 31, 30,
31, 31, 30, 31, 30, 31};

static int doy_calc(int y, int m, int d)
{
int i, n = d;

for (i = 0; i < m - 1; i++)
n += mdays[i];
if (m > 2 && ((y % 4 == 0 && y % 100 != 0) || y % 400 == 0))
n++;
return n;
}



static rt_u8 buf[72];

static void pack_profile(void)
{
int c, i;
rt_u8 x = 0;

for (i = 0; i < 72; i++)
buf[i] = 0;
buf[0] = 'R';
buf[1] = 'T';
buf[2] = '2';
buf[3] = 1;
for (i = 0; i < 8 && bname[i]; i++)
buf[4 + i] = (rt_u8)bname[i];
buf[12] = (rt_u8)bgen;
buf[13] = (rt_u8)(byear - 2000);
buf[14] = (rt_u8)(bstamp >> 8);
buf[15] = (rt_u8)(bstamp & 255);
buf[16] = (rt_u8)bhour;
buf[17] = (rt_u8)bmin;

buf[55] = 0;
buf[56] = 0;
for (i = 0; i < 72 - 1; i++)
x = (rt_u8)(x ^ buf[i]);
buf[72 - 1] = x;
# 190
for (c = 0; c < 24; c++) {
rt_u8 b0 = buf[c * 3], b1 = buf[c * 3 + 1], b2 = buf[c * 3 + 2];

hal_scratch_put(c * 4 + 0, b0 & 0x3F);
hal_scratch_put(c * 4 + 1,
(rt_u8)((b0 >> 6) | ((b1 & 0x0F) << 2)));
hal_scratch_put(c * 4 + 2,
(rt_u8)(((b1 >> 4) & 0x0F) | ((b2 & 0x03) << 4)));
hal_scratch_put(c * 4 + 3, b2 >> 2);
}
}



static void manual(void)
{
say("\nHOGYAN MUKODIK:\n");
say("- irj kisbetukkel, entert nyomj\n");
say("- /topic: temalist es valtas (szalagrol)\n");
say("- SHIFT+1..4: hofok 1-4 (ulerese/keverese)\n");
say("- SHIFT+2 ures soron: gondolkodo kapcsolo\n");
say("- SHIFT+5/SHIFT+0: regen elore/vissza tekercs\n");
say("- /save: emlekek mentese a szalagra\n");
say("- /new: uj beszelgetes, /quit: kilepes\n");
say("- a felso sorok: a modell kontexusa\n\n");
}

void main(void)
{
int i, m;
#asm
# 229
; -IXIY swap: assembles as LD IY,4000h = the ROM sysvar base
ld ix, $4000
call $0F2B ; SLOW: enable the continuous NMI display
#endasm


logo_draw();
say("Ujra itt vagyok! Utmutato kell? (i/n)\n");
for (;;) {
int c = hal_getchar();
if (c == -1)
continue;
if (c >= 'A' && c <= 'Z')
c += 32;
if (c == 'i') {
manual();
break;
}
if (c == 'n')
break;
}

say("Datum: ev? ");
byear = getnum(2000, 2099);
say("honap (1-12)? ");
m = getnum(1, 12);
say("nap (1-31)? ");
bdoy = doy_calc(byear, m, getnum(1, 31));
say("Ido: ora (0-23)? ");
bhour = getnum(0, 23);
say("perc (0-59)? ");
bmin = getnum(0, 59);
say("Neved? ");
getline(bname, 9);
say("Nemed (f/n)? ");
for (;;) {
int c = hal_getchar();
if (c == -1)
continue;
if (c >= 'A' && c <= 'Z')
c += 32;
if (c == 'f' || c == 'n') {
bgen = (char)c;
hal_putchar(c);
break;
}
}
say("\n");

bstamp = (unsigned int)((byear - 2000) * 365 + bdoy);
pack_profile();

say("Rendben, ");
for (i = 0; bname[i]; i++)
hal_putchar(bname[i]);
say("!\nMentem a beallitasokat es toltom az alapot.\n");
say("Tekerj fel a szalagot a RT-BASE16 blokkra!\n");


return 1;
}
