#ifndef _STDDEF_H
#define _STDDEF_H
#if !defined(_SIZE_T) && !defined(_SIZE_T_DEFINED)
#define _SIZE_T
#define _SIZE_T_DEFINED
typedef unsigned int size_t;
#endif
#ifndef NULL
#define NULL ((void *)0)
#endif
#endif
