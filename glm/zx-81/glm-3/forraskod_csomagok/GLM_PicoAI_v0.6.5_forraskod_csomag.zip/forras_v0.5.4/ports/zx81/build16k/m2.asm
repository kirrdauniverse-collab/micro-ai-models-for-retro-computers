;* * * * *  Small-C/Plus z88dk * * * * *
;  Version: 20070909.1
;
;	Reconstructed for the z80 Module Assembler
;
;	Module compile time: Fri Nov 20 17:01:17 2026



	MODULE	app16.c

	INCLUDE "z80_crt0.hdr"



._say
.i_3
	pop	bc
	pop	hl
	push	hl
	push	bc
	call	l_gchar
	ld	a,h
	or	l
	jp	z,i_4
	pop	de
	pop	hl
	inc	hl
	push	hl
	push	de
	dec	hl
	call	l_gchar
	push	hl
	call	_hal_putchar
	pop	bc
	jp	i_3
.i_4
	ret



._say_int
	push	bc
	push	bc
	push	bc
	ld	hl,0	;const
	push	hl
	ld	hl,10	;const
	add	hl,sp
	call	l_gint	;
	xor	a
	or	h
	jp	p,i_5
	ld	hl,45	;const
	push	hl
	call	_hal_putchar
	pop	bc
	ld	hl,10	;const
	add	hl,sp
	push	hl
	ld	hl,12	;const
	add	hl,sp
	call	l_gint	;
	call	l_neg
	pop	de
	call	l_pint
.i_5
.i_8
	ld	hl,2	;const
	add	hl,sp
	push	hl
	dec	hl
	dec	hl
	push	hl
	call	l_gint	;
	inc	hl
	pop	de
	call	l_pint
	dec	hl
	pop	de
	add	hl,de
	push	hl
	ld	hl,12	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,10	;const
	call	l_div
	ex	de,hl
	ld	de,48
	add	hl,de
	ld	a,l
	call	l_sxt
	ld	a,l
	call	l_sxt
	pop	de
	ld	a,l
	ld	(de),a
	ld	hl,10	;const
	add	hl,sp
	push	hl
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,10	;const
	call	l_div
	pop	de
	call	l_pint
.i_6
	ld	hl,10	;const
	add	hl,sp
	call	l_gint	;
	ld	a,h
	or	l
	jp	nz,i_8
.i_7
.i_9
	pop	hl
	push	hl
	ld	a,h
	or	l
	jp	z,i_10
	ld	hl,2	;const
	add	hl,sp
	push	hl
	dec	hl
	dec	hl
	push	hl
	call	l_gint	;
	dec	hl
	pop	de
	call	l_pint
	pop	de
	add	hl,de
	call	l_gchar
	push	hl
	call	_hal_putchar
	pop	bc
	jp	i_9
.i_10
	pop	bc
	pop	bc
	pop	bc
	pop	bc
	ret



._pack_state
	ld hl,($400C)
	inc hl ; HL = the first cell of row 0
	ld de,_b ; DE = the source b[0..71]
	ld a,3 ; 3 work rows
	ps_row:
	ld b,8 ; 8 groups of 3 -> 4 per row
	push af
	ps_grp:
	push bc ; the group counter
	ld a,(de)
	ld c,a ; C = b0
	inc de
	ld a,(de)
	ld b,a ; B = b1
	inc de
	ld a,(de)
	inc de
	push af ; b2 for cell2
	push af ; b2 for cell3
	ld a,c ; cell0 = b0 & $3F
	and $3F
	ld (hl),a
	inc hl
	ld a,c ; cell1 = (b0>>6) | ((b1&0F)<<2)
	and $C0
	rlca ; bits 6-7 -> bits 0-1
	rlca
	ld c,a
	ld a,b
	and $0F
	add a,a
	add a,a
	or c
	ld (hl),a
	inc hl
	ld a,b ; cell2 = ((b1>>4)&$0F) | ((b2&3)<<4)
	and $F0
	rrca
	rrca
	rrca
	rrca
	ld c,a
	pop af ; b2
	and $03
	add a,a
	add a,a
	add a,a
	add a,a
	or c
	ld (hl),a
	inc hl
	pop af ; b2
	srl a ; cell3 = b2 >> 2
	srl a
	ld (hl),a
	inc hl
	pop bc
	djnz ps_grp
	inc hl ; skip the row terminator ($76)
	pop af
	dec a
	jr nz,ps_row
	ret
	ret



._unpack_state
	ld hl,($400C)
	inc hl ; HL = the first cell of row 0 (the source)
	ld de,_b ; DE = the target b[0..71] - NEVER clobbered
	ld a,3 ; 3 work rows
	pu_row:
	ld b,8 ; 8 groups per row
	push af
	pu_grp:
	push bc ; the group counter waits on the stack, so
	; B and C are free as cell temporaries
	ld a,(hl) ; cell0
	inc hl
	and $3F
	ld c,a ; C = cell0
	ld a,(hl) ; cell1
	inc hl
	and $3F
	ld b,a ; B = cell1
	ld a,(hl) ; cell2
	inc hl
	and $3F
	push af ; cell2 on the stack
	ld a,(hl) ; cell3
	inc hl
	and $3F
	push af ; cell3 on the stack
	; b0 = cell0 | (cell1&3)<<6
	ld a,b
	and $03
	rrca
	rrca
	or c
	ld (de),a
	inc de
	; b1 = (cell1>>2)&0F | (cell2&0F)<<4
	ld a,b
	and $3C
	rrca
	rrca
	ld c,a
	pop af ; cell2
	and $0F
	add a,a
	add a,a
	add a,a
	add a,a
	or c
	ld (de),a
	inc de
	; b2 = (cell2>>4)&3 | cell3<<2
	pop af ; cell2 again
	and $30
	rrca
	rrca
	rrca
	rrca
	ld c,a
	pop af ; cell3
	add a,a
	add a,a
	or c
	ld (de),a
	inc de
	pop bc
	djnz pu_grp
	inc hl ; skip the row terminator ($76)
	pop af
	dec a
	jr nz,pu_row
	ret
	ret



._state_valid
	ld	hl,0	;const
	ld	a,l
	call	l_sxt
	dec	sp
	ld	a,l
	pop	hl
	ld	l,a
	push	hl
	push	bc
	ld	a,(_b)
	cp	#(82 % 256)
	jp	nz,i_12
	ld	a,(_b+1)
	cp	#(84 % 256)
	jp	nz,i_12
	ld	a,(_b+1+1)
	cp	#(50 % 256)
	jp	z,i_11
.i_12
	ld	hl,0	;const
	inc	sp
	pop	bc
	ret


.i_11
	ld	hl,0	;const
	pop	bc
	push	hl
	jp	i_16
.i_14
	pop	hl
	inc	hl
	push	hl
	dec	hl
.i_16
	pop	hl
	push	hl
	ld	de,71	;const
	ex	de,hl
	call	l_lt
	jp	nc,i_15
	ld	hl,2	;const
	add	hl,sp
	push	hl
	ld	hl,4	;const
	add	hl,sp
	ld	l,(hl)
	ld	h,0
	push	hl
	ld	de,_b
	ld	hl,6-2	;const
	add	hl,sp
	call	l_gint	;
	add	hl,de
	ld	l,(hl)
	ld	h,0
	pop	de
	call	l_xor
	pop	de
	ld	a,l
	ld	(de),a
	jp	i_14
.i_15
	ld	hl,2	;const
	add	hl,sp
	ld	e,(hl)
	ld	d,0
	ld	hl,(_b+71)
	ld	h,0
	call	l_eq
	ld	hl,0	;const
	rl	l
	inc	sp
	pop	bc
	ret



._state_apply
	ld	hl,0	;const
	push	hl
	jp	i_19
.i_17
	pop	hl
	inc	hl
	push	hl
	dec	hl
.i_19
	pop	hl
	push	hl
	ld	de,8	;const
	ex	de,hl
	call	l_lt
	jp	nc,i_18
	ld	hl,_chat
	ex	de,hl
	pop	hl
	push	hl
	add	hl,de
	push	hl
	ld	hl,_b
	push	hl
	ld	hl,4	;const
	add	hl,sp
	call	l_gint	;
	ld	de,18
	add	hl,de
	pop	de
	add	hl,de
	ld	a,(hl)
	cp	#(48 % 256)
	jp	z,i_20
	jp	nc,i_20
	ld	hl,_b
	push	hl
	ld	hl,4	;const
	add	hl,sp
	call	l_gint	;
	ld	de,18
	add	hl,de
	pop	de
	add	hl,de
	ld	l,(hl)
	ld	h,0
	jp	i_21
.i_20
	ld	hl,1	;const
.i_21
	pop	de
	ld	a,l
	ld	(de),a
	jp	i_17
.i_18
	ld	hl,_chat+8
	push	hl
	ld	a,(_b+26)
	cp	#(8 % 256)
	jp	z,i_22
	jp	c,i_22
	ld	hl,8	;const
	jp	i_23
.i_22
	ld	hl,(_b+26)
	ld	h,0
.i_23
	pop	de
	call	l_pint
	ld	hl,_chat+10
	push	hl
	ld	hl,(_b+27)
	ld	h,0
	ld	de,0
	push	de
	push	hl
	ld	hl,(_b+28)
	ld	h,0
	ld	de,0
	ld	a,#(8 % 256)
	call	l_long_aslo
	call	l_long_or
	pop	bc
	call	l_plong
	ld	hl,_chat+16
	push	hl
	ld	a,(_b+33)
	cp	#(1 % 256)
	jp	z,i_24
	jp	nc,i_24
	ld	hl,1	;const
	jp	i_25
.i_24
	ld	a,(_b+33)
	cp	#(4 % 256)
	jp	z,i_26
	jp	c,i_26
	ld	hl,3	;const
	jp	i_27
.i_26
	ld	hl,(_b+33)
	ld	h,0
	dec	hl
.i_27
.i_25
	pop	de
	call	l_pint
	ld	a,(_b+31)
	cp	#(13 % 256)
	jp	z,i_28
	jp	c,i_28
	ld	hl,0	;const
	jp	i_29
.i_28
	ld	hl,(_b+31)
	ld	h,0
.i_29
	ld	h,0
	ld	a,l
	ld	(_topic_idx),a
	ld	a,(_b+32)
	cp	#(13 % 256)
	jp	z,i_30
	jp	c,i_30
	ld	hl,0	;const
	jp	i_31
.i_30
	ld	hl,(_b+32)
	ld	h,0
.i_31
	ld	h,0
	ld	a,l
	ld	(_pending),a
	pop	bc
	ret



._model_find
	push	bc
	ld	hl,16528	;const
	push	hl
	ld	hl,31487	;const
	push	hl
	ld	hl,4	;const
	add	hl,sp
	ex	de,hl
	pop	hl
	push	hl
	call	l_pint
	jp	i_34
.i_32
	ld	hl,4	;const
	add	hl,sp
	push	hl
	call	l_gint	;
	dec	hl
	pop	de
	call	l_pint
	inc	hl
.i_34
	ld	hl,4	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,4	;const
	add	hl,sp
	call	l_gint	;
	pop	de
	call	l_uge
	jp	nc,i_33
	ld	hl,4	;const
	add	hl,sp
	call	l_gint	;
	ld	a,(hl)
	cp	#(82 % 256)
	jp	nz,i_36
	ld	hl,4	;const
	add	hl,sp
	call	l_gint	;
	inc	hl
	ld	a,(hl)
	cp	#(84 % 256)
	jp	nz,i_36
	ld	hl,4	;const
	add	hl,sp
	call	l_gint	;
	inc	hl
	inc	hl
	ld	a,(hl)
	cp	#(76 % 256)
	jp	nz,i_36
	ld	hl,4	;const
	add	hl,sp
	call	l_gint	;
	inc	hl
	inc	hl
	inc	hl
	ld	a,(hl)
	cp	#(77 % 256)
	jr	z,i_37_i_36
.i_36
	jp	i_35
.i_37_i_36
	ld	hl,_model
	push	hl
	ld	hl,6	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,2816	;const
	call	l_int2long_s
	push	de
	push	hl
	call	_rt_model_load
	pop	bc
	pop	bc
	pop	bc
	pop	bc
	ld	a,h
	or	l
	jp	nz,i_38
	ld	hl,4	;const
	add	hl,sp
	call	l_gint	;
	ld	(_model_addr),hl
	ld	hl,4	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,1030+(12)
	add	hl,bc
	ld	(_namtab),hl
	ld	hl,1	;const
	pop	bc
	pop	bc
	pop	bc
	ret


.i_38
.i_35
	jp	i_32
.i_33
	ld	hl,0	;const
	pop	bc
	pop	bc
	pop	bc
	ret



._event_add
	ld	a,(_b+55)
	ld	e,a
	ld	d,0
	ld	hl,10	;const
	call	l_div_u
	ex	de,hl
	push	hl
	ld	hl,_b
	push	hl
	pop	bc
	pop	hl
	push	hl
	push	bc
	add	hl,hl
	ld	de,35
	add	hl,de
	pop	de
	add	hl,de
	push	hl
	ld	hl,6	;const
	add	hl,sp
	ld	a,(hl)
	pop	de
	ld	(de),a
	ld	hl,_b
	push	hl
	pop	bc
	pop	hl
	push	hl
	push	bc
	add	hl,hl
	ld	de,35
	add	hl,de
	inc	hl
	pop	de
	add	hl,de
	ex	de,hl
	ld	hl,(_now)
	ld	a,l
	ld	(de),a
	ld	hl,_b+55
	inc	(hl)
	ld	l,(hl)
	ld	h,0
	dec	l
	pop	bc
	ret



._match
	ld	hl,0	;const
	push	hl
	push	bc
.i_39
	ld	hl,6	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,4	;const
	add	hl,sp
	call	l_gint	;
	pop	de
	add	hl,de
	call	l_gchar
	ld	a,h
	or	l
	jp	z,i_40
	pop	de
	pop	hl
	inc	hl
	push	hl
	push	de
	dec	hl
	jp	i_39
.i_40
	jp	i_43
.i_41
.i_43
	ld	hl,0	;const
	pop	bc
	push	hl
	jp	i_46
.i_44
	pop	hl
	inc	hl
	push	hl
	dec	hl
.i_46
	pop	de
	push	de
	ld	hl,4-2	;const
	add	hl,sp
	call	l_gint	;
	call	l_lt
	jp	nc,i_45
	ld	hl,8	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	pop	hl
	push	hl
	push	de
	pop	de
	add	hl,de
	call	l_gchar
	push	hl
	ld	hl,8	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,4	;const
	add	hl,sp
	call	l_gint	;
	pop	de
	add	hl,de
	call	l_gchar
	pop	de
	call	l_ne
	jp	c,i_48
.i_47
	jp	i_44
.i_45
	ld	hl,8	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,4	;const
	add	hl,sp
	call	l_gint	;
	pop	de
	add	hl,de
	call	l_gchar
	call	l_lneg
	jp	c,i_50
	ld	hl,8	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,4	;const
	add	hl,sp
	call	l_gint	;
	pop	de
	add	hl,de
	call	l_gchar
	ld	de,32	;const
	ex	de,hl
	call	l_eq
	jp	c,i_50
	ld	hl,8	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,4	;const
	add	hl,sp
	call	l_gint	;
	pop	de
	add	hl,de
	call	l_gchar
	ld	de,44	;const
	ex	de,hl
	call	l_eq
	jp	c,i_50
	ld	hl,8	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,4	;const
	add	hl,sp
	call	l_gint	;
	pop	de
	add	hl,de
	call	l_gchar
	ld	de,46	;const
	ex	de,hl
	call	l_eq
	jp	c,i_50
	ld	hl,8	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,4	;const
	add	hl,sp
	call	l_gint	;
	pop	de
	add	hl,de
	call	l_gchar
	ld	de,63	;const
	ex	de,hl
	call	l_eq
	jp	c,i_50
	ld	hl,8	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,4	;const
	add	hl,sp
	call	l_gint	;
	pop	de
	add	hl,de
	call	l_gchar
	ld	de,33	;const
	ex	de,hl
	call	l_eq
	jp	nc,i_49
.i_50
	ld	hl,1	;const
	pop	bc
	pop	bc
	ret


.i_49
.i_48
.i_52
.i_53
	ld	hl,8	;const
	add	hl,sp
	call	l_gint	;
	call	l_gchar
	ld	a,h
	or	l
	jp	z,i_55
	ld	hl,8	;const
	add	hl,sp
	call	l_gint	;
	call	l_gchar
	ld	de,32	;const
	ex	de,hl
	call	l_ne
	jr	c,i_56_i_55
.i_55
	jp	i_54
.i_56_i_55
	ld	hl,8	;const
	add	hl,sp
	push	hl
	call	l_gint	;
	inc	hl
	pop	de
	call	l_pint
	dec	hl
	jp	i_53
.i_54
	ld	hl,8	;const
	add	hl,sp
	call	l_gint	;
	call	l_gchar
	call	l_lneg
	jp	nc,i_57
	ld	hl,0	;const
	pop	bc
	pop	bc
	ret


.i_57
	ld	hl,8	;const
	add	hl,sp
	push	hl
	call	l_gint	;
	inc	hl
	pop	de
	call	l_pint
	dec	hl
	jp	i_41
.i_42
	pop	bc
	pop	bc
	ret



._memory_scan
	pop	bc
	pop	hl
	push	hl
	push	bc
	push	hl
	ld	hl,i_1+0
	push	hl
	call	_match
	pop	bc
	pop	bc
	ld	a,h
	or	l
	jp	nz,i_59
	pop	bc
	pop	hl
	push	hl
	push	bc
	push	hl
	ld	hl,i_1+4
	push	hl
	call	_match
	pop	bc
	pop	bc
	ld	a,h
	or	l
	jp	nz,i_59
	jr	i_60
.i_59
	ld	hl,1	;const
.i_60
	ld	a,h
	or	l
	jp	z,i_58
	ld	hl,1 % 256	;const
	push	hl
	call	_event_add
	pop	bc
	jp	i_61
.i_58
	pop	bc
	pop	hl
	push	hl
	push	bc
	push	hl
	ld	hl,i_1+13
	push	hl
	call	_match
	pop	bc
	pop	bc
	ld	a,h
	or	l
	jp	nz,i_63
	pop	bc
	pop	hl
	push	hl
	push	bc
	push	hl
	ld	hl,i_1+20
	push	hl
	call	_match
	pop	bc
	pop	bc
	ld	a,h
	or	l
	jp	nz,i_63
	jr	i_64
.i_63
	ld	hl,1	;const
.i_64
	ld	a,h
	or	l
	jp	z,i_62
	ld	hl,2 % 256	;const
	push	hl
	call	_event_add
	pop	bc
	jp	i_65
.i_62
	pop	bc
	pop	hl
	push	hl
	push	bc
	push	hl
	ld	hl,i_1+30
	push	hl
	call	_match
	pop	bc
	pop	bc
	ld	a,h
	or	l
	jp	nz,i_67
	pop	bc
	pop	hl
	push	hl
	push	bc
	push	hl
	ld	hl,i_1+38
	push	hl
	call	_match
	pop	bc
	pop	bc
	ld	a,h
	or	l
	jp	nz,i_67
	jr	i_68
.i_67
	ld	hl,1	;const
.i_68
	ld	a,h
	or	l
	jp	z,i_66
	ld	hl,3 % 256	;const
	push	hl
	call	_event_add
	pop	bc
.i_66
.i_65
.i_61
	ret



._recall_print
	jp	i_69
._st_recall_print_ew
	defw	0
	defw	i_1+45
	defw	i_1+57
	defw	i_1+62
	defw	i_1+73
	defw	i_1+82

.i_69
	push	bc
	ld	hl,65535	;const
	push	hl
	dec	sp
	ld	hl,3	;const
	add	hl,sp
	ld	de,0	;const
	ex	de,hl
	call	l_pint
	jp	i_73
.i_71
	ld	hl,3	;const
	add	hl,sp
	push	hl
	call	l_gint	;
	inc	hl
	pop	de
	call	l_pint
	dec	hl
.i_73
	ld	hl,3	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,10	;const
	call	l_lt
	jp	nc,i_72
	ld	hl,_b
	push	hl
	ld	hl,5	;const
	add	hl,sp
	call	l_gint	;
	add	hl,hl
	ld	de,35
	add	hl,de
	pop	de
	add	hl,de
	ld	a,(hl)
	and	a
	jp	z,i_75
	ld	hl,1+1	;const
	add	hl,sp
	ld	a,(hl)
	rlca
	jp	c,i_76
	ld	hl,_b
	push	hl
	ld	hl,5	;const
	add	hl,sp
	call	l_gint	;
	add	hl,hl
	ld	de,35
	add	hl,de
	inc	hl
	pop	de
	add	hl,de
	ld	l,(hl)
	ld	h,0
	push	hl
	ld	hl,_b
	push	hl
	ld	hl,5	;const
	add	hl,sp
	call	l_gint	;
	add	hl,hl
	ld	de,35
	add	hl,de
	inc	hl
	pop	de
	add	hl,de
	ld	l,(hl)
	ld	h,0
	pop	de
	ex	de,hl
	and	a
	sbc	hl,de
	ld	h,0
	ld	de,128	;const
	ex	de,hl
	call	l_ult
	jp	nc,i_75
.i_76
	jr	i_78_i_75
.i_75
	jp	i_74
.i_78_i_75
	ld	hl,1	;const
	add	hl,sp
	ex	de,hl
	ld	hl,5-2	;const
	add	hl,sp
	call	l_gint	;
	call	l_pint
.i_74
	jp	i_71
.i_72
	ld	hl,1	;const
	add	hl,sp
	call	l_gint	;
	xor	a
	or	h
	jp	p,i_79
	inc	sp
	pop	bc
	pop	bc
	ret


.i_79
	ld	hl,0	;const
	add	hl,sp
	push	hl
	ld	hl,(_now)
	ld	h,0
	push	hl
	ld	hl,_b
	push	hl
	ld	hl,7	;const
	add	hl,sp
	call	l_gint	;
	add	hl,hl
	ld	de,35
	add	hl,de
	inc	hl
	pop	de
	add	hl,de
	ld	l,(hl)
	ld	h,0
	pop	de
	ex	de,hl
	and	a
	sbc	hl,de
	pop	de
	ld	a,l
	ld	(de),a
	ld	hl,0	;const
	add	hl,sp
	ld	a,(hl)
	cp	#(14 % 256)
	jp	z,i_80
	jp	c,i_80
	ld	hl,i_1+91
	push	hl
	call	_say
	pop	bc
	jp	i_81
.i_80
	ld	hl,i_1+110
	push	hl
	call	_say
	pop	bc
	ld	hl,_st_recall_print_ew
	push	hl
	ld	hl,_b
	push	hl
	ld	hl,5	;const
	add	hl,sp
	call	l_gint	;
	add	hl,hl
	ld	de,35
	add	hl,de
	pop	de
	add	hl,de
	ld	l,(hl)
	ld	h,0
	add	hl,hl
	pop	de
	add	hl,de
	call	l_gint	;
	push	hl
	call	_say
	pop	bc
	ld	hl,i_1+118
	push	hl
	call	_say
	pop	bc
	ld	hl,0	;const
	add	hl,sp
	ld	l,(hl)
	ld	h,0
	push	hl
	call	_say_int
	pop	bc
	ld	hl,i_1+121
	push	hl
	call	_say
	pop	bc
.i_81
	inc	sp
	pop	bc
	pop	bc
	ret



._poke_load_name
	ld hl,2
	add hl,sp
	ld a,(hl) ; topic number
	ld hl,(_namtab) ; the name table (the C computed it)
	ld c,a
	ld a,(hl) ; magic
	cp $A1
	ret nz
	inc hl
	ld a,(hl) ; count
	cp c
	ret c ; topic > count: leave line 2 untouched
	dec c
	ld b,$00
	ld a,c
	add a,a
	add a,a
	add a,a ; (topic-1)*8
	ld c,a
	inc hl ; first name byte
	add hl,bc ; hl = names + (topic-1)*8
	ex de,hl ; de = the source
	ld hl,($407F) ; line-1 body length
	ld bc,$4085
	add hl,bc ; hl = the first body byte of line 2
	ld b,$20
	pkn2:
	ld a,(hl)
	cp $EF ; the LOAD token
	jr z,pkn3
	inc hl
	djnz pkn2
	ret ; no LOAD in line 2: leave it untouched
	pkn3:
	inc hl ; skip the quote: hl = the 8-char slot
	ld b,$08
	pkn1:
	ld a,(de)
	ld (hl),a
	inc hl
	inc de
	djnz pkn1
	ret
	ret



._page_show
	ld	hl,65499	;const
	add	hl,sp
	ld	sp,hl
	ld	hl,32	;const
	add	hl,sp
	push	hl
	ld	hl,0	;const
	ld	a,l
	call	l_sxt
	pop	de
	ld	a,l
	ld	(de),a
	ld	hl,35	;const
	add	hl,sp
	ld	de,0	;const
	ex	de,hl
	call	l_pint
	jp	i_84
.i_82
	ld	hl,35	;const
	add	hl,sp
	push	hl
	call	l_gint	;
	inc	hl
	pop	de
	call	l_pint
	dec	hl
.i_84
	ld	hl,35	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,5	;const
	call	l_lt
	jp	nc,i_83
	ld	hl,(_ring_pos)
	ld	de,32	;const
	ex	de,hl
	call	l_div
	ld	de,32
	call	l_mult
	push	hl
	push	hl
	ld	hl,39	;const
	add	hl,sp
	call	l_gint	;
	ld	de,32
	call	l_mult
	pop	de
	add	hl,de
	ld	de,160	;const
	ex	de,hl
	call	l_div
	ex	de,hl
	push	hl
	ld	hl,37	;const
	add	hl,sp
	ld	de,0	;const
	ex	de,hl
	call	l_pint
	jp	i_87
.i_85
	ld	hl,37	;const
	add	hl,sp
	push	hl
	call	l_gint	;
	inc	hl
	pop	de
	call	l_pint
	dec	hl
.i_87
	ld	hl,37	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,32	;const
	call	l_lt
	jp	nc,i_86
	pop	de
	push	de
	ld	hl,39-2	;const
	add	hl,sp
	call	l_gint	;
	add	hl,de
	ld	de,160	;const
	ex	de,hl
	call	l_div
	ex	de,hl
	ld	de,96
	add	hl,de
	call	l_int2long_s
	push	de
	push	hl
	call	_hal_scratch_get
	pop	bc
	pop	bc
	ld	a,l
	call	l_sxt
	dec	sp
	ld	a,l
	pop	hl
	ld	l,a
	push	hl
	ld	hl,5	;const
	add	hl,sp
	ex	de,hl
	ld	hl,40-2	;const
	add	hl,sp
	call	l_gint	;
	add	hl,de
	push	hl
	ld	hl,_RT_CHARSET
	push	hl
	ld	hl,4	;const
	add	hl,sp
	ld	a,(hl)
	cp	#(48 % 256)
	jp	z,i_88
	jp	nc,i_88
	ld	hl,4	;const
	add	hl,sp
	ld	l,(hl)
	ld	h,0
	jp	i_89
.i_88
	ld	hl,0	;const
.i_89
	pop	de
	add	hl,de
	call	l_gchar
	ld	a,l
	call	l_sxt
	pop	de
	ld	a,l
	ld	(de),a
	inc	sp
	jp	i_85
.i_86
	ld	hl,37	;const
	add	hl,sp
	ld	de,0	;const
	ex	de,hl
	call	l_pint
	jp	i_92
.i_90
	ld	hl,37	;const
	add	hl,sp
	push	hl
	call	l_gint	;
	inc	hl
	pop	de
	call	l_pint
	dec	hl
.i_92
	ld	hl,37	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,32	;const
	call	l_lt
	jp	nc,i_91
	ld	hl,39	;const
	add	hl,sp
	call	l_gint	;
	ld	de,8
	add	hl,de
	ld	de,32
	call	l_mult
	ex	de,hl
	ld	hl,39-2	;const
	add	hl,sp
	call	l_gint	;
	add	hl,de
	push	hl
	ld	hl,6	;const
	add	hl,sp
	ex	de,hl
	ld	hl,41-2	;const
	add	hl,sp
	call	l_gint	;
	add	hl,de
	call	l_gchar
	push	hl
	call	_hal_scratch_char
	pop	bc
	pop	bc
	jp	i_90
.i_91
	pop	bc
	pop	bc
	jp	i_82
.i_83
	ld	hl,37	;const
	add	hl,sp
	ld	sp,hl
	ret



._emit
	pop	bc
	pop	hl
	push	hl
	push	bc
	ld	hl,4	;const
	add	hl,sp
	call	l_gchar
	push	hl
	call	_hal_putchar
	pop	bc
	ld	hl,(_ring_col)
	xor	a
	or	h
	jp	m,i_93
	ld	hl,4	;const
	add	hl,sp
	call	l_gchar
	ld	de,13	;const
	ex	de,hl
	call	l_eq
	jp	nc,i_94
.i_95
	ld	hl,(_ring_col)
	ld	de,32	;const
	ex	de,hl
	call	l_lt
	jp	nc,i_96
	ld	hl,(_ring_pos)
	ld	de,96
	add	hl,de
	call	l_int2long_s
	push	de
	push	hl
	ld	hl,32 % 256	;const
	push	hl
	call	_hal_scratch_put
	pop	bc
	pop	bc
	pop	bc
	ld	hl,(_ring_pos)
	inc	hl
	ld	(_ring_pos),hl
	dec	hl
	ld	hl,(_ring_col)
	inc	hl
	ld	(_ring_col),hl
	dec	hl
	jp	i_95
.i_96
	ld	hl,0	;const
	ld	(_ring_col),hl
	jp	i_97
.i_94
	ld	hl,(_ring_col)
	ld	de,32	;const
	ex	de,hl
	call	l_lt
	jp	nc,i_98
	ld	hl,(_ring_pos)
	ld	de,96
	add	hl,de
	call	l_int2long_s
	push	de
	push	hl
	ld	hl,8	;const
	add	hl,sp
	call	l_gchar
	ld	h,0
	push	hl
	call	_hal_scratch_put
	pop	bc
	pop	bc
	pop	bc
	ld	hl,(_ring_pos)
	inc	hl
	ld	de,160	;const
	ex	de,hl
	call	l_div
	ex	de,hl
	ld	(_ring_pos),hl
	ld	hl,(_ring_col)
	inc	hl
	ld	(_ring_col),hl
	dec	hl
.i_98
.i_97
.i_93
	jp	_hal_flush



._eq_cmd
	ld	hl,1	;const
	push	hl
.i_99
	ld	hl,4	;const
	add	hl,sp
	call	l_gint	;
	call	l_gchar
	ld	a,h
	or	l
	jp	z,i_100
	ld	hl,6	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	pop	hl
	push	hl
	push	de
	pop	de
	add	hl,de
	call	l_gchar
	push	hl
	ld	hl,6	;const
	add	hl,sp
	call	l_gint	;
	call	l_gchar
	pop	de
	call	l_ne
	jp	nc,i_101
	ld	hl,0	;const
	pop	bc
	ret


.i_101
	pop	hl
	inc	hl
	push	hl
	ld	hl,4	;const
	add	hl,sp
	push	hl
	call	l_gint	;
	inc	hl
	pop	de
	call	l_pint
	dec	hl
	jp	i_99
.i_100
	ld	hl,6	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	pop	hl
	push	hl
	push	de
	pop	de
	add	hl,de
	call	l_gchar
	ld	de,0	;const
	ex	de,hl
	call	l_eq
	jp	c,i_102
	ld	hl,6	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	pop	hl
	push	hl
	push	de
	pop	de
	add	hl,de
	call	l_gchar
	ld	de,32	;const
	ex	de,hl
	call	l_eq
	jp	c,i_102
	ld	hl,0	;const
	jr	i_103
.i_102
	ld	hl,1	;const
.i_103
	pop	bc
	ret



._silent_emit
	pop	bc
	pop	hl
	push	hl
	push	bc
	ld	hl,4	;const
	add	hl,sp
	call	l_gchar
	ret



._getline
	ld	hl,0	;const
	push	hl
	push	bc
	jp	i_106
.i_104
.i_106
	call	_hal_getchar
	pop	bc
	push	hl
	xor	a
	or	h
	jp	p,i_107
	jp	i_104
.i_107
	pop	hl
	push	hl
	ld	de,13	;const
	ex	de,hl
	call	l_eq
	jp	c,i_109
	pop	hl
	push	hl
	ld	de,10	;const
	ex	de,hl
	call	l_eq
	jp	nc,i_108
.i_109
	ld	de,_line
	ld	hl,4-2	;const
	add	hl,sp
	call	l_gint	;
	add	hl,de
	push	hl
	ld	hl,0	;const
	ld	a,l
	call	l_sxt
	pop	de
	ld	a,l
	ld	(de),a
	pop	bc
	pop	hl
	ret


.i_108
	pop	hl
	push	hl
	ld	de,30	;const
	ex	de,hl
	call	l_eq
	jp	c,i_112
	pop	hl
	push	hl
	ld	de,31	;const
	ex	de,hl
	call	l_eq
	jp	nc,i_111
.i_112
	call	_page_show
	jp	i_104
.i_111
	pop	bc
	pop	hl
	push	hl
	push	bc
	ld	a,h
	or	l
	jp	nz,i_114
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,17	;const
	call	l_ge
	jp	nc,i_116
	pop	hl
	push	hl
	ld	de,20	;const
	ex	de,hl
	call	l_le
	jr	c,i_117_i_116
.i_116
	jp	i_115
.i_117_i_116
	ld	hl,_b+33
	push	hl
	pop	bc
	pop	hl
	push	hl
	push	bc
	ld	bc,-17+1
	add	hl,bc
	pop	de
	ld	a,l
	ld	(de),a
	ld	a,(_b+33)
	cp	#(4 % 256)
	jp	z,i_118
	jp	c,i_118
	ld	hl,_b+33
	ld	(hl),#(4 % 256 % 256)
.i_118
	ld	hl,_chat+16
	push	hl
	ld	hl,(_b+33)
	ld	h,0
	dec	hl
	pop	de
	call	l_pint
	ld	hl,i_1+130
	push	hl
	call	_say
	pop	bc
	ld	hl,(_b+33)
	ld	h,0
	push	hl
	call	_say_int
	pop	bc
	ld	hl,i_1+108
	push	hl
	call	_say
	pop	bc
	jp	i_104
.i_115
	pop	hl
	push	hl
	ld	de,34	;const
	ex	de,hl
	call	l_eq
	jp	nc,i_119
	ld	hl,_b+34
	push	hl
	ld	a,(hl)
	and	a
	jp	z,i_120
	ld	hl,0	;const
	jp	i_121
.i_120
	ld	hl,1	;const
.i_121
	pop	de
	ld	a,l
	ld	(de),a
	ld	a,(_b+34)
	and	a
	jp	z,i_122
	ld	hl,i_1+138
	jp	i_123
.i_122
	ld	hl,i_1+151
.i_123
	push	hl
	call	_say
	pop	bc
	jp	i_104
.i_119
.i_114
	pop	hl
	push	hl
	ld	de,18	;const
	ex	de,hl
	call	l_eq
	jp	nc,i_124
	pop	bc
	pop	hl
	push	hl
	push	bc
	ld	a,h
	or	l
	jp	z,i_125
	pop	de
	pop	hl
	dec	hl
	push	hl
	push	de
	ld	hl,8	;const
	push	hl
	call	_hal_putchar
	pop	bc
.i_125
	jp	i_104
.i_124
	pop	hl
	push	hl
	ld	de,32	;const
	ex	de,hl
	call	l_lt
	jp	c,i_127
	pop	hl
	push	hl
	ld	de,127	;const
	ex	de,hl
	call	l_gt
	jr	nc,i_126
.i_127
	jp	i_104
.i_126
	pop	hl
	push	hl
	ld	de,65	;const
	ex	de,hl
	call	l_ge
	jp	nc,i_130
	pop	hl
	push	hl
	ld	de,90	;const
	ex	de,hl
	call	l_le
	jr	c,i_131_i_130
.i_130
	jp	i_129
.i_131_i_130
	pop	hl
	ld	bc,32
	add	hl,bc
	push	hl
.i_129
	pop	bc
	pop	de
	push	de
	push	bc
	ld	hl,38	;const
	call	l_lt
	jp	nc,i_132
	ld	hl,_line
	push	hl
	ld	hl,4	;const
	add	hl,sp
	push	hl
	call	l_gint	;
	inc	hl
	pop	de
	call	l_pint
	dec	hl
	pop	de
	add	hl,de
	push	hl
	pop	bc
	pop	hl
	push	hl
	push	bc
	ld	a,l
	call	l_sxt
	ld	a,l
	call	l_sxt
	pop	de
	ld	a,l
	ld	(de),a
.i_132
	pop	hl
	push	hl
	push	hl
	call	_hal_putchar
	pop	bc
	jp	i_104
.i_105
	pop	bc
	pop	bc
	ret



._gen_reply
	ld	a,(_b+34)
	and	a
	jp	z,i_133
	ld	hl,_chat+14
	ld	(hl),#(1 % 256)
	inc	hl
	ld	(hl),#(1 / 256)
	ld	hl,_chat
	push	hl
	ld	hl,_model
	push	hl
	ld	hl,_silent_emit
	push	hl
	ld	hl,0	;const
	push	hl
	call	_rt_chat_gen
	pop	bc
	pop	bc
	pop	bc
	pop	bc
	ld	hl,0	;const
	ld	(_chat+14),hl
.i_133
	ld	hl,_chat
	push	hl
	ld	hl,_model
	push	hl
	ld	hl,_emit
	push	hl
	ld	hl,0	;const
	push	hl
	call	_rt_chat_gen
	pop	bc
	pop	bc
	pop	bc
	pop	bc
	ld	hl,(_ring_col)
	ld	a,h
	or	l
	jp	z,i_134
.i_135
	ld	hl,(_ring_col)
	ld	de,32	;const
	ex	de,hl
	call	l_lt
	jp	nc,i_136
	ld	hl,(_ring_pos)
	ld	de,96
	add	hl,de
	call	l_int2long_s
	push	de
	push	hl
	ld	hl,32 % 256	;const
	push	hl
	call	_hal_scratch_put
	pop	bc
	pop	bc
	pop	bc
	ld	hl,(_ring_pos)
	inc	hl
	ld	de,160	;const
	ex	de,hl
	call	l_div
	ex	de,hl
	ld	(_ring_pos),hl
	ld	hl,(_ring_col)
	inc	hl
	ld	(_ring_col),hl
	dec	hl
	jp	i_135
.i_136
	ld	hl,0	;const
	ld	(_ring_col),hl
.i_134
	ret



._state_default
	ld	hl,0	;const
	push	hl
	jp	i_139
.i_137
	pop	hl
	inc	hl
	push	hl
	dec	hl
.i_139
	pop	hl
	push	hl
	ld	de,72	;const
	ex	de,hl
	call	l_lt
	jp	nc,i_138
	ld	hl,_b
	ex	de,hl
	pop	hl
	push	hl
	add	hl,de
	ld	(hl),#(0 % 256 % 256)
	ld	l,(hl)
	ld	h,0
	jp	i_137
.i_138
	ld	hl,_b
	ld	(hl),#(82 % 256 % 256)
	ld	hl,_b+1
	ld	(hl),#(84 % 256 % 256)
	ld	hl,_b+1+1
	ld	(hl),#(50 % 256 % 256)
	ld	hl,_b+1+1+1
	ld	(hl),#(2 % 256 % 256)
	ld	hl,_b+33
	ld	(hl),#(2 % 256 % 256)
	ld	l,(hl)
	ld	h,0
	pop	bc
	ret



._main
	push	bc
	push	bc
	dec	sp
	; -IXIY swap: assembles as LD IY,4000h = the ROM sysvar base
	ld ix, $4000
	call $0F2B ; SLOW: enable the continuous NMI display
	call	_rt_charset_init
	call	_unpack_state
	ld	hl,3	;const
	add	hl,sp
	ld	de,0	;const
	ex	de,hl
	call	l_pint
	call	_state_valid
	ld	a,h
	or	l
	jp	z,i_140
	ld	hl,3	;const
	add	hl,sp
	ld	(hl),#(1 % 256)
	inc	hl
	ld	(hl),#(1 / 256)
	ld	a,(_b+56)
	cp	#(2 % 256)
	jp	nz,i_141
	ld	hl,_b+56
	ld	(hl),#(0 % 256 % 256)
	ld	l,(hl)
	ld	h,0
	call	_pack_state
	ld	hl,2	;const
	inc	sp
	pop	bc
	pop	bc
	ret


.i_141
	call	_state_apply
	jp	i_142
.i_140
	call	_state_default
.i_142
	call	_model_find
	ld	a,h
	or	l
	jp	nz,i_143
	ld	hl,i_1+165
	push	hl
	call	_say
	pop	bc
	ld	hl,(16396)
	push	hl
	call	_say_int
	pop	bc
	ld	hl,i_1+182
	push	hl
	call	_say
	pop	bc
	ld	hl,0	;const
	inc	sp
	pop	bc
	pop	bc
	ret


.i_143
	ld	hl,(_model_addr)
	ld	bc,1030
	add	hl,bc
	ld	l,(hl)
	ld	h,0
	ld	a,l
	call	l_sxt
	dec	sp
	ld	a,l
	pop	hl
	ld	l,a
	push	hl
	ld	hl,0	;const
	add	hl,sp
	ld	a,(hl)
	cp	#(13 % 256)
	jp	z,i_144
	jp	c,i_144
	ld	hl,0	;const
	add	hl,sp
	ld	(hl),#(0 % 256 % 256)
.i_144
	ld	hl,0	;const
	add	hl,sp
	ld	l,(hl)
	ld	h,0
	ld	a,l
	ld	(_topic_idx),a
	ld	hl,_b+31
	push	hl
	ld	hl,2	;const
	add	hl,sp
	ld	a,(hl)
	pop	de
	ld	(de),a
	ld	l,a
	ld	h,0
	inc	sp
	ld	hl,1	;const
	add	hl,sp
	ld	de,0	;const
	ex	de,hl
	call	l_pint
	jp	i_147
.i_145
	ld	hl,1	;const
	add	hl,sp
	push	hl
	call	l_gint	;
	inc	hl
	pop	de
	call	l_pint
	dec	hl
.i_147
	ld	hl,1	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,8	;const
	call	l_lt
	jp	nc,i_146
	ld	de,_uname
	ld	hl,3-2	;const
	add	hl,sp
	call	l_gint	;
	add	hl,de
	push	hl
	ld	hl,_b
	push	hl
	ld	hl,5	;const
	add	hl,sp
	call	l_gint	;
	ld	de,4
	add	hl,de
	pop	de
	add	hl,de
	ld	a,(hl)
	cp	#(0 % 256)
	jp	nz,i_148
	ld	hl,32	;const
	jp	i_149
.i_148
	ld	hl,_b
	push	hl
	ld	hl,5	;const
	add	hl,sp
	call	l_gint	;
	ld	de,4
	add	hl,de
	pop	de
	add	hl,de
	ld	l,(hl)
	ld	h,0
.i_149
	ld	a,l
	call	l_sxt
	pop	de
	ld	a,l
	ld	(de),a
	jp	i_145
.i_146
	ld	hl,_uname+8
	push	hl
	ld	hl,0	;const
	ld	a,l
	call	l_sxt
	pop	de
	ld	a,l
	ld	(de),a
	ld	a,(_b+14)
	ld	e,a
	ld	d,0
	ld	l,#(8 % 256)
	call	l_asl
	ex	de,hl
	ld	hl,(_b+15)
	ld	h,0
	call	l_or
	ld	(_now),hl
	ld	hl,0	;const
	ld	(_ring_col),hl
	ld	hl,0	;const
	ld	(_ring_pos),hl
	ld	hl,i_1+197
	push	hl
	call	_say
	pop	bc
	ld	hl,_uname
	call	l_gchar
	ld	de,32	;const
	ex	de,hl
	call	l_ne
	jp	nc,i_150
	call	_recall_print
	jp	i_151
.i_150
	ld	hl,i_1+213
	push	hl
	call	_say
	pop	bc
.i_151
	jp	i_154
.i_152
.i_154
	push	bc
	ld	hl,i_1+225
	push	hl
	call	_say
	pop	bc
	call	_hal_flush
	call	_getline
	pop	bc
	push	hl
	ld	hl,i_1+108
	push	hl
	call	_say
	pop	bc
	pop	hl
	push	hl
	ld	a,h
	or	l
	jp	nz,i_155
	pop	bc
	jp	i_152
.i_155
	ld	hl,_line
	push	hl
	call	_memory_scan
	pop	bc
	ld	hl,_line
	call	l_gchar
	ld	de,47	;const
	ex	de,hl
	call	l_eq
	jp	nc,i_156
	ld	hl,2	;const
	add	hl,sp
	push	hl
	ld	hl,_line+1
	call	l_gchar
	ld	a,l
	call	l_sxt
	pop	de
	ld	a,l
	ld	(de),a
	ld	hl,_line+1
	call	l_gchar
	ld	de,104	;const
	ex	de,hl
	call	l_eq
	jp	nc,i_158
	ld	hl,_line+1+1
	call	l_gchar
	ld	de,101	;const
	ex	de,hl
	call	l_eq
	jr	c,i_159_i_158
.i_158
	jp	i_157
.i_159_i_158
	ld	hl,i_1+231
	push	hl
	call	_say
	pop	bc
	ld	hl,i_1+256
	push	hl
	call	_say
	pop	bc
	jp	i_160
.i_157
	ld	hl,2	;const
	add	hl,sp
	call	l_gchar
	ld	de,116	;const
	ex	de,hl
	call	l_eq
	jp	nc,i_162
	ld	hl,_line+1+1
	call	l_gchar
	ld	de,111	;const
	ex	de,hl
	call	l_eq
	jp	nc,i_162
	ld	hl,_line+6
	call	l_gchar
	ld	de,32	;const
	ex	de,hl
	call	l_eq
	jp	nc,i_162
	ld	hl,_line+7
	call	l_gchar
	ld	de,0	;const
	ex	de,hl
	call	l_eq
	jr	c,i_163_i_162
.i_162
	jp	i_161
.i_163_i_162
	ld	hl,3	;const
	add	hl,sp
	ld	de,1	;const
	ex	de,hl
	call	l_pint
	jp	i_166
.i_164
	ld	hl,3	;const
	add	hl,sp
	push	hl
	call	l_gint	;
	inc	hl
	pop	de
	call	l_pint
	dec	hl
.i_166
	ld	hl,3	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,13	;const
	call	l_le
	jp	nc,i_165
	ld	hl,3	;const
	add	hl,sp
	call	l_gint	;
	push	hl
	call	_say_int
	pop	bc
	ld	hl,i_1+116
	push	hl
	call	_say
	pop	bc
	jp	i_164
.i_165
	ld	hl,i_1+298
	push	hl
	call	_say
	pop	bc
	ld	hl,i_1+337
	push	hl
	call	_say
	pop	bc
	ld	hl,i_1+377
	push	hl
	call	_say
	pop	bc
	jp	i_167
.i_161
	ld	hl,2	;const
	add	hl,sp
	call	l_gchar
	ld	de,116	;const
	ex	de,hl
	call	l_eq
	jp	nc,i_169
	ld	hl,_line+7
	call	l_gchar
	ld	de,49	;const
	ex	de,hl
	call	l_ge
	jp	nc,i_169
	ld	hl,_line+7
	call	l_gchar
	ld	de,57	;const
	ex	de,hl
	call	l_le
	jr	c,i_170_i_169
.i_169
	jp	i_168
.i_170_i_169
	ld	hl,_line+7
	call	l_gchar
	ld	bc,-48
	add	hl,bc
	ld	h,0
	ld	a,l
	call	l_sxt
	dec	sp
	ld	a,l
	pop	hl
	ld	l,a
	push	hl
	ld	hl,0	;const
	add	hl,sp
	ld	a,(hl)
	cp	#(13 % 256)
	jp	z,i_171
	jp	c,i_171
	ld	hl,0	;const
	add	hl,sp
	ld	(hl),#(13 % 256 % 256)
.i_171
	ld	hl,0	;const
	add	hl,sp
	ld	l,(hl)
	ld	h,0
	ld	a,l
	ld	(_pending),a
	ld	hl,0	;const
	add	hl,sp
	ld	l,(hl)
	ld	h,0
	push	hl
	call	_poke_load_name
	pop	bc
	call	_pack_state
	ld	hl,i_1+403
	push	hl
	call	_say
	pop	bc
	ld	hl,1	;const
	pop	bc
	pop	bc
	pop	bc
	pop	bc
	ret


.i_168
	ld	hl,2	;const
	add	hl,sp
	call	l_gchar
	ld	de,115	;const
	ex	de,hl
	call	l_eq
	jp	nc,i_173
	call	_pack_state
	ld	hl,_b+56
	ld	(hl),#(2 % 256 % 256)
	ld	l,(hl)
	ld	h,0
	call	_pack_state
	ld	hl,i_1+422
	push	hl
	call	_say
	pop	bc
	ld	hl,2	;const
	inc	sp
	pop	bc
	pop	bc
	pop	bc
	ret


.i_173
	ld	hl,2	;const
	add	hl,sp
	call	l_gchar
	ld	de,110	;const
	ex	de,hl
	call	l_eq
	jp	nc,i_175
	ld	hl,_chat+8
	ld	(hl),#(0 % 256)
	inc	hl
	ld	(hl),#(0 / 256)
	ld	hl,_b+26
	ld	(hl),#(0 % 256 % 256)
	ld	l,(hl)
	ld	h,0
	call	_pack_state
	ld	hl,i_1+455
	push	hl
	call	_say
	pop	bc
	jp	i_176
.i_175
	ld	hl,2	;const
	add	hl,sp
	call	l_gchar
	ld	de,113	;const
	ex	de,hl
	call	l_eq
	jp	nc,i_177
	call	_pack_state
	ld	hl,0	;const
	inc	sp
	pop	bc
	pop	bc
	pop	bc
	ret


.i_177
	ld	hl,i_1+472
	push	hl
	call	_say
	pop	bc
.i_178
.i_176
.i_174
.i_172
.i_167
.i_160
	pop	bc
	jp	i_152
.i_156
	ld	hl,_chat
	push	hl
	ld	hl,_line
	push	hl
	call	_rt_chat_push
	pop	bc
	pop	bc
	call	_gen_reply
	ld	hl,13	;const
	push	hl
	call	_hal_putchar
	pop	bc
	call	_pack_state
	pop	bc
	jp	i_152
.i_153
	inc	sp
	pop	bc
	pop	bc
	ret


.i_1
	defm	"faj"&0
	defm	"fajdalom"&0
	defm	"boldog"&0
	defm	"szerelmes"&0
	defm	"szomoru"&0
	defm	"faradt"&0
	defm	"faj a fejem"&0
	defm	"orom"&0
	defm	"szomorusag"&0
	defm	"faradsag"&0
	defm	"szerelem"&0
	defm	"emlek: mar elmult"&13&""&0
	defm	"emlek: "&0
	defm	" ("&0
	defm	" napja)"&13&""&0
	defm	"hofok: "&0
	defm	"gondolkodom"&13&""&0
	defm	"gyors valasz"&13&""&0
	defm	"no model! dfile="&0
	defm	""&13&"bad cassette"&13&""&0
	defm	"tinyllm v0.5.4"&13&""&0
	defm	"udv! /help"&13&""&0
	defm	"you> "&0
	defm	"/topic /save /new /quit"&13&""&0
	defm	"SHIFT 1-4 hofok, 9 gondolkodo,"
	defm	" 5/0 regen"&13&""&0
	defm	""&13&"1 tud 2 elet 3 hobbi 4 egesz "
	defm	"5 munka"&13&""&0
	defm	"6 muvesz 7 tanul 8 irod 9 film"
	defm	" 10 prog"&13&""&0
	defm	"11 csill 12 rajz 13 vers"&13&""&0
	defm	"toltom a temat..."&13&""&0
	defm	"tekerj a RTBASE16-ra es mentsd"
	defm	"!"&13&""&0
	defm	"uj beszelgetes."&13&""&0
	defm	"???"&13&""&0


; --- Start of Static Variables ---

._b	defs	72
._topic_idx	defs	1
._model	defs	40
._ring_col	defs	2
._ring_pos	defs	2
._model_addr	defs	2
._uname	defs	9
._pending	defs	1
._chat	defs	20
._namtab	defs	2
._line	defs	40
._now	defs	2


; --- Start of Scope Defns ---

	LIB	strcmp
	XREF	_hal_kbhit
	LIB	strcpy
	LIB	strlen
	LIB	strdup
	LIB	strrev
	XREF	_rt_last_hidden
	LIB	strpos
	LIB	strlwr
	XREF	_hal_flush
	LIB	strtok
	LIB	strspn
	LIB	bcopy
	XREF	_rt_chat_push
	XREF	_hal_panic
	LIB	strstr
	LIB	strupr
	LIB	memopd_callee
	LIB	stricmp
	XREF	_rt_forward
	LIB	strncat
	LIB	strcspn
	XREF	_hal_scratch_char
	LIB	strncmp
	LIB	strncpy
	LIB	strpbrk
	LIB	strrchr
	XREF	_hal_scratch_bits
	LIB	index
	LIB	bzero
	LIB	strtok_callee
	LIB	strpos_callee
	XREF	_hal_getchar
	LIB	strcasecmp
	LIB	strrstr
	LIB	memmove
	XREF	_hal_putchar
	LIB	memswap
	LIB	strcat_callee
	LIB	strncat_callee
	LIB	strrstrip_callee
	LIB	strstrip_callee
	LIB	strcspn_callee
	LIB	strspn_callee
	LIB	memset_callee
	XREF	_rt_charset_init
	XREF	_rt_chat_context
	LIB	strrstrip
	XREF	_hal_scratch_cells
	LIB	strnicmp
	XREF	_hal_msleep
	LIB	bcmp
	XREF	_rt_model_load
	XREF	_RT_CHARSET
	LIB	memchr
	XREF	_RT_CHAR_TO_IDX
	LIB	memcmp
	XDEF	_main
	XREF	_hal_scratch_get
	LIB	memcpy
	XREF	_hal_load_file
	XREF	_rt_model_size
	LIB	memopd
	LIB	memopi
	LIB	memset
	XREF	_hal_entropy
	XREF	_hal_scratch_put
	XREF	_hal_list_topics
	XREF	_rt_sample
	LIB	strstrip
	LIB	strcpy_callee
	LIB	strncpy_callee
	LIB	memcpy_callee
	LIB	memmove_callee
	LIB	memopi_callee
	XREF	_rt_chat_push_idx
	LIB	strncasecmp
	LIB	rindex
	XREF	_rt_rand
	XREF	_hal_tape_load
	LIB	strcmp_callee
	LIB	strncmp_callee
	LIB	strchr_callee
	LIB	strrchr_callee
	LIB	strstr_callee
	LIB	strrstr_callee
	LIB	stricmp_callee
	LIB	strnicmp_callee
	LIB	memchr_callee
	LIB	memcmp_callee
	LIB	memswap_callee
	XREF	_hal_tape_save
	XREF	_rt_map_char
	XREF	_hal_save_file
	XREF	_rt_chat_gen
	LIB	strpbrk_callee
	LIB	strcat
	XREF	_rt_chat_init
	LIB	strchr


; --- End of Scope Defns ---


; --- End of Compilation ---
