# 1 "../../../engine/rt_chat.c"

# 6 "./stddef.h"
typedef unsigned int size_t;
# 16 "../../../engine/rt_types.h"
typedef signed char rt_i8;
typedef unsigned char rt_u8;
typedef short rt_i16;
typedef unsigned short rt_u16;
typedef long rt_i32;
typedef unsigned long rt_u32;
# 55 "../../../engine/rt_model.h"
typedef struct {
rt_u16 version, flags;
rt_u16 vocab, ctx, emb, h1, h2;
rt_u16 sh_e, sh1, sh2, sh_o, temp_sh;
} rt_hdr;

typedef struct {
rt_hdr hdr;
rt_i8 *emb;
rt_u8 *sh1;
rt_i8 *w1;
rt_u8 *sh2;
rt_i8 *w2;
rt_u8 *sho;
rt_i8 *wo;
const rt_u8 *raw;
} rt_model;
# 79
int rt_model_load(rt_model *m, const rt_u8 *buf, long len);


long rt_model_size(const rt_hdr *h);
# 7 "../../../engine/rt_chat.h"
typedef struct {
rt_u8 hist[8];
int hist_n;
rt_u32 seed;
int greedy;
int temp_sh;
int max_new;
} rt_chat;
# 19
typedef void (*rt_emit_fn)();

void rt_chat_init(rt_chat *c, rt_u32 seed);
void rt_chat_push_idx(rt_chat *c, rt_u8 idx);
void rt_chat_push(rt_chat *c, const char *s);
int rt_chat_gen(rt_chat *c, const rt_model *m, rt_emit_fn fn, void *user);
void rt_chat_context(const rt_chat *c, char *out, int maxlen);
# 15 "../../../engine/rt_charset.h"
extern const char RT_CHARSET[48 + 1];
extern rt_u8 RT_CHAR_TO_IDX[128];

void rt_charset_init(void);
rt_u8 rt_map_char(char c);
# 12 "../../../engine/rt_engine.h"
void rt_forward(const rt_model *m, const rt_u8 *ctx, rt_i32 *logits);


void rt_last_hidden(const rt_i8 **h, int *n);


rt_u32 rt_rand(rt_u32 *seed);
# 23
int rt_sample(const rt_model *m, const rt_i32 *logits, int temp_sh,
int greedy, rt_u32 *seed);
# 10 "../../../engine/rt_chat.c"
static rt_i32 rt_logits[48];

void rt_chat_init(rt_chat *c, rt_u32 seed)
{
int i;
for (i = 0; i < 8; i++)
c->hist[i] = 1;
c->hist_n = 0;
c->seed = seed;
c->greedy = 0;
c->temp_sh = 2;
c->max_new = 72;
}

void rt_chat_push_idx(rt_chat *c, rt_u8 idx)
{
int i;
if (c->hist_n < 8) {
c->hist[c->hist_n++] = idx;
return;
}
for (i = 1; i < 8; i++)
c->hist[i - 1] = c->hist[i];
c->hist[8 - 1] = idx;
}

void rt_chat_push(rt_chat *c, const char *s)
{
while (*s)
rt_chat_push_idx(c, rt_map_char(*s++));
}

int rt_chat_gen(rt_chat *c, const rt_model *m, rt_emit_fn fn, void *user)
{
rt_u8 win[8];
int i, n = 0, cap = c->max_new;
int empty = 3;

while (n < cap) {
int idx;
int ctx = (int)m->hdr.ctx;


for (i = 0; i < ctx; i++) {
int pos = c->hist_n - ctx + i;
win[i] = (pos < 0) ? (rt_u8)1 : c->hist[pos];
}

rt_forward(m, win, rt_logits);
idx = rt_sample(m, rt_logits, c->temp_sh, c->greedy, &c->seed);
if (idx == 0) {
if (n == 0 && empty > 0) {
empty--;
continue;
}
break;
}
if (fn)
fn(RT_CHARSET[idx], user);
rt_chat_push_idx(c, (rt_u8)idx);
n++;
}
return n;
}

void rt_chat_context(const rt_chat *c, char *out, int maxlen)
{
int i, n = c->hist_n;
if (n > maxlen - 1)
n = maxlen - 1;
for (i = 0; i < n; i++)
out[i] = RT_CHARSET[c->hist[i]];
out[i] = '\0';
}
