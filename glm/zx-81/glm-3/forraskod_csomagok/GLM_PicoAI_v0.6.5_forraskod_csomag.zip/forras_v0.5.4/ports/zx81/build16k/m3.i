# 1 "../../../engine/rt_charset.c"

# 16 "../../../engine/rt_types.h"
typedef signed char rt_i8;
typedef unsigned char rt_u8;
typedef short rt_i16;
typedef unsigned short rt_u16;
typedef long rt_i32;
typedef unsigned long rt_u32;
# 15 "../../../engine/rt_charset.h"
extern const char RT_CHARSET[48 + 1];
extern rt_u8 RT_CHAR_TO_IDX[128];

void rt_charset_init(void);
rt_u8 rt_map_char(char c);
# 4 "../../../engine/rt_charset.c"
const char RT_CHARSET[48 + 1] =
"\n abcdefghijklmnopqrstuvwxyz,.?!0123456789:-/*()";

rt_u8 RT_CHAR_TO_IDX[128];

void rt_charset_init(void)
{
int i;
for (i = 0; i < 128; i++)
RT_CHAR_TO_IDX[i] = 1;

for (i = 0; i < 48; i++) {
RT_CHAR_TO_IDX[(unsigned char)RT_CHARSET[i]] = (rt_u8)i;
if (RT_CHARSET[i] >= 'a' && RT_CHARSET[i] <= 'z')
RT_CHAR_TO_IDX[RT_CHARSET[i] - 'a' + 'A'] = (rt_u8)i;
}
}

rt_u8 rt_map_char(char c)
{
unsigned char u = (unsigned char)c;
if (u >= 128)
return 1;
return RT_CHAR_TO_IDX[u];
}
