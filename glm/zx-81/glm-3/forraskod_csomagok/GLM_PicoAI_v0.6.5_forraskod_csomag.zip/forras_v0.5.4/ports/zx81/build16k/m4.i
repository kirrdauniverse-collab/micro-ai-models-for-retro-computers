# 1 "../../../engine/rt_model.c"

# 6 "./stddef.h"
typedef unsigned int size_t;
# 20 "/home/z/my-project/tools/z88dk-deb/root/usr/share/z88dk/include/sys/types.h"
typedef signed int ssize_t;




typedef unsigned long clock_t;




typedef signed int pid_t;




typedef unsigned char bool_t;




typedef long time_t;




typedef short wild_t;




typedef unsigned long fpos_t;



typedef unsigned char u8_t;
typedef unsigned short u16_t;
typedef unsigned long u32_t;

typedef char i8_t;
typedef short i16_t;
typedef long i32_t;
# 66
typedef unsigned char uchar;




typedef unsigned int uint;
# 20 "/home/z/my-project/tools/z88dk-deb/root/usr/share/z88dk/include/string.h"
extern int __LIB__ __FASTCALL__ strlen(char *);
extern char __LIB__ *strcat(char *, char *);
extern int __LIB__ strcmp(char *, char *);
extern char __LIB__ *strcpy(char *, char *);
extern char __LIB__ *strncat(char *, char *, uint);
extern int __LIB__ strncmp(char *, char *, uint);
extern char __LIB__ *strncpy(char *, char *, uint);
extern char __LIB__ __FASTCALL__ *strrev(char *);
extern char __LIB__ *strchr(unsigned char *, unsigned char);
extern char __LIB__ *strrchr(unsigned char *, unsigned char);
extern char __LIB__ *strrstrip(char *, char);
extern char __LIB__ *strstrip(char *, uint);
extern char __LIB__ *strstr(char *, char *);
extern char __LIB__ *strrstr(char *, char *);
extern char __LIB__ *strtok(char *, char *);
extern char __LIB__ *strpbrk(char *, char *);
extern int __LIB__ strpos(char *, uint);
extern int __LIB__ strcspn(char *, char *);
extern int __LIB__ strspn(char *, char *);
extern int __LIB__ stricmp(char *, char *);
extern int __LIB__ strcasecmp(char *, char *);
extern int __LIB__ strnicmp(char *, char *, uint);
extern int __LIB__ strncasecmp(char *, char *, uint);
extern char __LIB__ __FASTCALL__ *strlwr(char *);
extern char __LIB__ __FASTCALL__ *strupr(char *);

extern void __LIB__ *memset(void *, unsigned char, uint);
extern void __LIB__ *memcpy(void *, void *,uint);
extern void __LIB__ *memmove(void *, void *, uint);
extern void __LIB__ *memchr(void *, unsigned char, uint);
extern int __LIB__ memcmp(void *, void *, uint);
extern void __LIB__ *memswap(void *, void *, uint);
extern void __LIB__ *memopi(void *, void *, uint, uint);
extern void __LIB__ *memopd(void *, void *, uint, uint);

extern char __LIB__ __FASTCALL__ *strdup(char *);



extern char __LIB__ __CALLEE__ *strcat_callee(char *, char *);
extern int __LIB__ __CALLEE__ strcmp_callee(char *, char *);
extern char __LIB__ __CALLEE__ *strcpy_callee(char *, char *);
extern char __LIB__ __CALLEE__ *strncat_callee(char *, char *, uint);
extern int __LIB__ __CALLEE__ strncmp_callee(char *, char *, uint);
extern char __LIB__ __CALLEE__ *strncpy_callee(char *, char *, uint);
extern char __LIB__ __CALLEE__ *strchr_callee(unsigned char *, unsigned char);
extern char __LIB__ __CALLEE__ *strrchr_callee(unsigned char *, unsigned char);
extern char __LIB__ __CALLEE__ *strrstrip_callee(char *, char);
extern char __LIB__ __CALLEE__ *strstrip_callee(char *, uint);
extern char __LIB__ __CALLEE__ *strstr_callee(char *, char *);
extern char __LIB__ __CALLEE__ *strrstr_callee(char *, char *);
extern char __LIB__ __CALLEE__ *strtok_callee(char *, char *);
extern char __LIB__ __CALLEE__ *strpbrk_callee(char *, char *);
extern int __LIB__ __CALLEE__ strpos_callee(char *, uint);
extern int __LIB__ __CALLEE__ strcspn_callee(char *, char *);
extern int __LIB__ __CALLEE__ strspn_callee(char *, char *);
extern int __LIB__ __CALLEE__ stricmp_callee(char *, char *);
extern int __LIB__ __CALLEE__ strnicmp_callee(char *, char *, uint);

extern void __LIB__ __CALLEE__ *memset_callee(void *, unsigned char, uint);
extern void __LIB__ __CALLEE__ *memcpy_callee(void *, void *,uint);
extern void __LIB__ __CALLEE__ *memmove_callee(void *, void *, uint);
extern void __LIB__ __CALLEE__ *memchr_callee(void *, unsigned char, uint);
extern int __LIB__ __CALLEE__ memcmp_callee(void *, void *, uint);
extern void __LIB__ __CALLEE__ *memswap_callee(void *, void *, uint);
extern void __LIB__ __CALLEE__ *memopi_callee(void *, void *, uint, uint);
extern void __LIB__ __CALLEE__ *memopd_callee(void *, void *, uint, uint);
# 171
extern void __LIB__ *bzero(void *, uint);
extern int __LIB__ bcmp(void *, void *, uint);
extern void __LIB__ *bcopy(void *, void *,uint);
extern char __LIB__ *index(unsigned char *, unsigned char);
extern char __LIB__ *rindex(unsigned char *, unsigned char);
# 16 "../../../engine/rt_types.h"
typedef signed char rt_i8;
typedef unsigned char rt_u8;
typedef short rt_i16;
typedef unsigned short rt_u16;
typedef long rt_i32;
typedef unsigned long rt_u32;
# 55 "../../../engine/rt_model.h"
typedef struct {
rt_u16 version, flags;
rt_u16 vocab, ctx, emb, h1, h2;
rt_u16 sh_e, sh1, sh2, sh_o, temp_sh;
} rt_hdr;

typedef struct {
rt_hdr hdr;
rt_i8 *emb;
rt_u8 *sh1;
rt_i8 *w1;
rt_u8 *sh2;
rt_i8 *w2;
rt_u8 *sho;
rt_i8 *wo;
const rt_u8 *raw;
} rt_model;
# 79
int rt_model_load(rt_model *m, const rt_u8 *buf, long len);


long rt_model_size(const rt_hdr *h);
# 15 "../../../engine/rt_charset.h"
extern const char RT_CHARSET[48 + 1];
extern rt_u8 RT_CHAR_TO_IDX[128];

void rt_charset_init(void);
rt_u8 rt_map_char(char c);
# 7 "../../../engine/rt_model.c"
static rt_u16 rd16(const rt_u8 *p)
{
return (rt_u16)(p[0] | ((rt_u16)p[1] << 8));
}

long rt_model_size(const rt_hdr *h)
{
long n;
n = 92;
n += (long)h->vocab * h->emb;
n += h->h1 + (long)h->h1 * ((long)h->ctx * h->emb + 1);
if (h->h2)
n += h->h2 + (long)h->h2 * (h->h1 + 1);
n += h->vocab + (long)h->vocab * ((h->h2 ? h->h2 : h->h1) + 1);
n += 2;
return n;
}

int rt_model_load(rt_model *m, const rt_u8 *buf, long len)
{
const rt_u8 *p = buf;
rt_hdr h;
long need, i;

if (len < 94)
return -1;
if (p[0] != 'R' || p[1] != 'T' ||
p[2] != 'L' || p[3] != 'M')
return -2;

h.version = rd16(p + 4);
if (h.version != 2)
return -3;
h.flags = rd16(p + 6);
h.vocab = rd16(p + 8);
h.ctx = rd16(p + 10);
h.emb = rd16(p + 12);
h.h1 = rd16(p + 14);
h.h2 = rd16(p + 16);
h.sh_e = rd16(p + 18);
h.sh1 = rd16(p + 20);
h.sh2 = rd16(p + 22);
h.sh_o = rd16(p + 24);
h.temp_sh = rd16(p + 26);

if (h.vocab == 0 || h.vocab > 48 ||
h.ctx == 0 || h.ctx > 8 ||
h.emb == 0 || h.emb > 10 ||
h.h1 == 0 || h.h1 > 18 ||
h.h2 > 18)
return -4;
if (h.vocab != 48)
return -5;

for (i = 0; i < 48; i++)
if (p[28 + i] != (rt_u8)RT_CHARSET[i])
return -6;

need = rt_model_size(&h);
if (need > len)
# 72
return -8;

{
rt_u32 sum = 0;
long n = need - 2;
for (i = 0; i < n; i++)
sum = (sum + p[i]) & 0xFFFFUL;
if ((rt_u16)sum != rd16(p + n))
return -7;
}

memcpy_callee(&m->hdr,&h,sizeof(rt_hdr));
m->raw = buf;
p = buf + 92;
m->emb = (rt_i8 *)p;
p += (long)h.vocab * h.emb;

m->sh1 = (rt_u8 *)p;
p += h.h1;
m->w1 = (rt_i8 *)p;
p += (long)h.h1 * ((long)h.ctx * h.emb + 1);

if (h.h2) {
m->sh2 = (rt_u8 *)p;
p += h.h2;
m->w2 = (rt_i8 *)p;
p += (long)h.h2 * (h.h1 + 1);
} else {
m->sh2 = (rt_u8 *)0;
m->w2 = (rt_i8 *)0;
}

m->sho = (rt_u8 *)p;
p += h.vocab;
m->wo = (rt_i8 *)p;
return 0;
}
