;* * * * *  Small-C/Plus z88dk * * * * *
;  Version: 20070909.1
;
;	Reconstructed for the z80 Module Assembler
;
;	Module compile time: Fri Nov 20 17:01:17 2026



	MODULE	hal_zx81.c

	INCLUDE "z80_crt0.hdr"


._ZX81_TO_ASCII
	defm	" "&255&""&255&""&255&""&255&""&255&""&255&""&255&""&255&""&255&""&255&""&34&""&255&"$:?()><=+-*/;,.01"
	defm	"23456789abcdefghijklmnopqrstuv"
	defm	"wxyz"

._ASCII_TO_ZX81
	defm	""&0
	defm	""&0
	defm	""&11&""&0
	defm	""&13&""&0
	defm	""&0
	defm	""&0
	defm	""&16&""&17&""&23&""&21&""&26&""&22&""&27&""&24&""&28&""&29&""&30&""&31&" !"&34&"#$%"&14&""&25&""&19&""&20&""&18&""&15&""&0
	defm	"&'()*+,-./0123456789:;<=>?"&0
	defm	""&0
	defm	""&0
	defm	""&0
	defm	""&0
	defm	""&0
	defm	"&'()*+,-./0123456789:;<=>?"&0
	defm	""&0
	defm	""&0
	defm	""&0
	defm	""&0


._zx81_ascii
	pop	bc
	pop	de
	push	de
	push	bc
	ld	hl,118	;const
	call	l_eq
	jp	nc,i_5
	ld	hl,13	;const
	ret


.i_5
	pop	bc
	pop	de
	push	de
	push	bc
	ld	hl,112	;const
	call	l_eq
	jp	nc,i_6
	ld	hl,30	;const
	ret


.i_6
	pop	bc
	pop	de
	push	de
	push	bc
	ld	hl,113	;const
	call	l_eq
	jp	nc,i_7
	ld	hl,31	;const
	ret


.i_7
	pop	bc
	pop	de
	push	de
	push	bc
	ld	hl,115	;const
	call	l_eq
	jp	nc,i_8
	ld	hl,20	;const
	ret


.i_8
	pop	bc
	pop	de
	push	de
	push	bc
	ld	hl,116	;const
	call	l_eq
	jp	nc,i_9
	ld	hl,19	;const
	ret


.i_9
	pop	bc
	pop	de
	push	de
	push	bc
	ld	hl,117	;const
	call	l_eq
	jp	nc,i_10
	ld	hl,17	;const
	ret


.i_10
	pop	bc
	pop	de
	push	de
	push	bc
	ld	hl,119	;const
	call	l_eq
	jp	nc,i_11
	ld	hl,18	;const
	ret


.i_11
	pop	bc
	pop	de
	push	de
	push	bc
	bit	7,d
	jp	nz,i_13
	pop	bc
	pop	de
	push	de
	push	bc
	ld	hl,63	;const
	call	l_gt
	jp	nc,i_12
.i_13
	ld	hl,65535	;const
	ret


.i_12
	ld	de,_ZX81_TO_ASCII
	ld	hl,4-2	;const
	add	hl,sp
	call	l_gint	;
	add	hl,de
	call	l_gchar
	ret



._hal_getchar
	call	getk
	push	hl
	ld	a,h
	or	l
	jp	z,i_15
	push	hl
	call	_zx81_ascii
	pop	bc
	jp	i_16
.i_15
	ld	hl,65535	;const
.i_16
	pop	bc
	ret



._hal_kbhit
	call	getk
	ld	de,0	;const
	ex	de,hl
	call	l_ne
	ld	hl,0	;const
	rl	l
	ret


._zx81_row
	defw	8

._zx81_col
	defw	0


._zx81_dfile
	ld	hl,(16396)
	ret



._zx81_line
	call	_zx81_dfile
	inc	hl
	push	hl
	ld	hl,4	;const
	add	hl,sp
	call	l_gint	;
	ld	de,33
	call	l_mult
	pop	de
	add	hl,de
	ret



._zx81_code
	pop	bc
	pop	de
	push	de
	push	bc
	ld	hl,32	;const
	call	l_lt
	jp	c,i_20
	pop	bc
	pop	de
	push	de
	push	bc
	ld	hl,127	;const
	call	l_gt
	jp	nc,i_19
.i_20
	ld	hl,0 % 256	;const
	ret


.i_19
	ld	hl,_ASCII_TO_ZX81
	push	hl
	ld	hl,4	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,-32
	add	hl,bc
	pop	de
	add	hl,de
	ld	l,(hl)
	ld	h,0
	ret



._zx81_scr_scroll
	ld	hl,8	;const
	push	hl
	push	bc
	jp	i_24
.i_22
	pop	de
	pop	hl
	inc	hl
	push	hl
	push	de
	dec	hl
.i_24
	pop	bc
	pop	de
	push	de
	push	bc
	ld	hl,21	;const
	call	l_lt
	jp	nc,i_23
	pop	bc
	pop	hl
	push	hl
	push	bc
	push	hl
	call	_zx81_line
	pop	bc
	push	hl
	ld	hl,4	;const
	add	hl,sp
	call	l_gint	;
	inc	hl
	push	hl
	call	_zx81_line
	pop	bc
	push	hl
	ld	hl,4	;const
	add	hl,sp
	ld	de,0	;const
	ex	de,hl
	call	l_pint
	jp	i_27
.i_25
	ld	hl,4	;const
	add	hl,sp
	push	hl
	call	l_gint	;
	inc	hl
	pop	de
	call	l_pint
	dec	hl
.i_27
	ld	hl,4	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,33	;const
	call	l_lt
	jp	nc,i_26
	pop	bc
	pop	hl
	push	hl
	push	bc
	ex	de,hl
	ld	hl,6-2	;const
	add	hl,sp
	call	l_gint	;
	add	hl,de
	push	hl
	pop	bc
	pop	hl
	push	hl
	push	bc
	ex	de,hl
	ld	hl,8-2	;const
	add	hl,sp
	call	l_gint	;
	add	hl,de
	ld	a,(hl)
	pop	de
	ld	(de),a
	ld	l,a
	ld	h,0
	jp	i_25
.i_26
	pop	bc
	pop	bc
	jp	i_22
.i_23
	ld	hl,0	;const
	pop	bc
	push	hl
	jp	i_30
.i_28
	pop	hl
	inc	hl
	push	hl
	dec	hl
.i_30
	pop	hl
	push	hl
	ld	de,32	;const
	ex	de,hl
	call	l_lt
	jp	nc,i_29
	ld	hl,21	;const
	push	hl
	call	_zx81_line
	pop	bc
	ex	de,hl
	pop	hl
	push	hl
	add	hl,de
	ld	(hl),#(0 % 256 % 256)
	ld	l,(hl)
	ld	h,0
	jp	i_28
.i_29
	pop	bc
	pop	bc
	ret



._zx81_advance
	ld	hl,0	;const
	ld	(_zx81_col),hl
	ld	hl,(_zx81_row)
	inc	hl
	ld	(_zx81_row),hl
	ld	de,21	;const
	ex	de,hl
	call	l_gt
	jp	nc,i_31
	call	_zx81_scr_scroll
	ld	hl,21	;const
	ld	(_zx81_row),hl
.i_31
	ret



._hal_putchar
	pop	bc
	pop	de
	push	de
	push	bc
	ld	hl,13	;const
	call	l_eq
	jp	nc,i_32
	jp	_zx81_advance


.i_32
	ld	hl,(_zx81_col)
	ld	de,31	;const
	ex	de,hl
	call	l_gt
	call	c,_zx81_advance
.i_33
	ld	hl,(_zx81_row)
	push	hl
	call	_zx81_line
	pop	bc
	ex	de,hl
	ld	hl,(_zx81_col)
	add	hl,de
	push	hl
	ld	hl,4	;const
	add	hl,sp
	call	l_gint	;
	push	hl
	call	_zx81_code
	pop	bc
	pop	de
	ld	a,l
	ld	(de),a
	ld	hl,(_zx81_col)
	inc	hl
	ld	(_zx81_col),hl
	dec	hl
	ret



._hal_flush
	ret



._hal_msleep
	ld	hl,16436	;const
	push	hl
	ld	l,(hl)
	ld	h,0
	push	hl
	pop	bc
	pop	hl
	push	hl
	push	bc
	inc	hl
	ld	e,(hl)
	ld	d,0
	ld	l,#(8 % 256)
	call	l_asl
	pop	de
	call	l_or
	push	hl
	ld	hl,6	;const
	add	hl,sp
	call	l_glong
	push	de
	push	hl
	ld	hl,20	;const
	ld	de,0
	call	l_long_div
	push	hl
.i_34
	ld	hl,4	;const
	add	hl,sp
	call	l_gint	;
	ld	l,(hl)
	ld	h,0
	push	hl
	ld	hl,6	;const
	add	hl,sp
	call	l_gint	;
	inc	hl
	ld	e,(hl)
	ld	d,0
	ld	l,#(8 % 256)
	call	l_asl
	pop	de
	call	l_or
	ex	de,hl
	ld	hl,4-2	;const
	add	hl,sp
	call	l_gint	;
	ex	de,hl
	and	a
	sbc	hl,de
	ex	de,hl
	pop	hl
	push	hl
	call	l_ult
	jp	c,i_34
.i_35
	pop	bc
	pop	bc
	pop	bc
	ret



._hal_entropy
	ld	hl,16436	;const
	push	hl
	ld	de,0
	ld	l,(hl)
	ld	h,0
	push	hl
	pop	bc
	pop	hl
	push	hl
	push	bc
	ld	de,0
	inc	hl
	ld	e,(hl)
	ld	d,0
	ld	l,#(8 % 256)
	call	l_asl
	pop	de
	call	l_or
	push	hl
	ld	hl,0	;const
	ld	de,33024
	exx
	pop	hl
	ld	de,0
	push	de
	push	hl
	exx
	call	l_long_or
	pop	bc
	ret



._hal_scratch_get
	ld	hl,2	;const
	add	hl,sp
	call	l_glong
	push	de
	push	hl
	ld	hl,32	;const
	ld	de,0
	call	l_long_div
	push	hl
	call	_zx81_line
	pop	bc
	push	hl
	ld	hl,4	;const
	add	hl,sp
	call	l_glong
	push	de
	push	hl
	ld	hl,32	;const
	ld	de,0
	call	l_long_div
	exx
	pop	de
	add	hl,de
	ld	l,(hl)
	ld	h,0
	ret



._hal_scratch_put
	ld	hl,4	;const
	add	hl,sp
	call	l_glong
	push	de
	push	hl
	ld	hl,32	;const
	ld	de,0
	call	l_long_div
	push	hl
	call	_zx81_line
	pop	bc
	push	hl
	ld	hl,6	;const
	add	hl,sp
	call	l_glong
	push	de
	push	hl
	ld	hl,32	;const
	ld	de,0
	call	l_long_div
	exx
	pop	de
	add	hl,de
	push	hl
	ld	hl,4	;const
	add	hl,sp
	ld	a,(hl)
	pop	de
	ld	(de),a
	ld	l,a
	ld	h,0
	ret



._hal_scratch_char
	ld	hl,4	;const
	add	hl,sp
	call	l_glong
	push	de
	push	hl
	ld	hl,32	;const
	ld	de,0
	call	l_long_div
	push	hl
	call	_zx81_line
	pop	bc
	push	hl
	ld	hl,6	;const
	add	hl,sp
	call	l_glong
	push	de
	push	hl
	ld	hl,32	;const
	ld	de,0
	call	l_long_div
	exx
	pop	de
	add	hl,de
	push	hl
	ld	hl,4	;const
	add	hl,sp
	call	l_gchar
	push	hl
	call	_zx81_code
	pop	bc
	pop	de
	ld	a,l
	ld	(de),a
	ret



._hal_panic
	pop	bc
	pop	hl
	push	hl
	push	bc
	push	hl
	ld	hl,21	;const
	ld	(_zx81_row),hl
	ld	hl,0	;const
	ld	(_zx81_col),hl
.i_36
	pop	hl
	push	hl
	call	l_gchar
	ld	a,h
	or	l
	jp	z,i_37
	pop	hl
	inc	hl
	push	hl
	dec	hl
	call	l_gchar
	push	hl
	call	_hal_putchar
	pop	bc
	jp	i_36
.i_37
	ld	hl,13	;const
	push	hl
	call	_hal_putchar
	pop	bc
	jp	i_40
.i_38
.i_40
	jp	i_38
.i_39
	pop	bc
	ret




; --- Start of Static Variables ---



; --- Start of Scope Defns ---

	XDEF	_hal_kbhit
	XDEF	_ASCII_TO_ZX81
	LIB	sprintf
	XDEF	_hal_flush
	XDEF	_hal_panic
	LIB	fgetc
	LIB	freopen
	LIB	fgets
	LIB	open_z88
	LIB	creat
	LIB	hrg_off
	LIB	close
	LIB	copytxt
	XDEF	_hal_scratch_char
	LIB	fread
	LIB	getwd
	XREF	_hal_scratch_bits
	LIB	fseek
	LIB	ltoa_any
	LIB	fopen
	LIB	_clg_hr
	LIB	ftell
	LIB	fprintf
	LIB	vsscanf
	XREF	__sgoioblk
	LIB	fgets_cons
	LIB	mkdir
	LIB	fputc
	XDEF	_hal_getchar
	LIB	scanf
	LIB	fputs
	LIB	lseek
	LIB	zx_setstr
	XDEF	_hal_putchar
	LIB	writebyte
	LIB	fclose
	LIB	rmdir
	LIB	fdopen
	LIB	fdtell
	LIB	zx_fast
	LIB	freopen_z88
	LIB	getarg
	LIB	getcwd
	XREF	_hal_scratch_cells
	LIB	zx_line
	XDEF	_hal_msleep
	LIB	vfprintf_comp
	LIB	fscanf
	LIB	fdgetpos
	LIB	write
	LIB	puts_cons
	LIB	mirrortxt
	LIB	vfprintf_mini
	LIB	feof
	LIB	zx_slow
	LIB	getk
	LIB	hrg_on
	LIB	gets
	LIB	vfprintf_fp
	XDEF	_hal_scratch_get
	XREF	_base_graphics
	XREF	_hal_load_file
	LIB	read
	LIB	ascii_zx
	XDEF	_hal_entropy
	LIB	zx_basic_length
	LIB	open
	XDEF	_hal_scratch_put
	LIB	tell
	LIB	fopen_z88
	XREF	_hal_list_topics
	LIB	puts
	LIB	fwrite
	LIB	rename
	LIB	fchkstd
	XDEF	_zx81_col
	LIB	readbyte
	LIB	invtxt
	LIB	fgetc_cons
	LIB	remove
	XDEF	_zx81_row
	LIB	vsprintf
	XDEF	_ZX81_TO_ASCII
	LIB	zx_asciimode
	LIB	vfscanf
	LIB	zx_ascii
	LIB	nropen
	XREF	_hal_tape_load
	LIB	fgetpos
	LIB	printf
	LIB	zx_getstr_callee
	LIB	zx_setstr_callee
	LIB	sscanf
	LIB	printk
	LIB	printn
	XREF	_hal_tape_save
	LIB	closeall
	LIB	ungetc
	XREF	_hal_save_file
	LIB	zx_getstr
	LIB	fabandon
	LIB	zx_var_length
	XREF	_vfprintf
	LIB	fputc_cons


; --- End of Scope Defns ---


; --- End of Compilation ---
