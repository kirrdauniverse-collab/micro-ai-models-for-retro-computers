;* * * * *  Small-C/Plus z88dk * * * * *
;  Version: 20070909.1
;
;	Reconstructed for the z80 Module Assembler
;
;	Module compile time: Fri Nov 20 17:01:17 2026



	MODULE	rt_engine.c

	INCLUDE "z80_crt0.hdr"


._RT_EXP_LUT
	defw	4096,3615,3190,2815,2484,2192,1935,1707,1507,1330
	defw	1174,1036,914,807,712,628,554,489,432,381
	defw	336,297,262,231,204,180,159,140,124,109
	defw	96,85,75,66,58,52,46,40,35,31
	defw	28,24,21,19,17,15,13,12,10,9
	defw	8,7,6,5,5,4,4,3,3,3
	defw	2,2,2,2,1,1,1,1,1,1
	defw	1,1,1,0,0,0,0,0,0,0
	defw	0,0,0,0,0,0,0,0,0,0
	defw	0,0,0,0,0,0,0,0,0,0
	defw	0,0,0,0,0,0,0,0,0,0
	defw	0,0,0,0,0,0,0,0,0,0
	defw	0,0,0,0,0,0,0,0,0,0
	defw	0,0,0,0,0,0,0,0,0,0
	defw	0,0,0,0,0,0,0,0,0,0
	defw	0,0,0,0,0,0,0,0,0,0
	defw	0,0,0,0,0,0,0,0,0,0
	defw	0,0,0,0,0,0,0,0,0,0
	defw	0,0,0,0,0,0,0,0,0,0
	defw	0,0,0,0,0,0,0,0,0,0
	defw	0,0,0,0,0,0,0,0,0,0
	defw	0,0,0,0,0,0,0,0,0,0
	defw	0,0,0,0,0,0,0,0,0,0
	defw	0,0,0,0,0,0,0,0,0,0
	defw	0,0,0,0,0,0,0,0,0,0
	defw	0,0,0,0,0,0


._matmul_hid
	ld	hl,0	;const
	push	hl
	push	bc
	jp	i_6
.i_4
	pop	de
	pop	hl
	inc	hl
	push	hl
	push	de
	dec	hl
.i_6
	pop	bc
	pop	hl
	push	hl
	push	bc
	ex	de,hl
	ld	hl,10-2	;const
	add	hl,sp
	call	l_gint	;
	call	l_lt
	jp	nc,i_5
	ld	hl,16	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,4	;const
	add	hl,sp
	call	l_gint	;
	call	l_int2long_s
	push	de
	push	hl
	ld	hl,16	;const
	add	hl,sp
	call	l_gint	;
	inc	hl
	call	l_int2long_s
	call	l_long_mult
	exx
	pop	hl
	call	l_int2long_s
	push	de
	push	hl
	exx
	call	l_long_add
	push	hl
	ld	hl,0	;const
	call	l_int2long_s
	push	de
	push	hl
	ld	hl,6	;const
	add	hl,sp
	ld	de,0	;const
	ex	de,hl
	call	l_pint
	jp	i_9
.i_7
	ld	hl,6	;const
	add	hl,sp
	push	hl
	call	l_gint	;
	inc	hl
	pop	de
	call	l_pint
	dec	hl
.i_9
	ld	hl,6	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,18	;const
	add	hl,sp
	call	l_gint	;
	pop	de
	call	l_lt
	jp	nc,i_8
	ld	hl,0	;const
	add	hl,sp
	push	hl
	call	l_glong
	push	de
	push	hl
	ld	hl,24	;const
	add	hl,sp
	call	l_gint	;
	call	l_int2long_s
	ex	de,hl
	ld	hl,14-2	;const
	add	hl,sp
	call	l_gint	;
	call	l_long_add
	call	l_gchar
	push	hl
	ld	hl,8	;const
	add	hl,sp
	call	l_gint	;
	call	l_int2long_s
	ex	de,hl
	ld	hl,12-2	;const
	add	hl,sp
	call	l_gint	;
	call	l_long_add
	call	l_gchar
	pop	de
	call	l_mult
	call	l_int2long_s
	call	l_long_add
	pop	bc
	call	l_plong
	jp	i_7
.i_8
	ld	hl,65528	;const
	add	hl,sp
	push	hl
	call	l_glong
	push	de
	push	hl
	pop	bc
	pop	hl
	push	hl
	push	bc
	ex	de,hl
	ld	hl,16-2	;const
	add	hl,sp
	call	l_gint	;
	add	hl,de
	call	l_gchar
	ld	de,128
	call	l_mult
	call	l_int2long_s
	call	l_long_add
	pop	bc
	call	l_plong
	ld	hl,65528	;const
	add	hl,sp
	push	hl
	call	l_glong
	push	de
	push	hl
	ld	hl,18	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,8	;const
	add	hl,sp
	call	l_gint	;
	pop	de
	add	hl,de
	ld	l,(hl)
	ld	h,0
	ld	de,0
	call	l_long_asr
	pop	bc
	call	l_plong
	ld	hl,65528	;const
	add	hl,sp
	call	l_glong
	xor	a
	or	d
	jp	p,i_10
	ld	hl,65528	;const
	add	hl,sp
	push	hl
	ld	hl,0	;const
	call	l_int2long_s
	pop	bc
	call	l_plong
.i_10
	ld	hl,65528	;const
	add	hl,sp
	call	l_glong
	push	de
	push	hl
	ld	hl,127	;const
	ld	de,0
	call	l_long_gt
	jp	nc,i_11
	ld	hl,65528	;const
	add	hl,sp
	push	hl
	ld	hl,127	;const
	call	l_int2long_s
	pop	bc
	call	l_plong
.i_11
	ld	hl,4	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	pop	hl
	push	hl
	push	de
	pop	de
	add	hl,de
	push	hl
	ld	hl,65530	;const
	add	hl,sp
	call	l_glong
	ld	a,l
	call	l_sxt
	ld	a,l
	call	l_sxt
	pop	de
	ld	a,l
	ld	(de),a
	push	bc
	jp	i_4
.i_5
	pop	bc
	pop	bc
	ret



._matmul_logits
	ld	hl,0	;const
	push	hl
	push	bc
	jp	i_14
.i_12
	pop	de
	pop	hl
	inc	hl
	push	hl
	push	de
	dec	hl
.i_14
	pop	bc
	pop	hl
	push	hl
	push	bc
	ex	de,hl
	ld	hl,10-2	;const
	add	hl,sp
	call	l_gint	;
	call	l_lt
	jp	nc,i_13
	ld	hl,16	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,4	;const
	add	hl,sp
	call	l_gint	;
	call	l_int2long_s
	push	de
	push	hl
	ld	hl,16	;const
	add	hl,sp
	call	l_gint	;
	inc	hl
	call	l_int2long_s
	call	l_long_mult
	exx
	pop	hl
	call	l_int2long_s
	push	de
	push	hl
	exx
	call	l_long_add
	push	hl
	ld	hl,0	;const
	call	l_int2long_s
	push	de
	push	hl
	ld	hl,6	;const
	add	hl,sp
	ld	de,0	;const
	ex	de,hl
	call	l_pint
	jp	i_17
.i_15
	ld	hl,6	;const
	add	hl,sp
	push	hl
	call	l_gint	;
	inc	hl
	pop	de
	call	l_pint
	dec	hl
.i_17
	ld	hl,6	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,18	;const
	add	hl,sp
	call	l_gint	;
	pop	de
	call	l_lt
	jp	nc,i_16
	ld	hl,0	;const
	add	hl,sp
	push	hl
	call	l_glong
	push	de
	push	hl
	ld	hl,24	;const
	add	hl,sp
	call	l_gint	;
	call	l_int2long_s
	ex	de,hl
	ld	hl,14-2	;const
	add	hl,sp
	call	l_gint	;
	call	l_long_add
	call	l_gchar
	push	hl
	ld	hl,8	;const
	add	hl,sp
	call	l_gint	;
	call	l_int2long_s
	ex	de,hl
	ld	hl,12-2	;const
	add	hl,sp
	call	l_gint	;
	call	l_long_add
	call	l_gchar
	pop	de
	call	l_mult
	call	l_int2long_s
	call	l_long_add
	pop	bc
	call	l_plong
	jp	i_15
.i_16
	ld	hl,65528	;const
	add	hl,sp
	push	hl
	call	l_glong
	push	de
	push	hl
	pop	bc
	pop	hl
	push	hl
	push	bc
	ex	de,hl
	ld	hl,16-2	;const
	add	hl,sp
	call	l_gint	;
	add	hl,de
	call	l_gchar
	ld	de,128
	call	l_mult
	call	l_int2long_s
	call	l_long_add
	pop	bc
	call	l_plong
	ld	hl,4	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	pop	hl
	push	hl
	push	de
	add	hl,hl
	add	hl,hl
	pop	de
	add	hl,de
	push	hl
	ld	hl,65530	;const
	add	hl,sp
	call	l_glong
	push	de
	push	hl
	ld	hl,18	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,8	;const
	add	hl,sp
	call	l_gint	;
	pop	de
	add	hl,de
	ld	l,(hl)
	ld	h,0
	ld	de,0
	call	l_long_asr
	pop	bc
	call	l_plong
	push	bc
	jp	i_12
.i_13
	pop	bc
	pop	bc
	ret



._rt_forward
	push	bc
	push	bc
	ld	hl,10	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,6
	add	hl,bc
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,12	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,8
	add	hl,bc
	call	l_gint	;
	pop	de
	call	l_mult
	push	hl
	ld	hl,4	;const
	add	hl,sp
	ld	de,0	;const
	ex	de,hl
	call	l_pint
	jp	i_20
.i_18
	ld	hl,4	;const
	add	hl,sp
	push	hl
	call	l_gint	;
	inc	hl
	pop	de
	call	l_pint
	dec	hl
.i_20
	ld	hl,4	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,14	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,6
	add	hl,bc
	call	l_gint	;
	pop	de
	call	l_lt
	jp	nc,i_19
	ld	hl,12	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,24
	add	hl,bc
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,12	;const
	add	hl,sp
	call	l_gint	;
	ld	de,0
	ex	de,hl
	ld	hl,8-2	;const
	add	hl,sp
	call	l_gint	;
	call	l_long_add
	call	l_gchar
	push	hl
	ld	hl,12	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,8
	add	hl,bc
	call	l_gint	;
	pop	de
	call	l_mult
	pop	de
	add	hl,de
	push	hl
	ld	hl,0	;const
	pop	bc
	push	hl
	jp	i_23
.i_21
	pop	hl
	inc	hl
	push	hl
	dec	hl
.i_23
	pop	hl
	push	hl
	push	hl
	ld	hl,12	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,8
	add	hl,bc
	call	l_gint	;
	pop	de
	call	l_lt
	jp	nc,i_22
	ld	hl,_rt_x
	push	hl
	ld	hl,4	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,14	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,8
	add	hl,bc
	call	l_gint	;
	pop	de
	call	l_mult
	ex	de,hl
	ld	hl,4-2	;const
	add	hl,sp
	call	l_gint	;
	add	hl,de
	pop	de
	add	hl,de
	push	hl
	ld	hl,65534	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,4	;const
	add	hl,sp
	call	l_gint	;
	pop	de
	add	hl,de
	call	l_gchar
	ld	a,l
	call	l_sxt
	pop	de
	ld	a,l
	ld	(de),a
	jp	i_21
.i_22
	push	bc
	jp	i_18
.i_19
	ld	hl,12	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,28
	add	hl,bc
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,14	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,26
	add	hl,bc
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,_rt_x
	push	hl
	ld	hl,6	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,20	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,10
	add	hl,bc
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,_rt_h1
	push	hl
	call	_matmul_hid
	ld	hl,12	;const
	add	hl,sp
	ld	sp,hl
	ld	hl,12	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,12
	add	hl,bc
	call	l_gint	;
	ld	a,h
	or	l
	jp	z,i_24
	ld	hl,12	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,32
	add	hl,bc
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,14	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,30
	add	hl,bc
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,_rt_h1
	push	hl
	ld	hl,18	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,10
	add	hl,bc
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,20	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,12
	add	hl,bc
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,_rt_h2
	push	hl
	call	_matmul_hid
	ld	hl,12	;const
	add	hl,sp
	ld	sp,hl
	ld	hl,_rt_h2
	ld	(_rt_hlast),hl
	ld	hl,12	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,12
	add	hl,bc
	call	l_gint	;
	ld	(_rt_hlast_n),hl
	jp	i_25
.i_24
	ld	hl,_rt_h1
	ld	(_rt_hlast),hl
	ld	hl,12	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,10
	add	hl,bc
	call	l_gint	;
	ld	(_rt_hlast_n),hl
.i_25
	ld	hl,12	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,36
	add	hl,bc
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,14	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,34
	add	hl,bc
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,(_rt_hlast)
	push	hl
	ld	hl,(_rt_hlast_n)
	push	hl
	ld	hl,20	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,4
	add	hl,bc
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,18	;const
	add	hl,sp
	call	l_gint	;
	push	hl
	call	_matmul_logits
	exx
	ld	hl,12	;const
	add	hl,sp
	ld	sp,hl
	exx
	pop	bc
	pop	bc
	pop	bc
	ret



._rt_last_hidden
	ld	hl,4	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,(_rt_hlast)
	call	l_pint
	pop	bc
	pop	hl
	push	hl
	push	bc
	ex	de,hl
	ld	hl,(_rt_hlast_n)
	call	l_pint
	ret



._rt_rand
	pop	bc
	pop	hl
	push	hl
	push	bc
	call	l_glong
	push	de
	push	hl
	ld	hl,0	;const
	add	hl,sp
	push	hl
	ld	hl,2	;const
	add	hl,sp
	call	l_glong
	push	de
	push	hl
	ld	hl,6	;const
	add	hl,sp
	call	l_glong
	ld	a,#(13 % 256)
	call	l_long_aslo
	push	de
	push	hl
	ld	hl,65535	;const
	ld	de,65535
	call	l_long_and
	call	l_long_xor
	push	de
	push	hl
	ld	hl,65535	;const
	ld	de,65535
	call	l_long_and
	pop	bc
	call	l_plong
	ld	hl,0	;const
	add	hl,sp
	push	hl
	ld	hl,2	;const
	add	hl,sp
	call	l_glong
	push	de
	push	hl
	ld	hl,6	;const
	add	hl,sp
	call	l_glong
	ld	c,#(17 % 256)
	call	l_long_asr_uo
	call	l_long_xor
	push	de
	push	hl
	ld	hl,65535	;const
	ld	de,65535
	call	l_long_and
	pop	bc
	call	l_plong
	ld	hl,0	;const
	add	hl,sp
	push	hl
	ld	hl,2	;const
	add	hl,sp
	call	l_glong
	push	de
	push	hl
	ld	hl,6	;const
	add	hl,sp
	call	l_glong
	ld	a,#(5 % 256)
	call	l_long_aslo
	push	de
	push	hl
	ld	hl,65535	;const
	ld	de,65535
	call	l_long_and
	call	l_long_xor
	push	de
	push	hl
	ld	hl,65535	;const
	ld	de,65535
	call	l_long_and
	pop	bc
	call	l_plong
	ld	hl,6	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,2	;const
	add	hl,sp
	call	l_glong
	pop	bc
	call	l_plong
	ld	hl,0	;const
	add	hl,sp
	call	l_glong
	pop	bc
	pop	bc
	ret



._rt_sample
	push	bc
	ld	hl,0	;const
	push	hl
	ld	hl,12	;const
	add	hl,sp
	call	l_gint	;
	call	l_glong
	push	de
	push	hl
	ld	hl,65440	;const
	add	hl,sp
	ld	sp,hl
	ld	hl,0	;const
	call	l_int2long_s
	push	de
	push	hl
	push	bc
	push	bc
	ld	hl,0	;const
	call	l_int2long_s
	push	de
	push	hl
	ld	hl,114	;const
	add	hl,sp
	ld	de,1	;const
	ex	de,hl
	call	l_pint
	jp	i_28
.i_26
	ld	hl,114	;const
	add	hl,sp
	push	hl
	call	l_gint	;
	inc	hl
	pop	de
	call	l_pint
	dec	hl
.i_28
	ld	hl,114	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,128	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,4
	add	hl,bc
	call	l_gint	;
	pop	de
	call	l_lt
	jp	nc,i_27
	ld	hl,124	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,116	;const
	add	hl,sp
	call	l_gint	;
	add	hl,hl
	add	hl,hl
	pop	de
	add	hl,de
	call	l_glong
	push	de
	push	hl
	ld	hl,112	;const
	add	hl,sp
	call	l_glong
	call	l_long_gt
	jp	nc,i_29
	ld	hl,108	;const
	add	hl,sp
	push	hl
	ld	hl,126	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,118	;const
	add	hl,sp
	call	l_gint	;
	add	hl,hl
	add	hl,hl
	pop	de
	add	hl,de
	call	l_glong
	pop	bc
	call	l_plong
	ld	hl,112	;const
	add	hl,sp
	ex	de,hl
	ld	hl,116-2	;const
	add	hl,sp
	call	l_gint	;
	call	l_pint
.i_29
	jp	i_26
.i_27
	ld	hl,120	;const
	add	hl,sp
	call	l_gint	;
	ld	a,h
	or	l
	jp	z,i_30
	ld	hl,112	;const
	add	hl,sp
	call	l_gint	;
	exx
	ld	hl,116	;const
	add	hl,sp
	ld	sp,hl
	exx
	ret


.i_30
	ld	hl,114	;const
	add	hl,sp
	ld	de,0	;const
	ex	de,hl
	call	l_pint
	jp	i_33
.i_31
	ld	hl,114	;const
	add	hl,sp
	push	hl
	call	l_gint	;
	inc	hl
	pop	de
	call	l_pint
	dec	hl
.i_33
	ld	hl,114	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,128	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,4
	add	hl,bc
	call	l_gint	;
	pop	de
	call	l_lt
	jp	nc,i_32
	ld	hl,108	;const
	add	hl,sp
	call	l_glong
	push	de
	push	hl
	ld	hl,128	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,120	;const
	add	hl,sp
	call	l_gint	;
	add	hl,hl
	add	hl,hl
	pop	de
	add	hl,de
	call	l_glong
	call	l_long_sub
	push	de
	push	hl
	ld	hl,126	;const
	add	hl,sp
	call	l_gint	;
	call	l_int2long_s
	call	l_long_asr
	push	de
	push	hl
	ld	hl,0	;const
	add	hl,sp
	call	l_glong
	ld	c,#(3 % 256)
	call	l_long_asro
	push	hl
	ld	de,255	;const
	ex	de,hl
	call	l_gt
	jp	nc,i_34
	ld	hl,255	;const
	pop	bc
	push	hl
.i_34
	ld	hl,18	;const
	add	hl,sp
	push	hl
	ld	hl,122	;const
	add	hl,sp
	call	l_gint	;
	add	hl,hl
	pop	de
	add	hl,de
	push	hl
	ld	hl,_RT_EXP_LUT
	push	hl
	ld	hl,4	;const
	add	hl,sp
	call	l_gint	;
	add	hl,hl
	pop	de
	add	hl,de
	call	l_gint	;
	pop	de
	call	l_pint
	ld	hl,14	;const
	add	hl,sp
	push	hl
	call	l_glong
	push	de
	push	hl
	ld	hl,24	;const
	add	hl,sp
	push	hl
	ld	hl,128	;const
	add	hl,sp
	call	l_gint	;
	add	hl,hl
	pop	de
	add	hl,de
	call	l_gint	;
	ld	de,0
	call	l_long_add
	pop	bc
	call	l_plong
	pop	bc
	pop	bc
	pop	bc
	jp	i_31
.i_32
	ld	hl,8	;const
	add	hl,sp
	call	l_glong
	ld	a,h
	or	l
	or	d
	or	e
	jp	nz,i_35
	ld	hl,112	;const
	add	hl,sp
	call	l_gint	;
	exx
	ld	hl,116	;const
	add	hl,sp
	ld	sp,hl
	exx
	ret


.i_35
	ld	hl,4	;const
	add	hl,sp
	push	hl
	ld	hl,120	;const
	add	hl,sp
	call	l_gint	;
	push	hl
	call	_rt_rand
	pop	bc
	push	de
	push	hl
	ld	hl,14	;const
	add	hl,sp
	call	l_glong
	call	l_long_div
	exx
	pop	bc
	call	l_plong
	ld	hl,114	;const
	add	hl,sp
	ld	de,0	;const
	ex	de,hl
	call	l_pint
	jp	i_38
.i_36
	ld	hl,114	;const
	add	hl,sp
	push	hl
	call	l_gint	;
	inc	hl
	pop	de
	call	l_pint
	dec	hl
.i_38
	ld	hl,114	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,128	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,4
	add	hl,bc
	call	l_gint	;
	pop	de
	call	l_lt
	jp	nc,i_37
	ld	hl,0	;const
	add	hl,sp
	push	hl
	call	l_glong
	push	de
	push	hl
	ld	hl,18	;const
	add	hl,sp
	push	hl
	ld	hl,122	;const
	add	hl,sp
	call	l_gint	;
	add	hl,hl
	pop	de
	add	hl,de
	call	l_gint	;
	ld	de,0
	call	l_long_add
	pop	bc
	call	l_plong
	ld	hl,4	;const
	add	hl,sp
	call	l_glong
	push	de
	push	hl
	ld	hl,4	;const
	add	hl,sp
	call	l_glong
	call	l_long_ult
	jp	nc,i_39
	ld	hl,114	;const
	add	hl,sp
	call	l_gint	;
	exx
	ld	hl,116	;const
	add	hl,sp
	ld	sp,hl
	exx
	ret


.i_39
	jp	i_36
.i_37
	ld	hl,112	;const
	add	hl,sp
	call	l_gint	;
	exx
	ld	hl,116	;const
	add	hl,sp
	ld	sp,hl
	exx
	ret




; --- Start of Static Variables ---

._rt_h1	defs	18
._rt_h2	defs	18
._rt_x	defs	80
._rt_hlast	defs	2
._rt_hlast_n	defs	2


; --- Start of Scope Defns ---

	XDEF	_rt_last_hidden
	XDEF	_rt_forward
	XDEF	_RT_EXP_LUT
	XREF	_rt_model_load
	XREF	_rt_model_size
	XDEF	_rt_sample
	XDEF	_rt_rand


; --- End of Scope Defns ---


; --- End of Compilation ---
