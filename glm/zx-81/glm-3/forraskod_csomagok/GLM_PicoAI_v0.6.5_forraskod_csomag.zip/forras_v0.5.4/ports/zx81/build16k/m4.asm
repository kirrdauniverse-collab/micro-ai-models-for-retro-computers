;* * * * *  Small-C/Plus z88dk * * * * *
;  Version: 20070909.1
;
;	Reconstructed for the z80 Module Assembler
;
;	Module compile time: Fri Nov 20 17:01:17 2026



	MODULE	rt_model.c

	INCLUDE "z80_crt0.hdr"



._rd16
	pop	bc
	pop	hl
	push	hl
	push	bc
	ld	l,(hl)
	ld	h,0
	push	hl
	ld	hl,4	;const
	add	hl,sp
	call	l_gint	;
	inc	hl
	ld	e,(hl)
	ld	d,0
	ld	l,#(8 % 256)
	call	l_asl
	pop	de
	call	l_or
	ret



._rt_model_size
	push	bc
	push	bc
	ld	hl,0	;const
	add	hl,sp
	push	hl
	ld	hl,92	;const
	call	l_int2long_s
	pop	bc
	call	l_plong
	ld	hl,0	;const
	add	hl,sp
	push	hl
	call	l_glong
	push	de
	push	hl
	ld	hl,12	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,4
	add	hl,bc
	call	l_gint	;
	ld	de,0
	push	de
	push	hl
	ld	hl,16	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,8
	add	hl,bc
	call	l_gint	;
	ld	de,0
	call	l_long_mult
	call	l_long_add
	pop	bc
	call	l_plong
	ld	hl,0	;const
	add	hl,sp
	push	hl
	call	l_glong
	push	de
	push	hl
	ld	hl,12	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,10
	add	hl,bc
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,14	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,10
	add	hl,bc
	call	l_gint	;
	ld	de,0
	push	de
	push	hl
	ld	hl,18	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,6
	add	hl,bc
	call	l_gint	;
	ld	de,0
	push	de
	push	hl
	ld	hl,22	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,8
	add	hl,bc
	call	l_gint	;
	ld	de,0
	call	l_long_mult
	inc	hl
	call	l_long_mult
	exx
	pop	hl
	ld	de,0
	push	de
	push	hl
	exx
	call	l_long_add
	call	l_long_add
	pop	bc
	call	l_plong
	ld	hl,6	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,12
	add	hl,bc
	call	l_gint	;
	ld	a,h
	or	l
	jp	z,i_3
	ld	hl,0	;const
	add	hl,sp
	push	hl
	call	l_glong
	push	de
	push	hl
	ld	hl,12	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,12
	add	hl,bc
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,14	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,12
	add	hl,bc
	call	l_gint	;
	ld	de,0
	push	de
	push	hl
	ld	hl,18	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,10
	add	hl,bc
	call	l_gint	;
	inc	hl
	ld	de,0
	call	l_long_mult
	exx
	pop	hl
	ld	de,0
	push	de
	push	hl
	exx
	call	l_long_add
	call	l_long_add
	pop	bc
	call	l_plong
.i_3
	ld	hl,0	;const
	add	hl,sp
	push	hl
	call	l_glong
	push	de
	push	hl
	ld	hl,12	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,4
	add	hl,bc
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,14	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,4
	add	hl,bc
	call	l_gint	;
	ld	de,0
	push	de
	push	hl
	ld	hl,18	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,12
	add	hl,bc
	call	l_gint	;
	ld	a,h
	or	l
	jp	z,i_4
	ld	hl,18	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,12
	add	hl,bc
	call	l_gint	;
	jp	i_5
.i_4
	ld	hl,18	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,10
	add	hl,bc
	call	l_gint	;
.i_5
	inc	hl
	ld	de,0
	call	l_long_mult
	exx
	pop	hl
	ld	de,0
	push	de
	push	hl
	exx
	call	l_long_add
	call	l_long_add
	pop	bc
	call	l_plong
	ld	hl,0	;const
	add	hl,sp
	push	hl
	call	l_glong
	call	l_inclong
	call	l_inclong
	pop	bc
	call	l_plong
	ld	hl,0	;const
	add	hl,sp
	call	l_glong
	pop	bc
	pop	bc
	ret



._rt_model_load
	ld	hl,6	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,65504	;const
	add	hl,sp
	ld	sp,hl
	ld	hl,36	;const
	add	hl,sp
	call	l_glong
	push	de
	push	hl
	ld	hl,94	;const
	ld	de,0
	call	l_long_lt
	jp	nc,i_6
	ld	hl,34	;const
	add	hl,sp
	ld	sp,hl
	ld	hl,65535	;const
	ret


.i_6
	ld	hl,32	;const
	add	hl,sp
	call	l_gint	;
	ld	a,(hl)
	cp	#(82 % 256)
	jp	nz,i_8
	ld	hl,32	;const
	add	hl,sp
	call	l_gint	;
	inc	hl
	ld	a,(hl)
	cp	#(84 % 256)
	jp	nz,i_8
	ld	hl,32	;const
	add	hl,sp
	call	l_gint	;
	inc	hl
	inc	hl
	ld	a,(hl)
	cp	#(76 % 256)
	jp	nz,i_8
	ld	hl,32	;const
	add	hl,sp
	call	l_gint	;
	inc	hl
	inc	hl
	inc	hl
	ld	a,(hl)
	cp	#(77 % 256)
	jp	z,i_7
.i_8
	ld	hl,34	;const
	add	hl,sp
	ld	sp,hl
	ld	hl,65534	;const
	ret


.i_7
	ld	hl,8	;const
	add	hl,sp
	push	hl
	ld	hl,34	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,4
	add	hl,bc
	push	hl
	call	_rd16
	pop	bc
	pop	de
	call	l_pint
	ld	hl,8	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,2	;const
	call	l_ne
	jp	nc,i_10
	ld	hl,34	;const
	add	hl,sp
	ld	sp,hl
	ld	hl,65533	;const
	ret


.i_10
	ld	hl,8+1+1	;const
	add	hl,sp
	push	hl
	ld	hl,34	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,6
	add	hl,bc
	push	hl
	call	_rd16
	pop	bc
	pop	de
	call	l_pint
	ld	hl,8+4	;const
	add	hl,sp
	push	hl
	ld	hl,34	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,8
	add	hl,bc
	push	hl
	call	_rd16
	pop	bc
	pop	de
	call	l_pint
	ld	hl,8+6	;const
	add	hl,sp
	push	hl
	ld	hl,34	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,10
	add	hl,bc
	push	hl
	call	_rd16
	pop	bc
	pop	de
	call	l_pint
	ld	hl,8+8	;const
	add	hl,sp
	push	hl
	ld	hl,34	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,12
	add	hl,bc
	push	hl
	call	_rd16
	pop	bc
	pop	de
	call	l_pint
	ld	hl,8+10	;const
	add	hl,sp
	push	hl
	ld	hl,34	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,14
	add	hl,bc
	push	hl
	call	_rd16
	pop	bc
	pop	de
	call	l_pint
	ld	hl,8+12	;const
	add	hl,sp
	push	hl
	ld	hl,34	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,16
	add	hl,bc
	push	hl
	call	_rd16
	pop	bc
	pop	de
	call	l_pint
	ld	hl,8+14	;const
	add	hl,sp
	push	hl
	ld	hl,34	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,18
	add	hl,bc
	push	hl
	call	_rd16
	pop	bc
	pop	de
	call	l_pint
	ld	hl,8+16	;const
	add	hl,sp
	push	hl
	ld	hl,34	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,20
	add	hl,bc
	push	hl
	call	_rd16
	pop	bc
	pop	de
	call	l_pint
	ld	hl,8+18	;const
	add	hl,sp
	push	hl
	ld	hl,34	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,22
	add	hl,bc
	push	hl
	call	_rd16
	pop	bc
	pop	de
	call	l_pint
	ld	hl,8+20	;const
	add	hl,sp
	push	hl
	ld	hl,34	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,24
	add	hl,bc
	push	hl
	call	_rd16
	pop	bc
	pop	de
	call	l_pint
	ld	hl,8+22	;const
	add	hl,sp
	push	hl
	ld	hl,34	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,26
	add	hl,bc
	push	hl
	call	_rd16
	pop	bc
	pop	de
	call	l_pint
	ld	hl,8+4	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,0	;const
	call	l_eq
	jp	c,i_12
	ld	hl,8+4	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,48	;const
	call	l_ugt
	jp	c,i_12
	ld	hl,8+6	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,0	;const
	call	l_eq
	jp	c,i_12
	ld	hl,8+6	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,8	;const
	call	l_ugt
	jp	c,i_12
	ld	hl,8+8	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,0	;const
	call	l_eq
	jp	c,i_12
	ld	hl,8+8	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,10	;const
	call	l_ugt
	jp	c,i_12
	ld	hl,8+10	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,0	;const
	call	l_eq
	jp	c,i_12
	ld	hl,8+10	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,18	;const
	call	l_ugt
	jp	c,i_12
	ld	hl,8+12	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,18	;const
	call	l_ugt
	jp	nc,i_11
.i_12
	ld	hl,34	;const
	add	hl,sp
	ld	sp,hl
	ld	hl,65532	;const
	ret


.i_11
	ld	hl,8+4	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,48	;const
	call	l_ne
	jp	nc,i_14
	ld	hl,34	;const
	add	hl,sp
	ld	sp,hl
	ld	hl,65531	;const
	ret


.i_14
	ld	hl,0	;const
	add	hl,sp
	push	hl
	ld	hl,0	;const
	call	l_int2long_s
	pop	bc
	call	l_plong
	jp	i_17
.i_15
	ld	hl,0	;const
	add	hl,sp
	push	hl
	call	l_glong
	call	l_inclong
	pop	bc
	call	l_plong
	call	l_declong
.i_17
	ld	hl,0	;const
	add	hl,sp
	call	l_glong
	push	de
	push	hl
	ld	hl,48	;const
	ld	de,0
	call	l_long_lt
	jp	nc,i_16
	ld	hl,32	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,2	;const
	add	hl,sp
	call	l_glong
	ld	de,28
	add	hl,de
	pop	de
	add	hl,de
	ld	l,(hl)
	ld	h,0
	push	hl
	ld	hl,_RT_CHARSET
	push	hl
	ld	hl,4	;const
	add	hl,sp
	call	l_glong
	pop	de
	add	hl,de
	call	l_gchar
	ld	h,0
	pop	de
	call	l_ne
	jp	nc,i_18
	ld	hl,34	;const
	add	hl,sp
	ld	sp,hl
	ld	hl,65530	;const
	ret


.i_18
	jp	i_15
.i_16
	ld	hl,4	;const
	add	hl,sp
	push	hl
	ld	hl,10	;const
	add	hl,sp
	push	hl
	call	_rt_model_size
	pop	bc
	pop	bc
	call	l_plong
	ld	hl,4	;const
	add	hl,sp
	call	l_glong
	push	de
	push	hl
	ld	hl,40	;const
	add	hl,sp
	call	l_glong
	call	l_long_gt
	jp	nc,i_19
	ld	hl,34	;const
	add	hl,sp
	ld	sp,hl
	ld	hl,65528	;const
	ret


.i_19
	ld	hl,0	;const
	call	l_int2long_s
	push	de
	push	hl
	ld	hl,8	;const
	add	hl,sp
	call	l_glong
	push	de
	push	hl
	ld	hl,65534	;const
	ld	de,65535
	call	l_long_add
	push	de
	push	hl
	ld	hl,8	;const
	add	hl,sp
	push	hl
	ld	hl,0	;const
	call	l_int2long_s
	pop	bc
	call	l_plong
	jp	i_22
.i_20
	ld	hl,8	;const
	add	hl,sp
	push	hl
	call	l_glong
	call	l_inclong
	pop	bc
	call	l_plong
	call	l_declong
.i_22
	ld	hl,8	;const
	add	hl,sp
	call	l_glong
	push	de
	push	hl
	ld	hl,4	;const
	add	hl,sp
	call	l_glong
	call	l_long_lt
	jp	nc,i_21
	ld	hl,4	;const
	add	hl,sp
	push	hl
	call	l_glong
	push	de
	push	hl
	ld	hl,46	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,16	;const
	add	hl,sp
	call	l_glong
	pop	de
	add	hl,de
	ld	l,(hl)
	ld	h,0
	ld	de,0
	call	l_long_add
	push	de
	push	hl
	ld	hl,65535	;const
	ld	de,0
	call	l_long_and
	pop	bc
	call	l_plong
	jp	i_20
.i_21
	ld	hl,4	;const
	add	hl,sp
	call	l_glong
	push	hl
	ld	hl,42	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,4	;const
	add	hl,sp
	call	l_glong
	exx
	pop	hl
	ld	de,0
	push	de
	push	hl
	exx
	call	l_long_add
	push	de
	push	hl
	call	_rd16
	pop	bc
	pop	bc
	pop	de
	call	l_ne
	jp	nc,i_23
	ld	hl,42	;const
	add	hl,sp
	ld	sp,hl
	ld	hl,65529	;const
	ret


.i_23
	pop	bc
	pop	bc
	pop	bc
	pop	bc
	ld	hl,42	;const
	add	hl,sp
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,10	;const
	add	hl,sp
	push	hl
	ld	hl,24	;const
	push	hl
	call	memcpy_callee
	ld	hl,42	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,38
	add	hl,bc
	ex	de,hl
	ld	hl,42-2	;const
	add	hl,sp
	call	l_gint	;
	call	l_pint
	ld	hl,32	;const
	add	hl,sp
	push	hl
	ld	hl,42	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,92
	add	hl,bc
	pop	de
	call	l_pint
	ld	hl,42	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,24
	add	hl,bc
	ex	de,hl
	ld	hl,34-2	;const
	add	hl,sp
	call	l_gint	;
	call	l_pint
	ld	hl,32	;const
	add	hl,sp
	push	hl
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,12+4	;const
	add	hl,sp
	call	l_gint	;
	ld	de,0
	push	de
	push	hl
	ld	hl,16+8	;const
	add	hl,sp
	call	l_gint	;
	ld	de,0
	call	l_long_mult
	exx
	pop	hl
	ld	de,0
	push	de
	push	hl
	exx
	call	l_long_add
	pop	de
	call	l_pint
	ld	hl,42	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,26
	add	hl,bc
	ex	de,hl
	ld	hl,34-2	;const
	add	hl,sp
	call	l_gint	;
	call	l_pint
	ld	hl,32	;const
	add	hl,sp
	push	hl
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,12+10	;const
	add	hl,sp
	call	l_gint	;
	pop	de
	add	hl,de
	pop	de
	call	l_pint
	ld	hl,42	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,28
	add	hl,bc
	ex	de,hl
	ld	hl,34-2	;const
	add	hl,sp
	call	l_gint	;
	call	l_pint
	ld	hl,32	;const
	add	hl,sp
	push	hl
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,12+10	;const
	add	hl,sp
	call	l_gint	;
	ld	de,0
	push	de
	push	hl
	ld	hl,16+6	;const
	add	hl,sp
	call	l_gint	;
	ld	de,0
	push	de
	push	hl
	ld	hl,20+8	;const
	add	hl,sp
	call	l_gint	;
	ld	de,0
	call	l_long_mult
	inc	hl
	call	l_long_mult
	exx
	pop	hl
	ld	de,0
	push	de
	push	hl
	exx
	call	l_long_add
	pop	de
	call	l_pint
	ld	hl,8+12	;const
	add	hl,sp
	call	l_gint	;
	ld	a,h
	or	l
	jp	z,i_24
	ld	hl,42	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,30
	add	hl,bc
	ex	de,hl
	ld	hl,34-2	;const
	add	hl,sp
	call	l_gint	;
	call	l_pint
	ld	hl,32	;const
	add	hl,sp
	push	hl
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,12+12	;const
	add	hl,sp
	call	l_gint	;
	pop	de
	add	hl,de
	pop	de
	call	l_pint
	ld	hl,42	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,32
	add	hl,bc
	ex	de,hl
	ld	hl,34-2	;const
	add	hl,sp
	call	l_gint	;
	call	l_pint
	ld	hl,32	;const
	add	hl,sp
	push	hl
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,12+12	;const
	add	hl,sp
	call	l_gint	;
	ld	de,0
	push	de
	push	hl
	ld	hl,16+10	;const
	add	hl,sp
	call	l_gint	;
	inc	hl
	ld	de,0
	call	l_long_mult
	exx
	pop	hl
	ld	de,0
	push	de
	push	hl
	exx
	call	l_long_add
	pop	de
	call	l_pint
	jp	i_25
.i_24
	ld	hl,42	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,30
	add	hl,bc
	ld	(hl),#(0 % 256)
	inc	hl
	ld	(hl),#(0 / 256)
	ld	hl,42	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,32
	add	hl,bc
	ld	de,0	;const
	ex	de,hl
	call	l_pint
.i_25
	ld	hl,42	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,34
	add	hl,bc
	ex	de,hl
	ld	hl,34-2	;const
	add	hl,sp
	call	l_gint	;
	call	l_pint
	ld	hl,32	;const
	add	hl,sp
	push	hl
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	push	de
	ld	hl,12+4	;const
	add	hl,sp
	call	l_gint	;
	pop	de
	add	hl,de
	pop	de
	call	l_pint
	ld	hl,42	;const
	add	hl,sp
	call	l_gint	;
	ld	bc,36
	add	hl,bc
	ex	de,hl
	ld	hl,34-2	;const
	add	hl,sp
	call	l_gint	;
	call	l_pint
	ld	hl,34	;const
	add	hl,sp
	ld	sp,hl
	ld	hl,0	;const
	ret




; --- Start of Static Variables ---



; --- Start of Scope Defns ---

	LIB	strcmp
	LIB	strcpy
	LIB	strlen
	LIB	strdup
	LIB	strrev
	LIB	strpos
	LIB	strlwr
	LIB	strtok
	LIB	strspn
	LIB	bcopy
	LIB	strstr
	LIB	strupr
	LIB	memopd_callee
	LIB	stricmp
	LIB	strncat
	LIB	strcspn
	LIB	strncmp
	LIB	strncpy
	LIB	strpbrk
	LIB	strrchr
	LIB	index
	LIB	bzero
	LIB	strtok_callee
	LIB	strpos_callee
	LIB	strcasecmp
	LIB	strrstr
	LIB	memmove
	LIB	memswap
	LIB	strcat_callee
	LIB	strncat_callee
	LIB	strrstrip_callee
	LIB	strstrip_callee
	LIB	strcspn_callee
	LIB	strspn_callee
	LIB	memset_callee
	XREF	_rt_charset_init
	LIB	strrstrip
	LIB	strnicmp
	LIB	bcmp
	XDEF	_rt_model_load
	XREF	_RT_CHARSET
	LIB	memchr
	XREF	_RT_CHAR_TO_IDX
	LIB	memcmp
	LIB	memcpy
	XDEF	_rt_model_size
	LIB	memopd
	LIB	memopi
	LIB	memset
	LIB	strstrip
	LIB	strcpy_callee
	LIB	strncpy_callee
	LIB	memcpy_callee
	LIB	memmove_callee
	LIB	memopi_callee
	LIB	strncasecmp
	LIB	rindex
	LIB	strcmp_callee
	LIB	strncmp_callee
	LIB	strchr_callee
	LIB	strrchr_callee
	LIB	strstr_callee
	LIB	strrstr_callee
	LIB	stricmp_callee
	LIB	strnicmp_callee
	LIB	memchr_callee
	LIB	memcmp_callee
	LIB	memswap_callee
	XREF	_rt_map_char
	LIB	strpbrk_callee
	LIB	strcat
	LIB	strchr


; --- End of Scope Defns ---


; --- End of Compilation ---
