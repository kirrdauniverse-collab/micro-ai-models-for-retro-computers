# 1 "../../hal_zx81.c"

# 15 "/home/z/my-project/tools/z88dk-deb/root/usr/share/z88dk/include/sys/types.h"
typedef unsigned int size_t;




typedef signed int ssize_t;




typedef unsigned long clock_t;




typedef signed int pid_t;




typedef unsigned char bool_t;




typedef long time_t;




typedef short wild_t;




typedef unsigned long fpos_t;



typedef unsigned char u8_t;
typedef unsigned short u16_t;
typedef unsigned long u32_t;

typedef char i8_t;
typedef short i16_t;
typedef long i32_t;
# 66
typedef unsigned char uchar;




typedef unsigned int uint;
# 96 "/home/z/my-project/tools/z88dk-deb/root/usr/share/z88dk/include/zx81.h"
extern int base_graphics;


extern void __LIB__ _clg_hr();


extern void __LIB__ hrg_off();
extern void __LIB__ hrg_on();


extern void __LIB__ __FASTCALL__ copytxt(int ovmode);
# 124
extern void __LIB__ invtxt();


extern void __LIB__ mirrortxt();



extern void __LIB__ __FASTCALL__ zx_asciimode();


extern char __LIB__ zx_ascii(char character);


extern char __LIB__ ascii_zx(char character);


extern void __LIB__ zx_fast();
extern void __LIB__ zx_slow();
# 148
extern int __LIB__ zx_basic_length(void);
extern int __LIB__ zx_var_length(void);
# 157
extern int __LIB__ __FASTCALL__ zx_line(int line);

extern int __LIB__ zx_getstr(char variable, char *value);
extern void __LIB__ zx_setstr(char variable, char *value);



extern int __LIB__ __CALLEE__ zx_getstr_callee(char variable, char *value);
extern void __LIB__ __CALLEE__ zx_setstr_callee(char variable, char *value);
# 30 "/home/z/my-project/tools/z88dk-deb/root/usr/share/z88dk/include/fcntl.h"
typedef int mode_t;


extern int __LIB__ open(far char *name, int flags, mode_t mode);
extern int __LIB__ creat(far char *name, mode_t mode);
extern int __LIB__ close(int fd);
extern size_t __LIB__ read(int fd, void *ptr, size_t len);
extern size_t __LIB__ write(int fd, void *ptr, size_t len);
extern long __LIB__ lseek(int fd,long posn, int whence);
extern long __LIB__ tell(int fd);

extern int __LIB__ __FASTCALL__ readbyte(int fd);
extern int __LIB__ writebyte(int fd, int c);



extern int __LIB__ open_z88(far char *name, int flags, mode_t mode, char *explicit, size_t len);



extern int __LIB__ nropen(char *name, int flags, mode_t mode, char *explicit, size_t len);

extern int __LIB__ mkdir(char *, int mode);
extern char __LIB__ *getcwd(char *buf, size_t maxlen);


extern int __LIB__ rmdir(char *);
extern char __LIB__ *getwd(char *buf);

#pragma  output ANSIstdio
# 56 "/home/z/my-project/tools/z88dk-deb/root/usr/share/z88dk/include/stdio.h"
struct filestr {
union f0xx {
int fd;
u8_t *ptr;
} desc;
u8_t flags;
u8_t ungetc;
};
#asm
#endasm
# 94
extern struct filestr _sgoioblk[10];
# 113
extern struct filestr __LIB__ *fopen(far char *name, unsigned char *mode);
extern struct filestr __LIB__ *fopen_z88(far char *name, unsigned char *mode, unsigned char *explicit, size_t len);
extern struct filestr __LIB__ *freopen(far char *name, unsigned char *mode, struct filestr *fp);
extern struct filestr __LIB__ *freopen_z88(far char *n, unsigned char *m, struct filestr *fp, unsigned char *explicit, size_t len);
extern struct filestr __LIB__ *fdopen(int fildes, unsigned char *mode);

extern int __LIB__ fclose(struct filestr *fp);

extern void __LIB__ closeall();


extern char __LIB__ *fgets(unsigned char *s, int, struct filestr *fp);
extern int __LIB__ fputs(unsigned char *s, struct filestr *fp);
extern int __LIB__ fputc(int c, struct filestr *fp);

extern int __LIB__ fgetc(struct filestr *fp);
extern int __LIB__ ungetc(int c, struct filestr *);
extern int __LIB__ feof(struct filestr *fp);
extern int __LIB__ puts(unsigned char *);


extern fpos_t __LIB__ ftell(struct filestr *fp);
extern int __LIB__ fgetpos(struct filestr *fp, fpos_t *pos);


extern int __LIB__ fseek(struct filestr *fp, fpos_t offset, int whence);


extern int __LIB__ fread(void *ptr, int size, int num, struct filestr *);
extern int __LIB__ fwrite(void *ptr, int size, int num, struct filestr *);



extern int __LIB__ gets(char *s);
# 159
extern int __LIB__ printf(char *,...);
extern int __LIB__ fprintf(struct filestr *,char *,...);
extern int __LIB__ sprintf(char *,char *,...);
extern int vfprintf(struct filestr *,unsigned char *fmt,void *ap);
extern int __LIB__ vsprintf(char *str,unsigned char *fmt,void *ap);
# 169
extern int __LIB__ vfprintf_mini(struct filestr *, unsigned char *, void *);
extern int __LIB__ vfprintf_comp(struct filestr *, unsigned char *, void *);
extern int __LIB__ vfprintf_fp(struct filestr *, unsigned char *, void *);

extern __LIB__ printn(int number, int radix,struct filestr *file);
extern int __LIB__ ltoa_any(long in,unsigned char *str, int sz, unsigned int radix, int signflag);
# 181
extern int __LIB__ scanf(unsigned char *fmt,...);
extern int __LIB__ fscanf(struct filestr *,unsigned char *fmt,...);
extern int __LIB__ sscanf(char *,unsigned char *fmt,...);
extern int __LIB__ vfscanf(struct filestr *, unsigned char *fmt, void *ap);
extern int __LIB__ vsscanf(char *str, unsigned char *fmt, void *ap);
# 195
extern int __LIB__ getarg(void);
# 209
extern int __LIB__ fchkstd(struct filestr *);


extern int __LIB__ fgetc_cons();
extern int __LIB__ fputc_cons(char c);
extern int __LIB__ fgets_cons(char *s, int n);

extern void __LIB__ fabandon(struct filestr *);

extern long __LIB__ fdtell(int fd);
extern int __LIB__ fdgetpos(int fd, fpos_t *posn);

extern int __LIB__ rename(char *s, char *d);

extern int __LIB__ remove(char *name);
# 234
extern int __LIB__ getk();

extern void __LIB__ puts_cons();
extern void __LIB__ printk(char *fmt,...);
# 16 "../../../../engine/rt_types.h"
typedef signed char rt_i8;
typedef unsigned char rt_u8;
typedef short rt_i16;
typedef unsigned short rt_u16;
typedef long rt_i32;
typedef unsigned long rt_u32;
# 15 "../../../../engine/rt_hal.h"
long hal_load_file(const char *name, rt_u8 *buf, long maxlen);


int hal_save_file(const char *name, const rt_u8 *buf, long len);
# 23
long hal_tape_load(int index, rt_u8 *buf, long maxlen);


int hal_tape_save(int index, const rt_u8 *buf, long len);
# 31
int hal_getchar(void);
int hal_kbhit(void);
void hal_putchar(int c);
void hal_flush(void);
void hal_msleep(long ms);


rt_u32 hal_entropy(void);
# 44
int hal_list_topics(char *names, int max);
# 53
long hal_scratch_cells(void);
int hal_scratch_bits(void);
rt_u8 hal_scratch_get(long i);
void hal_scratch_put(long i, rt_u8 v);


void hal_panic(const char *msg);
# 33 "../../hal_zx81.c"
static const signed char ZX81_TO_ASCII[64] = {
# 39
' ', -1, -1, -1, -1, -1, -1, -1,
-1, -1, -1, '"', -1, '$', ':', '?',
'(', ')', '>', '<', '=', '+', '-', '*',
'/', ';', ',', '.', '0', '1', '2', '3',
'4', '5', '6', '7', '8', '9', 'a', 'b',
'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j',
'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r',
's', 't', 'u', 'v', 'w', 'x', 'y', 'z',
};

static const rt_u8 ASCII_TO_ZX81[96] = {
# 57
0x00, 0x00, 0x0B, 0x00, 0x0D, 0x00, 0x00, 0x00,
0x10, 0x11, 0x17, 0x15, 0x1A, 0x16, 0x1B, 0x18,
0x1C, 0x1D, 0x1E, 0x1F, 0x20, 0x21, 0x22, 0x23,
0x24, 0x25, 0x0E, 0x19, 0x13, 0x14, 0x12, 0x0F,
0x00, 0x26, 0x27, 0x28, 0x29, 0x2A, 0x2B, 0x2C,
0x2D, 0x2E, 0x2F, 0x30, 0x31, 0x32, 0x33, 0x34,
0x35, 0x36, 0x37, 0x38, 0x39, 0x3A, 0x3B, 0x3C,
0x3D, 0x3E, 0x3F, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x26, 0x27, 0x28, 0x29, 0x2A, 0x2B, 0x2C,
0x2D, 0x2E, 0x2F, 0x30, 0x31, 0x32, 0x33, 0x34,
0x35, 0x36, 0x37, 0x38, 0x39, 0x3A, 0x3B, 0x3C,
0x3D, 0x3E, 0x3F, 0x00, 0x00, 0x00, 0x00, 0x00,
};

static int zx81_ascii(int k)
{
if (k == 0x76)
return '\n';
# 79
if (k == 0x70)
return 0x1E;
if (k == 0x71)
return 0x1F;
if (k == 0x73)
return 0x14;
if (k == 0x74)
return 0x13;
if (k == 0x75)
return 0x11;
if (k == 0x77)
return 0x12;
if (k < 0 || k > 63)
return -1;
return ZX81_TO_ASCII[k];
}

int hal_getchar(void)
{
int k = getk();
return k ? zx81_ascii(k) : -1;
}

int hal_kbhit(void)
{
return getk() != 0;
}
# 116
static int zx81_row = 8;
static int zx81_col = 0;

static rt_u8 *zx81_dfile(void)
{
# 127
unsigned d = *(unsigned *)0x400C;
return (rt_u8 *)d;
}

static rt_u8 *zx81_line(int row)
{
# 137
return zx81_dfile() + 1 + row * 33;
}
# 143
static rt_u8 zx81_code(int c)
{
if (c < 0x20 || c > 0x7F)
return 0x00;
return ASCII_TO_ZX81[c - 0x20];
}

static void zx81_scr_scroll(void)
{
int row, col;
for (row = 8; row < 21; row++) {
rt_u8 *dst = zx81_line(row);
rt_u8 *src = zx81_line(row + 1);
for (col = 0; col < 33; col++)
dst[col] = src[col];
}
for (col = 0; col < 32; col++)
zx81_line(21)[col] = 0x00;
}

static void zx81_advance(void)
{
zx81_col = 0;
if (++zx81_row > 21) {
zx81_scr_scroll();
zx81_row = 21;
}
}

void hal_putchar(int c)
{
if (c == '\n') {
zx81_advance();
return;
}
if (zx81_col > 31)
zx81_advance();
zx81_line(zx81_row)[zx81_col] = zx81_code(c);
zx81_col++;
}

void hal_flush(void)
{
}

void hal_msleep(long ms)
{
# 194
unsigned char *f = (unsigned char *)0x4034;
unsigned start = (unsigned)(f[0] | (f[1] << 8));
unsigned want = (unsigned)(ms / 20);
while ((unsigned)(f[0] | (f[1] << 8)) - start < want)
;
}

rt_u32 hal_entropy(void)
{

unsigned char *f = (unsigned char *)0x4034;
return (rt_u32)f[0] | ((rt_u32)f[1] << 8) | 0x81000000UL;
}
# 213
rt_u8 hal_scratch_get(long i)
{
return zx81_line((int)(i / 32))[i % 32];
}

void hal_scratch_put(long i, rt_u8 v)
{

zx81_line((int)(i / 32))[i % 32] = v;
}


void hal_scratch_char(long i, char c)
{
zx81_line((int)(i / 32))[i % 32] = zx81_code(c);
}

void hal_panic(const char *msg)
{
const char *p = msg;

zx81_row = 21;
zx81_col = 0;
while (*p)
hal_putchar(*p++);
hal_putchar('\n');
for (;;)
;
}
