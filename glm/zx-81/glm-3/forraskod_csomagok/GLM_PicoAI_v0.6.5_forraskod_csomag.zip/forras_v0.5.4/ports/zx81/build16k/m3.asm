;* * * * *  Small-C/Plus z88dk * * * * *
;  Version: 20070909.1
;
;	Reconstructed for the z80 Module Assembler
;
;	Module compile time: Fri Nov 20 17:01:17 2026



	MODULE	rt_charset.c

	INCLUDE "z80_crt0.hdr"


._RT_CHARSET
	defm	""&13&" abcdefghijklmnopqrstuvwxyz,."
	defm	"?!0123456789:-/*()"&0



._rt_charset_init
	ld	hl,0	;const
	push	hl
	jp	i_6
.i_4
	pop	hl
	inc	hl
	push	hl
	dec	hl
.i_6
	pop	hl
	push	hl
	ld	de,128	;const
	ex	de,hl
	call	l_lt
	jp	nc,i_5
	ld	hl,_RT_CHAR_TO_IDX
	ex	de,hl
	pop	hl
	push	hl
	add	hl,de
	ld	(hl),#(1 % 256 % 256)
	ld	l,(hl)
	ld	h,0
	jp	i_4
.i_5
	ld	hl,0	;const
	pop	bc
	push	hl
	jp	i_9
.i_7
	pop	hl
	inc	hl
	push	hl
	dec	hl
.i_9
	pop	hl
	push	hl
	ld	de,48	;const
	ex	de,hl
	call	l_lt
	jp	nc,i_8
	ld	hl,_RT_CHAR_TO_IDX
	push	hl
	ld	de,_RT_CHARSET
	ld	hl,4-2	;const
	add	hl,sp
	call	l_gint	;
	add	hl,de
	call	l_gchar
	ld	h,0
	pop	de
	add	hl,de
	ex	de,hl
	pop	hl
	push	hl
	ld	a,l
	ld	(de),a
	ld	hl,_RT_CHARSET
	ex	de,hl
	pop	hl
	push	hl
	add	hl,de
	call	l_gchar
	ld	de,97	;const
	ex	de,hl
	call	l_ge
	jp	nc,i_11
	ld	hl,_RT_CHARSET
	ex	de,hl
	pop	hl
	push	hl
	add	hl,de
	call	l_gchar
	ld	de,122	;const
	ex	de,hl
	call	l_le
	jr	c,i_12_i_11
.i_11
	jp	i_10
.i_12_i_11
	ld	hl,_RT_CHAR_TO_IDX
	push	hl
	ld	de,_RT_CHARSET
	ld	hl,4-2	;const
	add	hl,sp
	call	l_gint	;
	add	hl,de
	call	l_gchar
	ld	bc,-97+(65)
	add	hl,bc
	pop	de
	add	hl,de
	ex	de,hl
	pop	hl
	push	hl
	ld	a,l
	ld	(de),a
.i_10
	jp	i_7
.i_8
	pop	bc
	ret



._rt_map_char
	ld	hl,2	;const
	add	hl,sp
	call	l_gchar
	ld	h,0
	ld	a,l
	call	l_sxt
	dec	sp
	ld	a,l
	pop	hl
	ld	l,a
	push	hl
	ld	hl,0	;const
	add	hl,sp
	ld	a,(hl)
	cp	#(128 % 256)
	jr	z,i_13_uge
	jp	c,i_13
.i_13_uge
	ld	hl,1 % 256	;const
	inc	sp
	ret


.i_13
	ld	de,_RT_CHAR_TO_IDX
	ld	hl,2-2	;const
	add	hl,sp
	ld	l,(hl)
	ld	h,0
	add	hl,de
	ld	l,(hl)
	ld	h,0
	inc	sp
	ret




; --- Start of Static Variables ---

._RT_CHAR_TO_IDX	defs	128


; --- Start of Scope Defns ---

	XDEF	_rt_charset_init
	XDEF	_RT_CHARSET
	XDEF	_RT_CHAR_TO_IDX
	XDEF	_rt_map_char


; --- End of Scope Defns ---


; --- End of Compilation ---
