# 1 "../../../engine/rt_engine.c"

# 16 "../../../engine/rt_types.h"
typedef signed char rt_i8;
typedef unsigned char rt_u8;
typedef short rt_i16;
typedef unsigned short rt_u16;
typedef long rt_i32;
typedef unsigned long rt_u32;
# 55 "../../../engine/rt_model.h"
typedef struct {
rt_u16 version, flags;
rt_u16 vocab, ctx, emb, h1, h2;
rt_u16 sh_e, sh1, sh2, sh_o, temp_sh;
} rt_hdr;

typedef struct {
rt_hdr hdr;
rt_i8 *emb;
rt_u8 *sh1;
rt_i8 *w1;
rt_u8 *sh2;
rt_i8 *w2;
rt_u8 *sho;
rt_i8 *wo;
const rt_u8 *raw;
} rt_model;
# 79
int rt_model_load(rt_model *m, const rt_u8 *buf, long len);


long rt_model_size(const rt_hdr *h);
# 12 "../../../engine/rt_engine.h"
void rt_forward(const rt_model *m, const rt_u8 *ctx, rt_i32 *logits);


void rt_last_hidden(const rt_i8 **h, int *n);


rt_u32 rt_rand(rt_u32 *seed);
# 23
int rt_sample(const rt_model *m, const rt_i32 *logits, int temp_sh,
int greedy, rt_u32 *seed);
# 11 "../../../engine/rt_lut.h"
static const rt_u16 RT_EXP_LUT[256] = {
4096, 3615, 3190, 2815, 2484, 2192, 1935, 1707,
1507, 1330, 1174, 1036, 914, 807, 712, 628,
554, 489, 432, 381, 336, 297, 262, 231,
204, 180, 159, 140, 124, 109, 96, 85,
75, 66, 58, 52, 46, 40, 35, 31,
28, 24, 21, 19, 17, 15, 13, 12,
10, 9, 8, 7, 6, 5, 5, 4,
4, 3, 3, 3, 2, 2, 2, 2,
1, 1, 1, 1, 1, 1, 1, 1,
1, 0, 0, 0, 0, 0, 0, 0,
0, 0, 0, 0, 0, 0, 0, 0,
0, 0, 0, 0, 0, 0, 0, 0,
0, 0, 0, 0, 0, 0, 0, 0,
0, 0, 0, 0, 0, 0, 0, 0,
0, 0, 0, 0, 0, 0, 0, 0,
0, 0, 0, 0, 0, 0, 0, 0,
0, 0, 0, 0, 0, 0, 0, 0,
0, 0, 0, 0, 0, 0, 0, 0,
0, 0, 0, 0, 0, 0, 0, 0,
0, 0, 0, 0, 0, 0, 0, 0,
0, 0, 0, 0, 0, 0, 0, 0,
0, 0, 0, 0, 0, 0, 0, 0,
0, 0, 0, 0, 0, 0, 0, 0,
0, 0, 0, 0, 0, 0, 0, 0,
0, 0, 0, 0, 0, 0, 0, 0,
0, 0, 0, 0, 0, 0, 0, 0,
0, 0, 0, 0, 0, 0, 0, 0,
0, 0, 0, 0, 0, 0, 0, 0,
0, 0, 0, 0, 0, 0, 0, 0,
0, 0, 0, 0, 0, 0, 0, 0,
0, 0, 0, 0, 0, 0, 0, 0,
0, 0, 0, 0, 0, 0, 0, 0,
};
# 15 "../../../engine/rt_engine.c"
static rt_i8 rt_x[8 * 10];
static rt_i8 rt_h1[18];
static rt_i8 rt_h2[18];
static rt_i8 *rt_hlast;
static int rt_hlast_n;

static void matmul_hid(const rt_i8 *w, const rt_u8 *sh, const rt_i8 *x,
int n_in, int n_out, rt_i8 *y)
{
int o, i;
for (o = 0; o < n_out; o++) {
const rt_i8 *wr = w + (long)o * (n_in + 1);
rt_i32 acc = 0;
for (i = 0; i < n_in; i++)
acc += (rt_i32)x[i] * (rt_i32)wr[i];
acc += (rt_i32)128 * wr[n_in];
acc >>= sh[o];
if (acc < 0)
acc = 0;
if (acc > 127)
acc = 127;
y[o] = (rt_i8)acc;
}
}

static void matmul_logits(const rt_i8 *w, const rt_u8 *sh, const rt_i8 *x,
int n_in, int n_out, rt_i32 *lg)
{
int o, i;
for (o = 0; o < n_out; o++) {
const rt_i8 *wr = w + (long)o * (n_in + 1);
rt_i32 acc = 0;
for (i = 0; i < n_in; i++)
acc += (rt_i32)x[i] * (rt_i32)wr[i];
acc += (rt_i32)128 * wr[n_in];
lg[o] = acc >> sh[o];
}
}

void rt_forward(const rt_model *m, const rt_u8 *ctx, rt_i32 *logits)
{
int i, j;
int n_in = (int)m->hdr.ctx * (int)m->hdr.emb;

for (i = 0; i < (int)m->hdr.ctx; i++) {
const rt_i8 *e = m->emb + (long)ctx[i] * m->hdr.emb;
for (j = 0; j < (int)m->hdr.emb; j++)
rt_x[i * (int)m->hdr.emb + j] = e[j];
}

matmul_hid(m->w1, m->sh1, rt_x, n_in, m->hdr.h1, rt_h1);
if (m->hdr.h2) {
matmul_hid(m->w2, m->sh2, rt_h1, m->hdr.h1, m->hdr.h2, rt_h2);
rt_hlast = rt_h2;
rt_hlast_n = m->hdr.h2;
} else {
rt_hlast = rt_h1;
rt_hlast_n = m->hdr.h1;
}
matmul_logits(m->wo, m->sho, rt_hlast, rt_hlast_n, m->hdr.vocab,
logits);
}

void rt_last_hidden(const rt_i8 **h, int *n)
{
*h = rt_hlast;
*n = rt_hlast_n;
}

rt_u32 rt_rand(rt_u32 *seed)
{
rt_u32 x = *seed;
x = (x ^ ((x << 13) & 0xFFFFFFFFUL)) & 0xFFFFFFFFUL;
x = (x ^ (x >> 17)) & 0xFFFFFFFFUL;
x = (x ^ ((x << 5) & 0xFFFFFFFFUL)) & 0xFFFFFFFFUL;
*seed = x;
return x;
}

int rt_sample(const rt_model *m, const rt_i32 *lg, int temp_sh, int greedy,
rt_u32 *seed)
{
int i, best = 0;
rt_i32 mx = lg[0];
rt_u16 w[48];
rt_u32 sum = 0, r, acc = 0;

for (i = 1; i < (int)m->hdr.vocab; i++)
if (lg[i] > mx) {
mx = lg[i];
best = i;
}
if (greedy)
return best;

for (i = 0; i < (int)m->hdr.vocab; i++) {
rt_i32 d = (mx - lg[i]) >> temp_sh;
int k = (int)(d >> 3);
if (k > 255)
k = 255;
w[i] = RT_EXP_LUT[k];
sum += w[i];
}
if (sum == 0)
return best;

r = rt_rand(seed) % sum;
for (i = 0; i < (int)m->hdr.vocab; i++) {
acc += w[i];
if (r < acc)
return i;
}
return best;
}
