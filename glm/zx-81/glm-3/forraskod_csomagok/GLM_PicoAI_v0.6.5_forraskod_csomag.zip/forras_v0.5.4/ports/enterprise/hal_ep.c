/* hal_ep.c - Enterprise 128 HAL (z88dk z80 or sdcc).
 *
 * Status: SKELETON - the EXOS call numbers below follow the published
 * EXOS interface but MUST be verified against the Enterprise technical
 * manual before first use (see docs/STATUS.md). The engine itself is
 * proven on the host.
 *
 * The Enterprise is a generous target: Z80 + 128 KB RAM, so Class B
 * (72 KB blob) fits easily; topic packs + memory.bin live on EXDOS disk
 * (primary) or tape.
 */
#include <string.h>
#include "rt_hal.h"

/* EXOS function codes (verify before use!):
 *   1  = read channel, 2 = write channel, 16 = open file/channel...
 * Calls go through the EXOS jump block at 0x000B (RST-equivalent):
 *   LD A,(function) / LD B,(channel) / CALL 0x000B with DE=HL args.  */
#define EXOS_CALL   0x000B
#define EXOS_READ   1
#define EXOS_WRITE  2
#define EXOS_OPEN   16
#define EXOS_CLOSE  17

extern int exos_call(int fn, int chan, void *buf, int len);

long hal_load_file(const char *name, rt_u8 *buf, long maxlen)
{
    /* EXDOS "disk:" channel (device 4) is the primary source */
    int ch = exos_call(EXOS_OPEN, 4, (void *)name, 0);
    long got = -1;
    if (ch >= 0) {
        got = exos_call(EXOS_READ, ch, buf, (int)maxlen);
        exos_call(EXOS_CLOSE, ch, 0, 0);
    }
    return got;
}

int hal_save_file(const char *name, const rt_u8 *buf, long len)
{
    int ch = exos_call(EXOS_OPEN, 4, (void *)name, 1);
    if (ch < 0)
        return -1;
    exos_call(EXOS_WRITE, ch, (void *)buf, (int)len);
    exos_call(EXOS_CLOSE, ch, 0, 0);
    return 0;
}

long hal_tape_load(int index, rt_u8 *buf, long maxlen)
{
    /* "tape:" channel (device 3), blocks in sequence */
    (void)index; (void)buf; (void)maxlen;
    return -1; /* TODO: wire EXOS tape channel + RT-turbo reader */
}

int hal_tape_save(int index, const rt_u8 *buf, long len)
{
    (void)index; (void)buf; (void)len;
    return -1;
}

int hal_getchar(void)  { return -1; }  /* TODO: EXOS console channel */
int hal_kbhit(void)    { return 0; }
void hal_putchar(int c){ (void)c; }    /* TODO: EXOS console write */
void hal_flush(void)   { }
void hal_msleep(long ms) { (void)ms; } /* TODO: EXOS 13 (wait ticks) */

rt_u32 hal_entropy(void) { return 0x45504F44UL; }

int hal_list_topics(char *names, int max)
{
    (void)names; (void)max;
    return -1;
}

/* Screen-RAM scratch: not supported yet. EXOS owns and banks the video
 * memory per segment; borrowing cells safely needs the segment API
 * (future work). */
long hal_scratch_cells(void)          { return -1; }
int  hal_scratch_bits(void)           { return 8; }
rt_u8 hal_scratch_get(long i)         { (void)i; return 0; }
void hal_scratch_put(long i, rt_u8 v) { (void)i; (void)v; }

void hal_panic(const char *msg)
{
    (void)msg;
    for (;;)
        ;
}
