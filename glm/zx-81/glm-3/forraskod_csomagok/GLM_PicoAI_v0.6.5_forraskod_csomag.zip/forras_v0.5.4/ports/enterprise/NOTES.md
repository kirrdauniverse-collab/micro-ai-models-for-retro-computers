# Enterprise 128 notes

- Best-endowed Z80 target: 128 KB RAM, so Class B (72 KB) and all topic
  packs fit at once; EXDOS disk is the primary source.
- hal_ep.c is a SKELETON: the EXOS call numbers follow published docs but
  were not verified here. Before first hardware run, check:
  * EXOS function numbers (open/read/write/close) in the EXOS 2.1 manual
  * device channel numbers for "disk:" and "tape:"
  * the exact trampoline for calling EXOS from C (sdcc __z88dk parameters)
- Tape: EXOS exposes tape as a channel, which makes the RT-turbo pulse
  decoder unnecessary - read the channel like a file (slower but simple).
