/* main_ep.c - Enterprise 128 entry point. */
#include "rt_app.h"

int main(void)
{
    if (rt_app_boot("model.bin") != 0)
        return 1;
    rt_app_run();
    return 0;
}
